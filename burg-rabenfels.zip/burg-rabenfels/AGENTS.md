# Anleitung für KI-Agenten: Inhalte für Burg Rabenfels

Diese Datei richtet sich an eine KI, die dem Spiel neue **Klassen, Karten, Quests und Gegner**
hinzufügen soll. Sie ist so geschrieben, dass du ohne Lesen der Engine arbeiten kannst.

## Das Wichtigste in einer Minute

1. **Inhalte sind Daten.** Alles, was es im Spiel gibt, steht als Python-Datei unter `content/`
   und meldet sich über Funktionen aus `game/registry.py` an. Der Server lädt beim Start jede
   `.py`-Datei unter `content/` (auch in Unterordnern). Eine neue Datei genügt – nirgends muss
   etwas eingetragen oder importiert werden.
2. **`game/engine.py` und `static/js/` bleiben unberührt.** Figuren, Symbole, Effekte, Dialoge,
   Skilltree und Minimap entstehen im Browser aus den Daten. Was sich *nicht* über Daten lösen
   lässt, steht unten unter „Wo Daten nicht reichen“.
3. **Nie von null beginnen.** `tools/neu.py` legt ein gültiges, spielbares Gerüst an; du passt es an.
4. **Nach jeder Änderung prüfen.** `tools/pruefen.py` meldet alle Fehler auf einmal, mit Datei und Ursache.

```
python tools/neu.py klasse paladin --name Paladin --stil klinge     # Gerüst anlegen
python tools/pruefen.py                                             # Fehler und Hinweise
python tools/pruefen.py --spiel                                     # Probelauf der Spiellogik, < 2 s
python test_spiel.py                                                # vollständiger Test, wenige Sekunden
```

Alle vier laufen ohne Browser und ohne Netzwerk. Rückgabewert 0 heißt in Ordnung. Der Server
liest die Inhalte nur beim Start – nach Änderungen neu starten.

## Arbeitsablauf

| Schritt | Befehl | Wozu |
| --- | --- | --- |
| 1. Bestand ansehen | `python tools/pruefen.py` | Übersicht: Karten, Klassen, Kennungen |
| 2. Gerüst anlegen | `python tools/neu.py klasse\|karte\|gegner\|quest ID …` | gültige Datei unter `content/` |
| 3. Anpassen | Datei bearbeiten | Namen, Texte (`TODO`), Werte, Plan |
| 4. Prüfen | `python tools/pruefen.py` | Querverweise, Geometrie, Platzhalter |
| 5. Ansehen | `--karte ID`, `--klasse ID`, `--quests` | Plan mit Zahlenleiste, Skilltree als Tabelle |
| 6. Probelauf | `python tools/pruefen.py --spiel` | jede Fähigkeit, jeder Übergang, jede Quest, jedes Verlies |
| 7. Gesamttest | `python test_spiel.py` | am Ende einmal; verträgt neue Inhalte, verlangt aber null Hinweise |

Schritt 4 nach jeder Datei wiederholen, nicht erst am Ende: Die Meldungen nennen die Stelle genau,
solange nur eine Sache neu ist.

**Ausprobieren, ohne `content/` anzufassen:** `--ordner ORDNER` bei `neu.py` schreibt woanders hin;
`--extra ORDNER` bei `pruefen.py` und die Umgebungsvariable `RABENFELS_CONTENT=ORDNER` beim Server
laden den Ordner zusätzlich (mehrere Ordner mit `:` getrennt, unter Windows mit `;`).

**Im Browser ansehen** (falls du einen steuern kannst): `RABENFELS_DEV=1 python app.py`, dann
`http://localhost:5000`. Im Chat (Enter) gibt es `/tp x z` (Kachel der aktuellen Karte),
`/tp karte x z`, `/lvl n`, `/gold n`, `/tiefe n`.

## Regeln, die immer gelten

- **Kennungen** bestehen aus Kleinbuchstaben, Ziffern und `_` und beginnen mit einem Buchstaben.
  Sie sind je Art im ganzen Spiel eindeutig – auch Fähigkeiten über alle Klassen hinweg und
  Bewohner über alle Karten. Stell deshalb neuen Fähigkeiten die Klasse voran (`paladin_richtspruch`).
- **Kennungen stehen in Speicherständen.** Bestehende nicht umbenennen oder löschen: Helden verlören
  die Quest oder Fähigkeit (die Punkte bekommen sie zurück). Neues hinzufügen ist immer gefahrlos.
- **Koordinaten sind Kacheln der jeweiligen Karte:** `(x, z)`, `x` = Spalte ab links, `z` = Zeile ab
  oben, beide ab 0. Eine ganze Zahl ist die linke bzw. obere Kante der Kachel, `.5` ihre Mitte:
  `(13.5, 5.5)` ist die Mitte der Kachel in Spalte 13, Zeile 5. Setze Bewohner, Ziele von Übergängen
  und Lichter am besten auf Kachelmitten, damit niemand halb in einer Wand steht; Questgegenstände
  und `portal(at=…)` nennen die Kachel mit ganzen Zahlen. Welt- oder Bildschirmkoordinaten brauchst du nie.
- **Rechtecke** sind `(x0, z0, x1, z1)` in Kacheln, beide Ecken eingeschlossen.
- **Alle sichtbaren Texte sind deutsch**, in der Du-Form, ohne Fachbegriffe der Technik.
- **`TODO`** in einem Text ist ein Platzhalter des Gerüsts. `pruefen.py` zählt sie als Hinweis auf –
  am Ende darf keiner übrig sein, sonst steht „TODO“ im Spiel.
- **Reihenfolge:** Geladen wird alphabetisch – erst die Dateien direkt in `content/`, dann die
  Unterordner. Querverweise werden erst geprüft, wenn alles geladen ist; die Reihenfolge ist also
  nur für die Anzeige wichtig (Klassen am Tor, Quests in der Liste) und für Kombos (die erste
  passende gewinnt). Dateien, deren Name mit `_` beginnt, werden übersprungen.
- **Farben** sind `'#rrggbb'`.

## Aufbau

```
content/                 ← hier arbeitest du
  grundlagen.py            Schadensarten, Zustände, Kombos, Questgegenstände, Aussehen-Vorlagen
  gegner.py                Gegnerarten
  klassen/<klasse>.py      eine Datei je Klasse: Kopf + Skilltree
  karten/<karte>.py        eine Datei je Karte: Plan, Bewohner, Gegnergebiete, Übergänge
  quests/<gebiet>.py       Quests, nach Gebiet gebündelt
game/registry.py         Anmelde-Funktionen und alle Prüfungen (Nachschlagen: Docstrings)
game/world.py            baut aus den Plänen die Welt; prüft Geometrie; Zeichen des Plans
game/data.py             feste Regeln: Höchststufe, Punkte je Stufe, Wachstumskurven
game/engine.py           Spiellogik – nicht anfassen
static/js/               Browser – nicht anfassen
tools/neu.py             Gerüst-Generator
tools/pruefen.py         Prüfen, Ansehen, Probelauf
test_spiel.py            Gesamttest der Spiellogik
```

Die vorhandenen Dateien sind zugleich die besten Beispiele: `content/klassen/krieger.py`,
`content/karten/katakomben.py`, `content/quests/burg.py`.

---

## Rezept: neue Klasse

```
python tools/neu.py klasse paladin --name Paladin --stil klinge [--farbe '#f2d16b']
```

`--stil`: `klinge` (Nahkampf, Stärke, Ausdauer), `magie` (Geschosse, Intelligenz, Mana) oder `bogen`
(Pfeile, Geschick, Ausdauer). Das Gerüst unter `content/klassen/paladin.py` enthält den Kopf und
einen vollständigen Skilltree: drei Zweige, **20 aktive und 9 passive Fähigkeiten**, jede der neun
Grundformen kommt vor, die Beschreibungen sind aus den Werten erzeugt und stimmen.

Danach:

1. `desc` und die drei Zweig-Beschreibungen schreiben (`TODO`).
2. Fähigkeiten umbenennen und umschreiben, bis die Klasse ein eigenes Gesicht hat. Stimmt eine
   Beschreibung nicht mehr mit den Werten überein, ist das ein Fehler, den kein Werkzeug findet.
3. Schadensarten und Zustände so wählen, dass **Kombos** möglich sind (Tabelle unten): mindestens ein
   Zustand, den die Klasse selbst verursacht *und* mit einer eigenen Schadensart zünden kann.
4. `python tools/pruefen.py --klasse paladin` zeigt den Baum als Tabelle.

### Kopf

```python
player_class(
    C, name='Krieger', color='#ea7d66',                # Farbe für Namen, Ring und Menüs
    desc='Steht vorn und hält stand. …',               # steht am Tor neben der Klasse
    hp=150, hp_lvl=18, dmg=15, armor=0.25,             # Leben, Leben je Stufe, Angriffskraft, Anteil abprallenden Schadens
    main='str', res='ausdauer',                        # Hauptattribut str | ges | int · Vorrat mana | ausdauer
    atk={'name': 'Schwerthieb', 'type': 'melee', 'cd': 0.55, 'range': 2.7, 'arc': 2.0, 'tag': 'schnitt'},
    look={'cloth': '#8f2f28', 'hat': 'helmet', 'weapon': 'sword', 'shield': '#6f757d', 'scale': 1.12},
    branches=[('Waffenmeister', 'Klingenkunst und Blutungen'), ('Bollwerk', '…'), ('Berserker', '…')],
    start='wirbel',                                    # aktive Fähigkeit mit lvl 1 – jeder Held hat sie von Anfang an
)
```

Grundangriff als Geschoss: `{'name', 'type': 'shot', 'kind', 'cd', 'range', 'speed', 'splash', 'tag'}`
(`splash` = Radius des Flächenschadens beim Einschlag, 0 = keiner). `style='klinge'|'magie'|'bogen'`
legt die Bewegungen fest; ohne Angabe folgt er aus dem Grundangriff.

Richtwerte der drei vorhandenen Klassen – bleib in diesem Rahmen:

| | hp | hp_lvl | dmg | armor | Grundangriff cd | Reichweite |
| --- | --- | --- | --- | --- | --- | --- |
| Nahkampf (Krieger) | 150 | 18 | 15 | 0.25 | 0.55 | 2.7 |
| Zauber (Magier) | 85 | 9 | 18 | 0.0 | 0.75 | 15 |
| Bogen (Waldläufer) | 105 | 12 | 12 | 0.08 | 0.45 | 17 |

Angriffskraft eines Helden = `(dmg + Hauptattribut × 0,5) × (1 + 3 % je Stufe) × Waffe`. Ein Treffer
richtet Angriffskraft × `mult` an.

### Fähigkeiten

```python
active(id, cls, branch, lvl, name, form, tag, cost, cd, desc, **angaben)
passive(id, cls, branch, lvl, name, stat, per, desc)        # desc enthält {v} für den Prozentwert
```

- `branch` 0–2, `lvl` = Heldenstufe, ab der sie lernbar ist. Innerhalb eines Zweigs verlangt der
  n-te Knoten (nach `lvl` sortiert) n−1 Punkte im selben Zweig – das wird berechnet, nicht angegeben.
- Eine einzelne Fähigkeit für eine *vorhandene* Klasse ist eine Zeile `active(…)` in irgendeiner
  Inhaltsdatei. Sie reiht sich nach ihrem `lvl` in den Zweig ein; alle späteren Knoten des Zweigs
  verlangen dadurch einen Punkt mehr.
- `tag` = Schadensart (`None` = keine, `'hilfe'` für Heilung und Schutz). Wer `mult` > 0 hat, braucht eine.
- `cost` aus einem Vorrat von rund 100, der sich mit 4–7 je Sekunde erholt; `cd` in Sekunden.
- Jede Stufe einer aktiven Fähigkeit (bis 5) bringt +12 % Wirkung, Dauern +10 %.

**Grundformen** (`form`) und ihre Angaben – fett = Pflicht:

| form | wirkt | Angaben |
| --- | --- | --- |
| `arc` | Hieb in Blickrichtung | **range**, **arc** (Öffnung im Bogenmaß; 2.0 ≈ 115°), hits (Treffer nacheinander) |
| `nova` | Kreis um den Helden | **r**, fade=True (Gegner lassen kurz ab) |
| `shot` | Geschoss zum Mauszeiger | **speed**, **range**, kind, count + spread (Fächer), pierce=True, splash, size |
| `blast` | Einschlag nach Verzögerung | **r**, **delay**, **range** *oder* at_self=True, falling=True (fällt vom Himmel) |
| `zone` | Feld, das wiederholt wirkt | **r**, **dur**, **tick**, **range** *oder* at_self=True *oder* follow=True; ally={…} für Gefährten |
| `dash` | Vorstoß in Zielrichtung | **dist**, leap=True (zum Mauszeiger), r + mult (Schaden am Ziel), mods + dur (Stärkung danach) |
| `chain` | springt von Gegner zu Gegner | **range**, **jump** (Sprungweite), **n** (Ziele) |
| `buff` | Stärkung | **dur**, mods={…}, r (auch Gefährten im Umkreis), absorb (Schild als Anteil des Lebens), taunt (Radius: Gegner greifen dich an) |
| `heal` | heilt Helden im Umkreis | **r**, **pct** (Anteil des Lebens) |

Für jede Form, die Gegner trifft, zusätzlich: `mult` (Schaden, 0 = keiner), `apply` (Zustand),
`stun` (Sekunden), `slow` (Sekunden) mit `slow_f` (Tempo-Faktor, Vorgabe 0.5), `weaken` (Sekunden,
in denen der Gegner 25 % schwächer zuschlägt), `execute=True` (+50 % gegen Gegner unter 35 % Leben),
`color` (Effektfarbe statt der Farbe der Schadensart).

- `mods` eines `buff`/`dash`: `dmg`, `armor`, `haste`, `speed`, `crit`, `lifesteal`, `regen` (Leben je Sekunde
  als Anteil), `res_pct` (Vorrat je Sekunde als Anteil) – jeweils als Anteil, `0.3` = 30 %.
- `ally` einer `zone`: `armor`, `regen`, `heal` (Heilung je Tick als Anteil des Lebens); dazu `mult=0`.
- `kind` eines Geschosses (nur Aussehen): `fire`, `ice`, `arkan`, `arrow`, `poison`, `welle`, `dark`.
- `stat` einer passiven Fähigkeit: `hp_pct`, `res_max_pct`, `res_regen_pct`, `crit`, `crit_dmg`, `dr`
  (weniger erlittener Schaden), `speed`, `haste`, `heal_pct`, `combo`, `status_dur`, `kill_heal`,
  `dmg_<Schadensart>`, `dot_<Zustand>`. `per` ist der Zuwachs je Stufe als Anteil (`0.04` = 4 %).

Richtwerte für `mult` nach Lernstufe (Einzelziel etwas höher, Fläche etwas niedriger):

| lvl | mult | cd | cost |
| --- | --- | --- | --- |
| 1–10 | 1.2–1.8 | 4–8 s | 10–25 |
| 11–30 | 2.2–3.2 | 8–14 s | 20–35 |
| 31–60 (letzter Knoten eines Zweigs) | 4.5–5.5 | 30–45 s | 50–60 |
| Felder je Tick | 0.35–0.55 | 12–16 s | 28–35 |

### Schadensarten, Zustände, Kombos (`content/grundlagen.py`)

Vorhanden – verwende sie, bevor du Neues anlegst.

Schadensarten: `schnitt`, `wucht`, `stich`, `feuer`, `frost`, `blitz`, `gift`, `arkan` – und `hilfe`
für alles, was Gefährten nützt.

| Zustand | Dauer | Wirkung auf den Gegner |
| --- | --- | --- |
| `brennend` | 5 s | Schaden über Zeit |
| `blutend` | 6 s | Schaden über Zeit |
| `vergiftet` | 8 s | Schaden über Zeit |
| `gefroren` | 4 s | halbes Tempo |
| `geschockt` | 5 s | teilt 20 % weniger Schaden aus |
| `markiert` | 8 s | erleidet 10 % mehr Schaden |
| `wankend` | 5 s | erleidet 15 % mehr Schaden |

Kombo = ein Treffer der passenden Schadensart auf einen Gegner mit dem Zustand. Der Zustand wird
verbraucht, derselbe Gegner ist danach eine Sekunde lang nicht erneut kombinierbar.

| Kombo | Zustand + Schadensart |
| --- | --- |
| Zersplittern | gefroren + wucht |
| Thermoschock | gefroren + feuer · brennend + frost |
| Flächenbrand | vergiftet + feuer · brennend + gift |
| Ausbrennen | blutend + feuer |
| Ausbluten | blutend + stich |
| Überladung | geschockt + stich · geschockt + schnitt |
| Hinrichten | wankend + schnitt |
| Volltreffer | markiert + stich · schnitt · wucht |
| Richtspruch | geblendet + wucht · wankend + licht |
| Läuterung | geblendet + feuer · brennend + licht |
| Reinigung | vergiftet + licht |

`licht` (Schadensart) und `geblendet` (Zustand: teilt 25 % weniger aus, 4 s) stehen in `content/licht.py`.

Neues in einer eigenen Datei, z. B. `content/licht.py`:

```python
from game.registry import combo, status, tag
tag('licht', 'Licht', '#ffe9a8')
status('geblendet', 'Geblendet', '#ffe9a8', dur=4.0, weak=0.3, desc='Teilt 30 % weniger Schaden aus.')
combo('laeuterung', 'Läuterung', [('geblendet', 'licht'), ('brennend', 'licht')], bonus=0.7, stun=1.0,
      desc='70 % mehr Schaden und eine Sekunde Betäubung.')
```

`status`: `dot` (Schaden je Sekunde als Anteil der Angriffskraft des Verursachers), `slow`
(Tempo-Faktor), `weak` (teilt weniger aus), `vuln` (erleidet mehr). `combo`: `bonus` (1.0 = doppelter
Schaden) und wahlweise `stun=Sekunden`, `apply=Zustand`, `crit=True`, `burst=Faktor` (restlicher
Schaden über Zeit sofort), `execute=Faktor`, `aoe={'r', 'mult', 'tag', 'apply'}`,
`chain={'n', 'mult', 'r', 'tag'}`. Eine Kombo nützt nur, wenn irgendeine Fähigkeit den Zustand
verursacht und irgendeine mit der Schadensart trifft.

---

## Rezept: neue Karte

```
python tools/neu.py karte moor --name "Das Moor" --groesse 34x26 [--licht tag|dunkel] [--gegner wolf]
python tools/neu.py karte mine --name "Alte Mine" --licht dunkel --verlies [--stufe 12]
```

Das Gerüst unter `content/karten/moor.py` ist sofort begehbar und angeschlossen: Plan mit
Ankunftsbereich und Gegnergebiet, Start, ein Bewohner, Gegner, Lichter, der Rückweg (Ziffer `1` im
Plan) und der **Eingang**: `portal('burg', at=(x, z), to='moor')` am Ende der Datei macht eine freie
Kachel im Burghof zur Treppe mit Lichtsäule. Die Kachel sucht das Werkzeug selbst; mit
`--eingang 30,40` oder `--eingang katakomben:15,7` legst du sie fest.

Danach: Plan umzeichnen, Orte benennen, Bewohner und Gegner setzen – und nach jedem Schritt
`python tools/pruefen.py --karte moor`. Die Ausgabe zeigt den Plan mit Zahlenleiste (`@` Start,
Buchstaben = Bewohner, `*` Questgegenstände, `>` Übergänge, `?` begehbare Kacheln, die niemand
erreichen kann) und nennt zu jeder Zone die begehbaren Kacheln. Der Plan erscheint auch dann, wenn
noch Fehler offen sind (solange alle Zeilen gleich lang sind und nur bekannte Zeichen vorkommen) –
lies Koordinaten dort ab, statt im Quelltext zu zählen.

### Plan

Ein Zeichen je Kachel (2 × 2 Meter), alle Zeilen gleich lang, 6 bis 96 Kacheln je Richtung,
keine Leerzeichen (Leere = `M`). Die Einrückung im Quelltext wird entfernt.

| Untergrund, begehbar | | Untergrund, fest | | Gegenstand, fest | |
| --- | --- | --- | --- | --- | --- |
| `,` | Gras | `#` | Ringmauer | `T` | Baum |
| `:` | Erdweg | `H` | Hauswand (Fachwerk) | `R` | Felsbrocken |
| `.` | Pflaster | `O` | Turm | `+` | Grabstein |
| `_` | Dielen | `M` | massiver Fels / Leere | `B` `X` | Fässer · Kiste |
| `=` | Bohlen, Brücke | `~` | Wasser (Geschosse fliegen darüber) | `W` | Brunnen |
| `c` `k` | Kellerboden · Gruftboden | | | `^` | Zelt |
| `g` | Friedhofserde | | | `A` `F` | Amboss · Esse (leuchtet) |
| `D` `d` | Burgtor · Türdurchgang | | | `S` `P` | Steinblock · Säule |
| `v` `u` | Treppe | | | `1`–`9` | Übergang (begehbar) |

Ein Gegenstand steht auf dem Untergrund seines begehbaren Nachbarn (links, oben, rechts, unten), sonst
auf `floor` der Karte. Brauchst du etwas anderes, lege mit `legend={'x': ('_', 'X')}` ein eigenes
Zeichen fest: (Untergrund, Gegenstand). Gebäude entstehen aus `H`-Wänden mit `d`-Türen; Innenräume
sind einfach begehbarer Untergrund dahinter. Eine Kachel Breite genügt für jeden Durchgang, auch
für Bosse. Geschosse fliegen über Wasser und niedrige Gegenstände (`+ B X W A F S`) hinweg; Mauern,
Bäume, Felsbrocken, Säulen und Zelte halten sie auf.

### Angaben von `game_map`

```python
game_map(
    'moor', name='Das Moor', light='tag', floor=',', start=(17, 3.5),
    plan="""…""",
    regions=[('Moorsteg', (1, 1, 32, 5)), ('Das Moor', (0, 0, 33, 25))],     # Ortsnamen; der erste Treffer gewinnt
    zones={'wildnis': {'rect': (2, 8, 31, 23), 'margin': 1}},                # Gegnergebiete
    spawns=[('wolf', 'wildnis', 9), ('boss', 'gruft', 1, (35, 25.5))],       # (Gegnerart, Zone, Anzahl[, fester Platz])
    pickups=[('ore', 12, 14)],                                               # (Questgegenstand, x, z)
    npcs={'ilse': {'name': 'Fährfrau Ilse', 'role': 'Hüterin des Stegs', 'look': 'cook', 'at': (20.5, 3.5),
                   'greet': 'Weiter als bis zur Hecke bringe ich niemanden.', 'services': ['potion']}},
    portals={'1': {'to': 'burg', 'target': (23.5, 21.5)}},                   # wohin die Ziffer 1 im Plan führt
    deco=[('torch', 14.5, 1.5), ('fire', 10, 12)],                           # torch | ghost | fire | banner
)
```

- `light`: `'tag'` oder `'dunkel'`. Dunkle Karten brauchen Lichter in `deco` (`ghost` = kaltes
  Geisterlicht, `torch` = Fackel, `fire` = Lagerfeuer), sonst sieht man nichts – etwa alle 6 Kacheln eines.
- `ambient`: Hintergrundklang `'wind'`, `'wald'`, `'sumpf'`, `'hoehle'`, `'gruft'` oder `'ruine'`. Ohne Angabe
  `'wind'` bei Tag und `'hoehle'` im Dunkeln.
- `start`: Ankunft ohne eigenes Ziel und Wiederbelebung nach dem Tod. Gehört nicht in ein Gegnergebiet.
- `zones`: Gegner erscheinen auf zufälligen erreichbaren Kacheln im `rect` und verfolgen Helden bis
  `margin` Kacheln darüber hinaus; dann kehren sie um und erholen sich. Halte zwischen Start,
  Bewohnern und dem nächsten Gebiet mindestens `margin + 2` Kacheln Abstand.
- `npcs`: `at` muss erreichbar sein. `look` ist eine Vorlage (`captain`, `cook`, `smith`, `priest`,
  `lady`, `guardian`, `skeleton`) oder eigene Angaben (siehe „Aussehen“). `services`: `potion`
  (Heiltränke), `weapon`, `armor` (Schmieden), `heal` (kostenlose Heilung), `respec` (Punkte
  zurücksetzen), `elixir` (Elixiere für zehn Minuten), `dungeon` (Start-Ebene wählen; nur auf einer
  Karte mit Verlies). Quests hängen nicht
  hier, sondern nennen ihren Bewohner selbst.
- `portals`: Jede Ziffer im Plan braucht einen Eintrag. `target` ist eine Kachel der Zielkarte
  (ohne Angabe: deren `start`) und darf nicht selbst auf einem Übergang liegen. Mehrere Kacheln mit
  derselben Ziffer bilden einen breiten Übergang. Wer eine Übergangskachel betritt, wird sofort
  versetzt: Lege sie an eine Wand oder ans Ende eines Wegs, nie in einen Durchgang, und mindestens
  zwei Kacheln vom `start` entfernt.
- `portal(karte, at=(x, z), to=ziel, target=None)` legt einen Übergang auf einer *bestehenden* Karte
  an, ohne deren Datei zu ändern – so bringt eine neue Karte ihren Eingang selbst mit.
- Jede Karte muss von der Hauptkarte aus erreichbar sein **und** einen Weg zurück haben; das wird geprüft.
- Genau eine Karte hat `main=True` (die Burg). Dort beginnen neue Helden.

### Endloses Verlies

Eine Karte wird zum Verlies, wenn sie `dungeon` angibt. Betritt ein Held die Zone (samt `margin`),
erwacht die nächste Ebene; sind alle Gegner besiegt, folgt nach vier Sekunden die nächste. Verlassen
alle die Zone, legt sie sich nach sechs Sekunden schlafen und merkt sich die Ebene.

```python
zones={'halle': {'rect': (2, 12, 27, 30), 'margin': 3}},
dungeon={
    'zone': 'halle', 'base_level': 7,                       # Gegnerstufe = base_level + Ebene
    'mix': [('knochen', 1, 5), ('aasratte', 1, 4), ('knochenmagier', 3, 3)],   # (Gegnerart, ab Ebene, Gewicht)
    'boss': 'gruftlord', 'boss_every': 5,                   # jede fünfte Ebene; danach neuer Einstiegspunkt
},
```

Alle Gegnerarten darin brauchen `scale=True`. Start und Bewohner dürfen nicht in der Zone samt
`margin` stehen (wird geprüft) – trenne sie durch eine Engstelle wie in
`content/karten/katakomben.py`. Je Ebene erscheinen `4 + Ebene/3` Gegner (höchstens 12), zu
mehreren mehr und zähere. Ein Bewohner mit dem Dienst `dungeon` lässt Helden nach jedem Boss auf
der folgenden Ebene wieder einsteigen.

---

## Rezept: neue Quest

```
python tools/neu.py quest wolfsjagd --npc ilse --art kill --ziel moorwolf --anzahl 5 [--nach ratten] [--stufe 4]
python tools/neu.py quest moorerz   --npc ilse --art collect --ziel ore --anzahl 4 --datei quests/moor.py
python tools/neu.py quest minentiefe --npc oswin --art depth --anzahl 10
python tools/neu.py quest moorwacht --npc ilse --art kill --wiederholbar
```

Mit `--datei` hängt das Werkzeug an eine vorhandene Datei an – bündle die Quests eines Gebiets so.
Danach `title`, `text` (der Auftrag in den Worten des Bewohners) und `done` (der Dank) schreiben.

```python
quest('goblins', title='Goblins vor dem Tor', npc='gerold', type='kill', target='goblin', count=8,
      goal='Goblins vertreiben', where='Goblinlager südlich der Zugbrücke',
      xp=200, gold=40, req='ratten', minlvl=1,
      text='Vor der Zugbrücke haben Goblins ihr Lager aufgeschlagen. Treib sie auseinander.',
      done='Das Tor ist wieder frei. Die Wache steht in deiner Schuld.')
```

| type | target | count |
| --- | --- | --- |
| `kill` | Gegnerart · `'any'` (beliebig) · `'map:<Karte>'` (alles auf dieser Karte) | Anzahl |
| `collect` | Questgegenstand, der auf einer Karte in `pickups` liegt | Anzahl |
| `combo` | `'any'` | Anzahl ausgelöster Kombos |
| `depth` | Karte mit Verlies | Ebene, die geschafft sein muss |

- `goal` ist die Kurzform in der Questliste („Goblins vertreiben 3/8“), `where` die Ortsangabe darunter.
- Belohnung fest (`xp`, `gold`) oder mit der Stufe wachsend (`xp_pct` = Anteil einer Stufe,
  `gold_lvl` = Gold je Heldenstufe) – Letzteres für wiederholbare Quests (`repeat=True`).
  Zusätzlich möglich: `potions=2`, `weapon=1` (eine Schmiedestufe).
- `req` = Quest, die vorher abgeschlossen sein muss; `minlvl` = Mindeststufe. So entstehen Ketten.
- Richtwert für `xp`: grob die Erfahrung, die eine Stufe bei `minlvl` kostet (`60 × Stufe^1,6` –
  Stufe 1: 60, Stufe 5: 790, Stufe 10: 2.390, Stufe 20: 7.240); bei Jagdquests mindestens so viel, wie
  die Gegner selbst bringen (Anzahl × `xp` des Gegners). `gold` ≈ `xp / 5`.
- Geprüft wird, ob die Quest lösbar ist: Der Gegner muss irgendwo erscheinen, der Gegenstand irgendwo
  liegen, der Bewohner existieren.
- Mitspieler in der Nähe (16 Meter) teilen den Fortschritt.

Neuer Questgegenstand: `pickup('kraut', 'Moorkraut', form='kiste'|'brocken', color='#7bc74d')` in
einer Inhaltsdatei, dann in `pickups` einer Karte verteilen – etwa doppelt so viele wie `count`.

---

## Rezept: neuer Gegner

```
python tools/neu.py gegner moorwolf --name Moorwolf --stufe 4 [--tier] [--fern]
python tools/neu.py gegner irrlicht --name Irrlicht --verlies [--fern]
```

hängt an `content/gegner.py` an. Ein Gegner erscheint erst, wenn eine Karte ihn nennt:
feste Gegner in `spawns`, wachsende (`scale=True`) in `dungeon['mix']`.

```python
enemy('goblin', 'Goblin', lvl=3, hp=62, dmg=7, speed=4.6, radius=0.5, aggro=9.0, range=1.5, cd=1.3,
      xp=26, gold=(3, 7), respawn=13,
      look={'skin': '#6f9a3c', 'cloth': '#6a4e30', 'ears': '#6f9a3c', 'weapon': 'club', 'scale': 0.88})
```

- `aggro` Sichtweite, `range` Angriffsreichweite, `cd` Sekunden zwischen Angriffen, `respawn` Sekunden bis zur Rückkehr.
- `shot=10.0` (Geschosstempo) macht ihn zum Fernkämpfer: dazu `range` um 11.
- `boss=True`: Sonderangriffe mit Vorwarnung, der Reihe nach aus `moves` (ohne Angabe nur `'slam'`):
  `'slam'` Bodenschlag am Ziel, `'cone'` Kegel vor ihm, `'charge'` Sturmangriff durch die Arena,
  `'volley'` Geschossfächer, `'nova'` Ring um ihn, `'rain'` Einschläge um jeden Helden. Unter einem Viertel
  Leben gerät jeder Boss in Raserei. Mit `summon='<Gegnerart>'` ruft er bei halbem Leben Diener.
  Zwei bis vier `moves` je Boss genügen; mischt Ausweichrichtungen (raus aus dem Ring, zur Seite, weg vom Ziel).
- Feste Gegner (nicht Bosse, nicht `scale=True`) erscheinen mit 7 % Chance als Elite – das regelt
  die Engine (`game/data.py`: `ELITE_CHANCE`, `ELITE_AFFIXES`), dafür ist keine Angabe nötig.
  Feste Bosse bekommen in `spawns` einen festen Platz und einen eigenen Raum als Zone.
- Richtwerte für feste Gegner der Stufe L: `hp ≈ 26 + 8·L + 1,9·L²`, `dmg ≈ 1 + 2·L`,
  `xp ≈ 6 + 3,5·L + 1,15·L²`, `gold=(L, 2·L+1)`, `speed` 3.2–6.0 (Helden laufen 6.5). Ein Boss wie der
  Knochenfürst (Stufe 8) hat etwa fünfzehnfaches Leben, anderthalbfachen Schaden, fünffache Erfahrung,
  `radius=1.1` und `respawn=90`.
- `scale=True`: Die Werte gelten für Stufe 1 und wachsen mit der Ebene. Vorhandene Spanne: `hp` 32–170,
  `dmg` 5–15, `xp` 1.2–4.0, `aggro=60` (sieht die ganze Halle); Boss `hp` 620, `xp` 27.

## Aussehen (`look`)

Entweder der Name einer Vorlage (`look('name', …)` in `content/grundlagen.py`) oder eigene Angaben.

**Gestalt** (Vorgabe): `cloth` (Pflicht, Farbe des Oberkörpers), `skin`, `arms`, `legs`, `robe`
(langes Gewand statt Beinen), `thin=True` (knochendünn), `eye`, `eyeGlow` (leuchtende Augen), `apron`,
`sash`, `cape`, `pads` (Schulterstücke), `ears` (spitze Ohren), `hat` (`helmet`, `wizard`, `hood`,
`crown`, `bonnet`, `hair`, `tonsure`) mit `hatColor`, `plume`, `hair`; `weapon` (`sword`,
`greatsword`, `staff`, `club`, `hammer`) mit `bladeColor`, `hilt`, `orb` (Kugel am Stab); `bow=True`,
`shield` (Farbe), `opacity` (0–1, Geister), `scale` (Größe, 1 = Mensch, Bosse um 2).

**Tier:** `body='beast'`, `fur` (Pflicht), `dark` (Beine, Schnauze), `ear`, `tail`, `eyeGlow`,
`bushy=True` (buschiger Schwanz), `scale`.

Alles außer `hat`, `weapon`, den Schaltern und Zahlen ist eine Farbe.

## Alle Anmelde-Funktionen auf einen Blick

```python
from game.registry import (tag, status, combo, look, pickup, player_class, active, passive,
                           enemy, quest, game_map, portal)

tag(id, name, color)
status(id, name, color, dur, desc, dot=0.0, slow=0.0, weak=0.0, vuln=0.0)
combo(id, name, pairs, bonus, desc, **wirkungen)             # stun, apply, crit, burst, execute, aoe, chain
look(id, **angaben)                                          # Aussehen-Vorlage
pickup(id, name, form, color)                                # form: 'kiste' | 'brocken'
player_class(id, name, desc, color, hp, hp_lvl, dmg, armor, main, res, atk, look, branches, start, style=None)
active(id, cls, branch, lvl, name, form, tag, cost, cd, desc, **angaben)
passive(id, cls, branch, lvl, name, stat, per, desc)
enemy(id, name, look, hp, dmg, speed, radius, aggro, range, cd, xp, gold,
      lvl=None, scale=False, respawn=15, boss=False, summon=None, shot=None, dust=None, moves=None)
quest(id, title, npc, type, target, count, goal, where, text, done,
      xp=None, gold=None, xp_pct=None, gold_lvl=None, req=None, minlvl=1, repeat=False, potions=0, weapon=0)
game_map(id, name, plan, start, light='tag', floor=',', legend=None, main=False, regions=(), zones=None,
         spawns=(), pickups=(), npcs=None, portals=None, deco=(), dungeon=None, ambient=None)
portal(map, at, to, target=None)
```

---

## Wo Daten nicht reichen

Diese Dinge brauchen Code. Tu das nur, wenn die Aufgabe es ausdrücklich verlangt, und lass danach
`python test_spiel.py` laufen – und sieh es dir im Browser an, denn die Tests prüfen keine Darstellung.

| Wunsch | Stellen |
| --- | --- |
| neues Zeichen im Plan (Untergrund, Gegenstand) | `game/world.py` (`FLOOR_CHARS`, `OBJ_CHARS`, `SOLID_…`, `SHOT_…`) · `static/js/world.js` (`buildGround`, `buildObjects`, `minimap`) |
| neue Grundform einer Fähigkeit | `game/registry.py` (`FORMS`) · `game/engine.py` (`_cast`) · `static/js/ui.js` (`ICONS`, Werte im Skilltree) |
| neue Angabe einer vorhandenen Form | `game/registry.py` (`FORMS`, `NUM_PARAMS`/`FLAG_PARAMS`) · `game/engine.py` (`_cast`, `_strike`) |
| neuer passiver Wert | `game/registry.py` (`PASSIVE_STATS`) · `game/engine.py` (`Player.recalc`) |
| neue Quest-Art | `game/registry.py` (`QUEST_TYPES`, `check`) · `game/engine.py` (`_quest_progress` und sein Aufruf) · `static/js/ui.js` (`progress`) |
| neuer Dienst eines Bewohners | `game/registry.py` (`SERVICES`) · `game/engine.py` (`on_shop`) · `static/js/ui.js` (`renderDialog`) |
| neue Kopfbedeckung, Waffe, Körperform | `game/registry.py` (`HATS`, `WEAPONS`, `HUMAN_LOOK`) · `static/js/entities.js` (`humanoid`, `quadruped`) |
| neues Geschoss-Aussehen, Deko, Questgegenstand-Form | `game/registry.py` (`SHOT_KINDS`, `DECO`, `PICKUP_FORMS`) · `static/js/entities.js` · `static/js/world.js` (`buildDeco`) |
| mehr als drei Zweige, mehr als vier Tasten, andere Höchststufe | `game/data.py` und die Fenster in `static/js/ui.js` – größerer Umbau |
| Schwierigkeit insgesamt | `game/data.py`: `enemy_hp_mult`, `enemy_dmg_mult`, `enemy_xp`, `xp_needed` |

Vokabular, das die Prüfung kennt, steht als Mengen am Anfang von `game/registry.py`. Was dort fehlt,
gibt es nicht – erfinde keine Angaben, die Prüfung lehnt sie ab.

## Häufige Meldungen

| Meldung | Ursache und Abhilfe |
| --- | --- |
| `Zeile n des Plans ist … Zeichen lang` | Alle Zeilen brauchen dieselbe Länge wie die erste; die Meldung nennt die Zeile. |
| `der Platz (x, z) ist nicht erreichbar` | Kachel ist fest oder vom Start abgeschnitten. `x` ist die Spalte, `z` die Zeile – oft vertauscht. |
| `im Rechteck … liegt keine erreichbare Kachel` | Zone liegt in Mauern oder hinter einer geschlossenen Wand. |
| `führt kein Übergang hierher` / `zurück` | `portal('burg', at=…, to='<karte>')` fehlt bzw. die Ziffer im Plan samt `portals`-Eintrag. |
| `das Ziel … liegt selbst auf einem Übergang` | `target` eine Kachel neben die Treppe legen, nicht darauf. |
| `liegt direkt am Startpunkt` | Übergang oder `start` verschieben: zwei Kacheln Abstand. |
| `liegt im Verlies … samt margin` | Start/Bewohner weiter weg oder `margin` kleiner; dazwischen eine Engstelle. |
| `taucht auf keiner Karte auf` / `liegt auf keiner Karte` | Gegner in `spawns`/`mix` bzw. Gegenstand in `pickups` einer Karte eintragen. |
| `unbekannte Angabe …` | Tippfehler oder Angabe einer anderen Form. Die Meldung zählt die erlaubten auf. |
| `… gibt es schon` | Kennung doppelt. Fähigkeiten mit dem Klassennamen beginnen lassen. |
| `datei.py, Zeile n: SyntaxError …` | Python-Fehler in der Inhaltsdatei selbst. |
| Hinweis `hat n aktive Fähigkeiten, die anderen Klassen haben 20` | Die Klasse ist dünner als vorgesehen (20 aktive, 9 passive). `test_spiel.py` verlangt das auch. |
| Hinweis `dieses Paar zündet nie` | Zu einer Kombo fehlt eine Fähigkeit, die den Zustand verursacht oder mit der Schadensart trifft. |
| Hinweis `liegt mitten im Gegnergebiet` | Start oder Bewohner aus dem `rect` der Zone herausnehmen. |
| Hinweis `enthält noch n Platzhalter (TODO)` | Texte schreiben. |

## Vor der Abgabe

- [ ] `python tools/pruefen.py` meldet „Inhalte in Ordnung“ und **keine Hinweise**
- [ ] `python tools/pruefen.py --spiel` meldet „Probelauf in Ordnung“
- [ ] `python test_spiel.py` endet mit „ALLE PRÜFUNGEN BESTANDEN“
- [ ] Neue Karte mit `--karte ID` angesehen: Start, Bewohner und Übergänge liegen, wo sie sollen;
      der Start liegt außerhalb der Gegnergebiete
- [ ] Jede Beschreibung einer Fähigkeit stimmt mit ihren Werten überein
- [ ] `game/engine.py` und `static/js/` sind unverändert (oder die Aufgabe hat es verlangt)
- [ ] Im Bericht steht, was du nur per Prüfwerkzeug und was du im Browser gesehen hast
