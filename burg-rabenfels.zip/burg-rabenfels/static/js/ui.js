// Anzeige im Spiel: Balken, Aktionsleiste, Quests, Dialoge, Charakterbogen, Skilltree, Chat, Minimap.
const $ = id => document.getElementById(id);
const el = (tag, cls, text) => {
  const e = document.createElement(tag);
  if (cls) e.className = cls;
  if (text != null) e.textContent = text;
  return e;
};
const fmt = (n, digits = 0) => Number(n).toLocaleString('de-DE', { maximumFractionDigits: digits });
const pct = (n, digits = 0) => fmt(n * 100, digits) + ' %';

// Ein Symbol je Grundform einer Fähigkeit; die Farbe zeigt die Schadensart.
const ICONS = {
  melee: 'M5 19l3-3M7 21l-4-4M8 16L19 5l1-3-3 1L6 14',
  fire: 'M12 3c1 4 5 5 5 10a5 5 0 0 1-10 0c0-2 1-3 2-4 0 2 1 3 2 3 0-3-1-5 1-9z',
  arrow: 'M4 20L18 6M11 6h7v7M4 20l1-4M4 20l4-1',
  arc: 'M4 18C6 9 13 4 21 4M4 18l1-5M4 18l5-1M10 14l7-7',
  nova: 'M12 7a5 5 0 1 0 0 10a5 5 0 1 0 0-10M12 2v2M12 20v2M2 12h2M20 12h2M5 5l1.5 1.5M17.5 17.5L19 19M19 5l-1.5 1.5M6.5 17.5L5 19',
  shot: 'M4 20L18 6M11 6h7v7M4 20l1-4M4 20l4-1',
  blast: 'M6 16a3 3 0 1 0 6 0a3 3 0 1 0-6 0M12 13l8-8M15 15l5-5M10 10l5-5',
  zone: 'M12 4a8 8 0 1 0 0 16a8 8 0 1 0 0-16M12 9a3 3 0 1 0 0 6a3 3 0 1 0 0-6',
  dash: 'M3 12h11M10 6l6 6-6 6M20 5v14',
  chain: 'M13 2L5 13h6l-1 9 9-12h-6z',
  buff: 'M12 3l8 3v6c0 5-3.5 8-8 9-4.5-1-8-4-8-9V6zM12 9v6M9 12h6',
  heal: 'M5 19c0-9 5-14 14-14 0 9-5 14-14 14zM5 19L15 9',
  passive: 'M12 3l9 9-9 9-9-9zM12 8l4 4-4 4-4-4z',
  potion: 'M10 3h4M10 3v5l-4 8a4 4 0 0 0 4 5h4a4 4 0 0 0 4-5l-4-8V3M7.5 14h9',
  empty: 'M12 6v12M6 12h12',
};
const icon = (name, color) => {
  const svg = document.createElementNS('http://www.w3.org/2000/svg', 'svg');
  svg.setAttribute('viewBox', '0 0 24 24');
  const p = document.createElementNS('http://www.w3.org/2000/svg', 'path');
  p.setAttribute('d', ICONS[name] ?? ICONS.passive);
  if (color) svg.style.stroke = color;
  svg.append(p);
  return svg;
};

// Darf die Quest (wieder) angenommen werden? Gleiche Regeln wie auf dem Server.
export function questOpen(you, qid, D) {
  const q = D.quests[qid], st = you.quests[qid];
  if (st && !(st.s === 'done' && q.repeat)) return false;
  if (you.lvl < q.minlvl) return false;
  return !q.req || you.quests[q.req]?.s === 'done';
}

// Marke über dem Kopf eines Burgbewohners: ? = Belohnung abholen, ! = neue Quest
export function npcMark(you, npc, D) {
  let mark = '';
  for (const [qid, q] of Object.entries(D.quests)) {
    if (q.npc !== npc) continue;
    if (you.quests[qid]?.s === 'ready') return '?';
    if (questOpen(you, qid, D)) mark = '!';
  }
  return mark;
}

export class UI {
  constructor(D, npcs, act) {
    this.D = D; this.npcs = npcs; this.act = act;
    this.you = null; this.slots = {}; this.dialogNpc = null; this.zoneName = '';
    this.sel = null; this.tab = 'baum'; this.dungeon = null;
    this.map = $('minimap').getContext('2d');
    this.chatInput = $('chatinput');
    $('dlg-close').addEventListener('click', () => this.closeDialog());
    $('help-btn').addEventListener('click', () => this.toggleHelp());
    $('btn-sheet').addEventListener('click', () => this.toggleWin('sheet'));
    $('btn-tree').addEventListener('click', () => this.toggleWin('tree'));
    for (const b of document.querySelectorAll('.win .x')) b.addEventListener('click', () => this.closeWins());
    for (const b of document.querySelectorAll('#tree-tabs button')) b.addEventListener('click', () => { this.tab = b.dataset.tab; this.renderTree(); });
  }

  skillColor(sk) { return sk.color ?? this.D.tags[sk.tag ?? 'hilfe'].color; }
  skillIcon(sk) { return icon(sk.type === 'passive' ? 'passive' : sk.form, this.skillColor(sk)); }
  resName() { return this.D.resNames[this.D.classes[this.you.cls].res]; }

  // ------------------------------------------------------- Aktionsleiste
  buildBar(cls) {
    const c = this.D.classes[cls], bar = $('bar');
    bar.replaceChildren();
    this.slots = {};
    const slot = (id, key) => {
      const s = el('div', 'slot');
      const ic = el('span', 'ic'), cd = el('div', 'cd'), count = el('span', 'count');
      s.append(ic, cd, count, el('span', 'key', key));
      bar.append(s);
      this.slots[id] = { s, ic, cd, count };
    };
    slot('atk', 'Maus');
    for (let i = 1; i <= 4; i++) slot('s' + i, String(i));
    slot('pot', 'Q');
    this.slots.atk.ic.append(icon(c.atk.type === 'melee' ? 'melee' : c.atk.kind, this.D.tags[c.atk.tag].color));
    this.slots.atk.s.title = c.atk.name;
    this.slots.pot.ic.append(icon('potion'));
    this.slots.pot.s.title = 'Heiltrank';
  }

  // cds: Endzeitpunkt je Fähigkeit, len: zugehörige Dauer; res: aktueller Vorrat an Mana/Ausdauer
  tickCooldowns(now, cds, len, res) {
    const you = this.you;
    for (const id of ['s1', 's2', 's3', 's4', 'pot']) {
      const sl = this.slots[id];
      const key = id === 'pot' ? 'potion' : you.bar[+id[1] - 1];
      const left = key ? Math.max(0, (cds[key] ?? 0) - now) : 0;
      const p = left > 0 ? Math.max(1, Math.round(left / (len[key] || 1) * 100)) : 0;
      const poor = id !== 'pot' && !!key && res < this.D.skills[key].cost;
      if (sl.p !== p) { sl.p = p; sl.cd.style.setProperty('--p', p + '%'); sl.s.classList.toggle('ready', p === 0 && !!key); }
      if (sl.poor !== poor) { sl.poor = poor; sl.s.classList.toggle('poor', poor); }
    }
  }

  // Aktive Elixiere unter der Questliste, mit Restzeit (läuft im Browser herunter)
  renderElixirs() {
    const box = $('elixirs'), now = performance.now() / 1000;
    if (!box) return;
    const live = Object.entries(this.elixirsUntil ?? {}).filter(([, t]) => t > now);
    box.hidden = !live.length;
    box.replaceChildren(...live.map(([k, t]) => {
      const left = Math.round(t - now), row = el('div', 'elx');
      row.append(el('b', null, this.D.elixirs[k].name), el('span', null, `${Math.floor(left / 60)}:${String(left % 60).padStart(2, '0')}`));
      row.title = this.D.elixirs[k].desc;
      return row;
    }));
    if (live.length && !this.elixTimer) this.elixTimer = setInterval(() => this.renderElixirs(), 1000);
    if (!live.length && this.elixTimer) { clearInterval(this.elixTimer); this.elixTimer = null; }
  }

  // ------------------------------------------------------ Eigene Werte
  setYou(you) {
    const barChanged = !this.you || this.you.bar.join() !== you.bar.join();
    this.you = you;
    const c = this.D.classes[you.cls];
    $('pname').textContent = `${you.name}, ${c.name}`;
    $('lvl').textContent = you.lvl;
    $('gold').textContent = fmt(you.gold);
    if (you.xpn) {
      $('xp-fill').style.width = Math.min(100, you.xp / you.xpn * 100) + '%';
      $('xp-text').textContent = `${fmt(you.xp)} / ${fmt(you.xpn)} EP`;
    } else { $('xp-fill').style.width = '100%'; $('xp-text').textContent = 'Höchste Stufe'; }
    $('ap-badge').textContent = you.ap > 0 ? '+' + you.ap : '';
    $('sp-badge').textContent = you.sp > 0 ? '+' + you.sp : '';
    $('res-fill').className = c.res;
    if (barChanged) {
      you.bar.forEach((key, i) => {
        const sl = this.slots['s' + (i + 1)], sk = key && this.D.skills[key];
        sl.ic.replaceChildren(sk ? this.skillIcon(sk) : icon('empty'));
        sl.s.classList.toggle('empty', !sk);
        sl.s.title = sk ? `${sk.name} – ${sk.desc}` : 'Frei. Im Fähigkeitenfenster (K) belegen.';
        sl.p = undefined;
      });
    }
    this.elixirsUntil = Object.fromEntries(Object.entries(you.elix ?? {}).map(([k, t]) => [k, performance.now() / 1000 + t]));
    this.renderElixirs();
    this.slots.pot.count.textContent = you.pot;
    this.slots.pot.s.classList.toggle('empty', you.pot === 0);
    this.renderQuests();
    if (this.dialogNpc) this.renderDialog();
    if (!$('sheet').hidden) this.renderSheet();
    if (!$('tree').hidden) this.renderTree();
  }

  setVitals(hp, mhp, res, resmax) {
    if (hp !== this.hp || mhp !== this.mhp) {
      this.hp = hp; this.mhp = mhp;
      $('hp-fill').style.width = Math.max(0, hp / mhp * 100) + '%';
      $('hp-text').textContent = `${fmt(hp)} / ${fmt(mhp)}`;
    }
    if (res !== this.res || resmax !== this.resmax) {
      this.res = res; this.resmax = resmax;
      $('res-fill').style.width = Math.max(0, res / resmax * 100) + '%';
      $('res-text').textContent = `${res} / ${resmax} ${this.resName()}`;
    }
  }

  reward(q) {
    const you = this.you;
    return { xp: q.xp ?? Math.round(you.xpn * (q.xp_pct ?? 0)), gold: q.gold ?? (q.gold_lvl ?? 0) * you.lvl };
  }

  progress(q, st) {
    return q.type === 'depth' ? `Tiefste geschaffte Ebene: ${st.n} von ${q.count}` : `${q.goal} ${st.n}/${q.count}`;
  }

  renderQuests() {
    const box = $('quests'), D = this.D;
    box.replaceChildren();
    for (const [qid, st] of Object.entries(this.you.quests)) {
      if (st.s === 'done') continue;
      const q = D.quests[qid], row = el('div', 'q' + (st.s === 'ready' ? ' ready' : ''));
      row.append(el('b', null, q.title));
      if (st.s === 'ready') row.append(el('span', null, `Erfüllt – zurück zu ${this.npcs[q.npc].name}`));
      else row.append(el('span', null, this.progress(q, st)), el('em', null, q.where));
      box.append(row);
    }
    if (!box.children.length) {
      const row = el('div', 'q');
      const open = Object.keys(D.quests).filter(qid => questOpen(this.you, qid, D));
      const next = open.find(qid => !D.quests[qid].repeat) ?? open[0];       // erst die Geschichte, dann Wiederholbares
      row.append(el('b', null, 'Keine Quest'), el('span', null, next ? `${this.npcs[D.quests[next].npc].name} hat Arbeit für dich.` : 'Im Augenblick ist alles getan.'));
      box.append(row);
    }
  }

  // Alle Helden im Spiel; wer auf einer anderen Karte ist, steht mit deren Namen da
  setParty(players, here) {
    const sig = players.map(p => p.name + p.lvl + p.map).join('|') + here;
    if (sig === this.partySig) return;
    this.partySig = sig;
    const box = $('party');
    box.replaceChildren(el('b', null, players.length === 1 ? 'Du bist allein in der Burg' : `${players.length} Abenteurer in der Burg`));
    if (players.length > 1) for (const p of players) {
      const row = el('div', null, p.name + ' ');
      row.style.color = this.D.classes[p.cls].color;
      row.append(el('i', null, 'St. ' + p.lvl + (p.map !== here ? ', ' + this.D.maps[p.map].name : '')));
      box.append(row);
    }
  }

  // Stand des Verlieses auf dieser Karte: [Ebene, lebende Gegner, Phase, nächste Start-Ebene] – oder null
  setDungeon(info) {
    const sig = info ? info.join() : '';
    if (sig === this.dungeonSig) return;
    this.dungeonSig = sig; this.dungeon = info;
    const box = $('cata');
    box.hidden = !info;
    if (!info) return;
    const [depth, alive, phase, start] = info;
    box.textContent = phase === 'fight' ? `Ebene ${depth} – noch ${alive} Gegner`
      : phase === 'cleared' ? `Ebene ${depth} geschafft – die nächste erwacht gleich`
      : `Das Verlies ruht. Es erwacht auf Ebene ${start}.`;
    if (this.dialogNpc) this.renderDialog();
  }

  // --------------------------------------------------------- Meldungen
  toast(text, kind = 'info') {
    const now = performance.now();
    if (text === this.lastToast && now - this.lastToastAt < 2500) return;      // nicht dieselbe Meldung stapeln
    this.lastToast = text; this.lastToastAt = now;
    const t = el('div', 'toast ' + kind, text), box = $('toasts');
    box.append(t);
    while (box.children.length > 4) box.firstChild.remove();
    setTimeout(() => t.classList.add('out'), 3600);
    setTimeout(() => t.remove(), 4100);
  }

  zone(name) {
    if (!name || name === this.zoneName) return;
    this.zoneName = name;
    $('zone').textContent = name;
    const b = $('zone-banner');
    b.textContent = name;
    b.classList.add('on');
    clearTimeout(this.zoneTimer);
    this.zoneTimer = setTimeout(() => b.classList.remove('on'), 2200);
  }

  hint(text) {
    const h = $('hint');
    if (text === this.hintText) return;
    this.hintText = text;
    h.hidden = !text;
    if (text) h.replaceChildren(el('kbd', null, 'E'), text);
  }

  death(seconds) {
    $('death').hidden = seconds <= 0;
    if (seconds > 0) $('death-timer').textContent = `Noch ${Math.ceil(seconds)} …`;
  }

  lost(on) { $('lost').hidden = !on; }
  toggleHelp(force) { const h = $('help'); h.hidden = force != null ? !force : !h.hidden; }

  chat(msg) {
    const log = $('chatlog'), p = el('p', msg.sys ? 'sys' : null);
    if (msg.sys) p.textContent = msg.text;
    else {
      const b = el('b', null, msg.name + ': ');
      b.style.color = this.D.classes[msg.cls]?.color ?? '';
      p.append(b, msg.text);
    }
    log.append(p);
    while (log.children.length > 40) log.firstChild.remove();
  }

  // ----------------------------------------------------------- Fenster
  toggleWin(id) {
    const w = $(id), open = w.hidden;
    this.closeWins();
    if (!open) return;
    w.hidden = false;
    if (id === 'sheet') this.renderSheet(); else this.renderTree();
  }
  closeWins() { $('sheet').hidden = true; $('tree').hidden = true; }
  anyWin() { return !$('sheet').hidden || !$('tree').hidden; }

  // ------------------------------------------------------ Charakterbogen
  renderSheet() {
    const D = this.D, you = this.you, c = D.classes[you.cls], s = you.stats, body = $('sheet-body');
    body.replaceChildren();
    const left = el('div', 'attrs'), right = el('dl', 'derived');
    left.append(el('p', 'points', you.ap > 0 ? `${you.ap} ${you.ap === 1 ? 'Attributpunkt' : 'Attributpunkte'} zu vergeben` : 'Alle Attributpunkte sind vergeben. Jede neue Stufe bringt drei weitere.'));
    for (const [key, a] of Object.entries(D.attrs)) {
      const row = el('div', 'attr' + (key === c.main ? ' main' : ''));
      const head = el('div', 'attr-head');
      head.append(el('b', null, a.name), el('span', 'val', you.attrs[key]));
      for (const n of [1, 5]) {
        const b = el('button', null, '+' + n);
        b.type = 'button'; b.disabled = you.ap < n;
        b.addEventListener('click', () => this.act.attr(key, n));
        head.append(b);
      }
      row.append(head, el('p', null, a.desc + (key === c.main ? ' Dein Hauptattribut.' : '')));
      left.append(row);
    }
    const line = (name, value) => { const d = el('div'); d.append(el('dt', null, name), el('dd', null, value)); right.append(d); };
    line('Leben', fmt(s.hp));
    line(this.resName(), `${fmt(s.res)}, +${fmt(s.resregen, 1)} je Sekunde`);
    line('Angriffskraft', fmt(s.power, 1));
    line('Kritische Treffer', pct(s.crit, 1));
    line('Kritischer Schaden', pct(s.critdmg));
    line('Rüstung', `${pct(s.armor, 1)} weniger Schaden`);
    line('Lauftempo', fmt(s.speed, 2));
    line('Angriffstempo', '+' + pct(s.haste));
    line('Abklingzeiten', '−' + pct(s.cdr, 1));
    line('Lebensregeneration', `${fmt(s.hpregen, 1)} je Sekunde`);
    line('Kombo-Zusatzschaden', '×' + fmt(s.combo, 2));
    line('Waffe und Rüstung', `Stufe ${you.wpn} und ${you.arm} von ${D.gearMax}`);
    for (const [mid, dn] of Object.entries(you.dungeons)) line(`Tiefste Ebene: ${D.maps[mid].name}`, dn.deep ? String(dn.deep) : 'noch keine');
    body.append(left, right);
    body.append(this.renderGear());
    const who = this.whoOffers('respec');
    body.append(el('p', 'foot', 'Verteilte Punkte bleiben.' + (who ? ` ${who} setzt Attribute und Fähigkeiten gegen Gold zurück.` : '')));
  }

  // Ein Ring oder Amulett als Karte: Name in der Farbe der Seltenheit, Werte, Knöpfe
  itemCard(it, buttons) {
    const D = this.D, r = D.rarities[it.rar], card = el('div', 'item');
    const name = el('b', null, it.name); name.style.color = r.color;
    card.append(name, el('small', null, `${r.name} · Stufe ${it.lvl}`));
    const ul = el('ul');
    for (const [k, v] of Object.entries(it.mods)) ul.append(el('li', null, `+${pct(v, 1)} ${D.itemStats[k]}`));
    card.append(ul);
    for (const [label, enabled, fn] of buttons) {
      const b = el('button', null, label); b.type = 'button'; b.disabled = !enabled;
      b.addEventListener('click', fn); card.append(b);
    }
    return card;
  }

  renderGear() {
    const D = this.D, you = this.you, box = el('div', 'gear');
    box.append(el('h3', null, 'Ausrüstung'));
    const slots = el('div', 'slots');
    for (const [slot, name] of Object.entries(D.itemSlots)) {
      const it = you.items?.[slot];
      if (it) slots.append(this.itemCard(it, [['Ablegen', (you.bag?.length ?? 0) < D.bagMax, () => this.act.item('unequip', { slot })]]));
      else { const e = el('div', 'item empty'); e.append(el('b', null, name), el('small', null, 'Nichts angelegt')); slots.append(e); }
    }
    box.append(slots);
    const bag = you.bag ?? [];
    box.append(el('h3', null, `Tasche (${bag.length} von ${D.bagMax})`));
    if (!bag.length) box.append(el('p', 'foot', 'Gegner lassen manchmal Ringe und Amulette fallen – Elite-Gegner oft, Bosse immer.'));
    const list = el('div', 'slots');
    bag.forEach((it, i) => {
      const worn = you.items?.[it.slot];
      const card = this.itemCard(it, [['Anlegen', true, () => this.act.item('equip', { i })],
                                      [`Verkaufen (${fmt(it.lvl * this.sellRate(it))} Gold)`, true, () => this.act.item('sell', { i })]]);
      if (worn) card.title = 'Angelegt: ' + worn.name + ' – ' + Object.entries(worn.mods).map(([k, v]) => `+${pct(v, 1)} ${D.itemStats[k]}`).join(', ');
      list.append(card);
    });
    box.append(list);
    return box;
  }

  sellRate(it) { return this.D.rarities[it.rar]?.sell ?? 4; }

  // ----------------------------------------------------------- Skilltree
  branchPoints(branch) {
    const you = this.you;
    return Object.entries(you.skills).reduce((n, [k, r]) => n + (this.D.skills[k].branch === branch ? r : 0), 0);
  }

  // Warum sich ein Knoten (noch) nicht lernen lässt – oder null, wenn es geht
  blocked(sk) {
    const you = this.you, rank = you.skills[sk.id] ?? 0, c = this.D.classes[you.cls];
    if (rank >= this.D.maxRank) return 'Höchste Stufe erreicht';
    if (you.lvl < sk.lvl) return `Ab Stufe ${sk.lvl}`;
    if (rank === 0 && this.branchPoints(sk.branch) < sk.need) return `Braucht ${sk.need} ${sk.need === 1 ? 'Punkt' : 'Punkte'} im Zweig ${c.branches[sk.branch].name}`;
    if (you.sp < 1) return 'Kein Fähigkeitspunkt frei';
    return null;
  }

  renderTree() {
    const D = this.D, you = this.you, c = D.classes[you.cls], body = $('tree-body');
    for (const b of document.querySelectorAll('#tree-tabs button')) b.classList.toggle('on', b.dataset.tab === this.tab);
    $('tree-points').textContent = you.sp > 0 ? `${you.sp} ${you.sp === 1 ? 'Punkt' : 'Punkte'} frei` : 'Kein Punkt frei';
    body.replaceChildren();
    body.className = this.tab;
    if (this.tab === 'kombos') return this.renderCombos(body);
    const cols = el('div', 'branches');
    c.branches.forEach((br, bi) => {
      const col = el('div', 'branch');
      col.append(el('h3', null, br.name), el('p', 'sub', `${br.desc} – ${this.branchPoints(bi)} ${this.branchPoints(bi) === 1 ? 'Punkt' : 'Punkte'}`));
      const nodes = Object.values(D.skills).filter(s => s.cls === you.cls && s.branch === bi).sort((a, b) => a.lvl - b.lvl);
      for (const sk of nodes) {
        const rank = you.skills[sk.id] ?? 0, why = this.blocked(sk);
        const b = el('button', 'node ' + sk.type + (rank ? ' learned' : '') + (!why ? ' avail' : '') + (this.sel === sk.id ? ' sel' : ''));
        b.type = 'button';
        const slot = you.bar.indexOf(sk.id);
        b.append(this.skillIcon(sk), el('span', 'nm', sk.name),
          el('span', 'rk', rank ? `${rank}/${D.maxRank}` : you.lvl < sk.lvl ? `St. ${sk.lvl}` : ''));
        if (slot >= 0) b.append(el('span', 'bound', String(slot + 1)));
        b.addEventListener('click', () => { this.sel = sk.id; this.renderTree(); });
        col.append(b);
      }
      cols.append(col);
    });
    body.append(cols, this.renderDetail());
  }

  renderDetail() {
    const D = this.D, you = this.you, c = D.classes[you.cls], box = el('aside', 'detail');
    const sk = D.skills[this.sel];
    if (!sk || sk.cls !== you.cls) {
      box.append(el('h3', null, 'Dein Skilltree'),
        el('p', null, 'Jede Stufe bringt einen Fähigkeitspunkt. Wähle links eine Fähigkeit, um sie zu lernen, zu verbessern oder auf eine der Tasten 1 bis 4 zu legen.'),
        el('p', null, 'Zwanzig aktive Fähigkeiten stehen zur Wahl, vier davon trägst du im Kampf. Rauten sind passive Fähigkeiten: Sie wirken immer.'),
        el('p', null, 'Tiefer im Zweig stehende Fähigkeiten verlangen, dass du schon Punkte in diesen Zweig gesteckt hast.'));
      return box;
    }
    const rank = you.skills[sk.id] ?? 0, shown = Math.max(1, rank), power = 1 + D.rankBonus * (shown - 1);
    const tag = D.tags[sk.tag ?? 'hilfe'];
    box.append(el('h3', null, sk.name));
    const kind = el('p', 'kind', sk.type === 'passive' ? 'Passive Fähigkeit' : 'Aktive Fähigkeit');
    if (sk.type === 'active' && sk.tag && sk.tag !== 'hilfe') {
      const chip = el('span', 'chip', tag.name);
      chip.style.color = tag.color;
      kind.append(' ', chip);
    }
    box.append(kind);
    if (sk.type === 'passive') {
      const v = per => fmt(sk.per * per * 100, 1);
      box.append(el('p', null, sk.desc.replace('{v}', v(shown))));
      box.append(el('p', 'num', rank ? `Stufe ${rank} von ${D.maxRank}. Jede Stufe bringt ${v(1)} %.` : `Jede Stufe bringt ${v(1)} %, bis zu ${v(D.maxRank)} %.`));
    } else {
      box.append(el('p', null, sk.desc));
      const dl = el('dl', 'num');
      const line = (k, v) => { const d = el('div'); d.append(el('dt', null, k), el('dd', null, v)); dl.append(d); };
      if (sk.mult) {
        const n = sk.hits ?? sk.count ?? 1, each = pct(sk.mult * power);
        line('Schaden', (n > 1 ? `${n} × ${each}` : each) + (sk.tick ? ' je Treffer' : '') + ' der Angriffskraft');
      }
      if (sk.pct) line('Heilung', pct(sk.pct * power) + ' des Lebens');
      if (sk.absorb) line('Schild', pct(sk.absorb * power) + ' des Lebens');
      line('Kosten', sk.cost ? `${sk.cost} ${this.resName()}` : 'keine');
      line('Abklingzeit', fmt(sk.cd * (1 - you.stats.cdr), 1) + ' s');
      if (sk.r) line('Radius', fmt(sk.r, 1));
      if (rank) line('Stufe', `${rank} von ${D.maxRank}`);
      box.append(dl);
      const st = sk.apply && D.status.find(s => s.id === sk.apply);
      if (st) {
        const p = el('p', 'status');
        const pip = el('i', 'pip'); pip.style.background = st.color;
        p.append(pip, `Verursacht ${st.name}: ${st.desc}`);
        box.append(p);
      }
      // Welche Kombos diese Fähigkeit auslöst oder vorbereitet
      const names = id => D.status.find(s => s.id === id).name;
      const fires = D.combos.filter(k => k.pairs.some(([, t]) => t === sk.tag))
        .map(k => `${k.name} (auf ${k.pairs.filter(([, t]) => t === sk.tag).map(([s]) => names(s)).join(' oder ')})`);
      const primes = D.combos.filter(k => k.pairs.some(([s]) => s === sk.apply)).map(k => k.name);
      if (fires.length && sk.mult) box.append(el('p', 'combo', 'Löst aus: ' + fires.join(', ')));
      if (primes.length) box.append(el('p', 'combo', 'Bereitet vor: ' + primes.join(', ')));
    }
    const why = this.blocked(sk);
    const learn = el('button', 'learn', rank ? 'Verbessern (1 Punkt)' : 'Lernen (1 Punkt)');
    learn.type = 'button'; learn.disabled = !!why;
    learn.addEventListener('click', () => this.act.learn(sk.id));
    box.append(learn);
    if (why) box.append(el('p', 'why', why + '.'));
    if (sk.type === 'active' && rank) {
      const bind = el('div', 'bind');
      bind.append(el('span', null, 'Auf Taste legen'));
      for (let i = 1; i <= 4; i++) {
        const b = el('button', you.bar[i - 1] === sk.id ? 'on' : null, String(i));
        b.type = 'button';
        b.title = you.bar[i - 1] ? `Belegt mit ${D.skills[you.bar[i - 1]].name}` : 'Frei';
        b.addEventListener('click', () => this.act.bind(i, you.bar[i - 1] === sk.id ? null : sk.id));
        bind.append(b);
      }
      box.append(bind);
    }
    return box;
  }

  renderCombos(body) {
    const D = this.D, you = this.you, c = D.classes[you.cls];
    body.append(el('p', 'lede', 'Manche Fähigkeiten hinterlassen einen Zustand auf dem Gegner. Trifft ihn danach die passende Schadensart, zündet die Kombo und verbraucht den Zustand. Wer den Zustand verursacht hat, ist egal – am stärksten seid ihr zu mehreren.'));
    const status = id => D.status.find(s => s.id === id);
    const mine = Object.values(D.skills).filter(s => s.cls === you.cls && s.type === 'active' && you.skills[s.id]);
    const table = el('div', 'combos');
    for (const k of D.combos) {
      const row = el('div', 'crow');
      const head = el('div', 'chead');
      head.append(el('b', null, k.name));
      const recipe = el('span', 'recipe');
      k.pairs.forEach(([s, t], i) => {
        if (i) recipe.append(' oder ');
        const pip = el('i', 'pip'); pip.style.background = status(s).color;
        const tg = el('span', 'chip', D.tags[t].name); tg.style.color = D.tags[t].color;
        recipe.append(pip, status(s).name + ' + ', tg);
      });
      head.append(recipe);
      row.append(head, el('p', null, k.desc));
      // Womit die eigene Klasse beitragen kann (gelernte Fähigkeiten und der Grundangriff)
      const tags = new Set(k.pairs.map(([, t]) => t)), stats = new Set(k.pairs.map(([s]) => s));
      const fire = mine.filter(s => tags.has(s.tag) && s.mult).map(s => s.name);
      if (tags.has(c.atk.tag)) fire.unshift(c.atk.name);
      const prime = mine.filter(s => stats.has(s.apply)).map(s => s.name);
      const own = [];
      if (prime.length) own.push('Du bereitest vor mit ' + prime.join(', '));
      if (fire.length) own.push((prime.length ? 'und löst aus mit ' : 'Du löst aus mit ') + fire.join(', '));
      row.append(el('p', 'own', own.length ? own.join(' ') + '.' : 'Dazu hast du noch keine passende Fähigkeit gelernt.'));
      table.append(row);
    }
    body.append(table);
    const legend = el('div', 'legend');
    legend.append(el('h3', null, 'Zustände und wer sie verursacht'));
    for (const st of D.status) {
      const p = el('p');
      const pip = el('i', 'pip'); pip.style.background = st.color;
      const by = Object.entries(D.classes).map(([cid, cl]) => {
        const n = Object.values(D.skills).filter(s => s.cls === cid && s.apply === st.id).length;
        return n ? `${cl.name} (${n})` : null;
      }).filter(Boolean).join(', ');
      p.append(pip, el('b', null, st.name + ' '), `${st.desc} Fähigkeiten: ${by}.`);
      legend.append(p);
    }
    body.append(legend);
  }

  // ----------------------------------------------------------- Dialoge
  openDialog(npc) { this.dialogNpc = npc; this.renderDialog(); $('dialog').hidden = false; }
  closeDialog() { this.dialogNpc = null; $('dialog').hidden = true; }

  renderDialog() {
    const D = this.D, you = this.you, id = this.dialogNpc, n = this.npcs[id];
    $('dlg-name').textContent = n.name;
    $('dlg-role').textContent = n.role;
    const body = $('dlg-body');
    body.replaceChildren(el('p', null, n.greet));
    const offer = (title, text, extra, buttons) => {
      const o = el('div', 'offer');
      o.append(el('h3', null, title), el('p', null, text));
      if (extra) o.append(el('p', 'reward', extra));
      for (const [label, enabled, fn] of buttons ?? []) {
        const b = el('button', null, label);
        b.type = 'button'; b.disabled = !enabled;
        b.addEventListener('click', fn);
        o.append(b);
      }
      body.append(o);
    };
    const reward = q => {
      const r = this.reward(q);
      return 'Belohnung: ' + [`${fmt(r.xp)} EP`, `${fmt(r.gold)} Gold`, q.potions && `${q.potions} Heiltränke`, q.weapon && 'eine Schmiedestufe'].filter(Boolean).join(', ');
    };
    for (const [qid, q] of Object.entries(D.quests)) {
      if (q.npc !== id) continue;
      const st = you.quests[qid];
      if (st?.s === 'ready') offer(q.title, q.done, reward(q), [['Belohnung annehmen', true, () => this.act.quest(qid, 'turnin')]]);
      else if (st?.s === 'active') offer(q.title, `Noch nicht geschafft. ${this.progress(q, st)}.`, 'Wo: ' + q.where);
      else if (questOpen(you, qid, D)) offer(q.title, q.text, reward(q), [['Quest annehmen', true, () => this.act.quest(qid, 'accept')]]);
      else if (!st && (!q.req || you.quests[q.req]?.s === 'done') && you.lvl < q.minlvl) {
        offer(q.title, `Dafür fehlt dir noch Erfahrung. Komm wieder, wenn du Stufe ${q.minlvl} erreicht hast.`);
      }
    }
    const P = you.prices, buy = item => () => this.act.shop(id, item);
    for (const item of D.shops[id] ?? []) {
      if (item === 'potion') {
        const full = you.pot >= D.potion.max;
        offer('Heiltrank', `Stellt fast die Hälfte deines Lebens wieder her. Du trägst ${you.pot} von ${D.potion.max}.`, null,
          [[full ? 'Mehr kannst du nicht tragen' : `Kaufen für ${fmt(P.potion)} Gold`, !full && you.gold >= P.potion, buy(item)]]);
      } else if (item === 'weapon' || item === 'armor') {
        const tier = item === 'weapon' ? you.wpn : you.arm, max = tier >= D.gearMax;
        offer(item === 'weapon' ? 'Waffe schmieden' : 'Rüstung schmieden',
          `${item === 'weapon' ? 'Jede Stufe bringt 4 % mehr Schaden.' : 'Jede Stufe bringt 3 % mehr Leben.'} Stufe ${tier} von ${D.gearMax}.`, null,
          [[max ? 'Besser geht es nicht' : `Schmieden für ${fmt(P[item])} Gold`, !max && you.gold >= P[item], buy(item)]]);
      } else if (item === 'elixir') {
        for (const [k, x] of Object.entries(D.elixirs)) {
          const left = Math.max(0, Math.round((this.elixirsUntil?.[k] ?? 0) - performance.now() / 1000));
          offer(x.name, `${x.desc}, zehn Minuten lang. Wirkt auch nach dem Abmelden weiter; ein zweites verlängert die Dauer.`,
            left ? `Wirkt noch ${Math.ceil(left / 60)} Minuten` : null,
            [[`Kaufen für ${fmt(P.elixir)} Gold`, you.gold >= P.elixir, () => this.act.shop(id, item, { kind: k })]]);
        }
      } else if (item === 'heal') {
        offer('Heilung', `${n.name} versorgt deine Wunden – so oft du willst.`, null, [['Heilen lassen', this.hp < this.mhp, buy(item)]]);
      } else if (item === 'respec') {
        offer('Neu verteilen', 'Setzt alle Attribut- und Fähigkeitspunkte zurück, damit du sie anders vergeben kannst.', null,
          [[`Zurücksetzen für ${fmt(P.respec)} Gold`, you.gold >= P.respec && you.lvl > 1, buy(item)]]);
      } else if (item === 'dungeon') {                        // Start-Ebene des Verlieses auf der Karte dieses Bewohners
        const [depth, , phase, start] = this.dungeon ?? [0, 0, 'idle', 1], idle = phase === 'idle';
        const mine = you.dungeons[n.map] ?? { deep: 0, steps: [1] };
        offer('Start-Ebene wählen',
          idle ? `Das Verlies ruht und erwacht auf Ebene ${start}, sobald jemand es betritt. Nach jedem Boss kannst du später auf der Ebene danach wieder einsteigen.`
               : `Im Verlies wird auf Ebene ${depth} gekämpft. Geh hinein, um mitzukämpfen – eine andere Ebene lässt sich erst wählen, wenn es ruht.`,
          mine.deep ? `Deine tiefste Ebene: ${mine.deep}` : null,
          mine.steps.map(d => [`Ebene ${d}`, idle && d !== start, () => this.act.shop(id, item, { depth: d })]));
      }
    }
  }

  // Name des ersten Bewohners, der einen Dienst anbietet ('potion', 'respec', …) – oder null
  whoOffers(service) {
    const id = Object.keys(this.D.shops).find(k => this.D.shops[k].includes(service));
    return id ? this.npcs[id].name : null;
  }

  // ----------------------------------------------------------- Minimap
  // mini: Grundbild der Karte samt Maßstab und Lage (siehe enterMap in main.js). 4 Pixel je Kachel = 2 je Welteinheit.
  drawMinimap(mini, me, players, enemies, npcs, picks) {
    const g = this.map, k = 2 * mini.scale;
    g.fillStyle = '#141217';
    g.fillRect(0, 0, g.canvas.width, g.canvas.height);
    g.drawImage(mini.base, mini.dx, mini.dy, mini.base.width * mini.scale, mini.base.height * mini.scale);
    const px = x => (x - mini.ox) * k + mini.dx, pz = z => (z - mini.oz) * k + mini.dy;
    const dot = (x, z, r, col) => { g.fillStyle = col; g.beginPath(); g.arc(px(x), pz(z), r, 0, 6.283); g.fill(); };
    for (const p of picks) dot(p.x, p.z, 2, '#9fe8ff');
    for (const e of enemies) dot(e.x, e.z, e.boss ? 4 : 2, e.boss ? '#c9a6ff' : '#e0453a');
    for (const n of npcs) dot(n.x, n.z, 3, n.mark ? '#ffd75a' : '#b99a55');
    for (const p of players) dot(p.x, p.z, 3, '#7fc4ff');
    g.save();
    g.translate(px(me.x), pz(me.z)); g.rotate(-me.rot);
    g.fillStyle = '#fff'; g.strokeStyle = '#000'; g.lineWidth = 1;
    g.beginPath(); g.moveTo(0, 6); g.lineTo(4, -4); g.lineTo(0, -2); g.lineTo(-4, -4); g.closePath(); g.fill(); g.stroke();
    g.restore();
  }
}
