// Burg Rabenfels – Spielablauf im Browser: Anmeldung, Netzwerk, Eingabe, Darstellung.
import * as THREE from 'three';
import { World } from './world.js';
import { figure, pickupModel, shotModel, zoneModel, animateModel, flashModel } from './entities.js';
import { Effects } from './effects.js';
import { UI, npcMark } from './ui.js';
import { Sfx } from './sfx.js';

const D = window.GAME_DATA;
const $ = id => document.getElementById(id);
const socket = io();
const sfx = new Sfx();
const clamp = (v, a, b) => Math.max(a, Math.min(b, v));
const lerpAngle = (a, b, k) => a + (((b - a + Math.PI) % (2 * Math.PI) + 2 * Math.PI) % (2 * Math.PI) - Math.PI) * k;
const secs = () => performance.now() / 1000;

// Spielzustand im Browser
const S = {
  joined: false, id: 0, you: null, me: null, name: '', cls: '',
  ents: new Map(), npcs: [], shots: new Map(), picks: new Map(), zones: new Map(), dying: [],
  keys: new Set(), mouse: { x: innerWidth / 2, y: innerHeight / 2, down: false }, aim: { x: 0, z: 0 },
  cd: { atk: 0 }, cdLen: { potion: D.potion.cd }, pending: 0, res: 0, cata: [0, 0, 'idle', 1],
  zoom: 1, deadUntil: 0, lastSend: 0, sent: { x: 0, z: 0, r: 0 }, zoneT: 0,
  map: null, mini: null,                   // Karte, auf der der Held steht, und ihr Minimap-Bild
  quality: 0, autoQuality: true, perf: { t: 0, n: 0, warm: 0 },
};
let renderer, scene, camera, world, fx, ui, meRing, aimRing;
const camT = new THREE.Vector3();

// Gegner schimmern in der Farbe ihres Zustands (Reihenfolge wie D.status); der erste gesetzte Zustand gewinnt
const hexRgb = hex => { const c = new THREE.Color(hex); return [c.r * 0.45, c.g * 0.45, c.b * 0.45]; };
const TINT = D.status.map(s => hexRgb(s.color));
const RAGE_TINT = t => [0.45 + Math.sin(t * 9) * 0.2, 0.02, 0.0];       // Boss in Raserei pulsiert rot
const tintOf = mask => {
  if (!mask) return null;
  for (let i = 0; i < TINT.length; i++) if (mask & (1 << i)) return TINT[i];
  return null;
};

// ================================================================ Torbuch
const classList = $('class-list');
for (const [id, c] of Object.entries(D.classes)) {
  const label = document.createElement('label');
  label.className = 'cls';
  const input = Object.assign(document.createElement('input'), { type: 'radio', name: 'cls', value: id });
  const name = document.createElement('b'); name.textContent = c.name;
  const what = Object.assign(document.createElement('span'), { className: 'what', textContent: c.desc });
  const can = Object.assign(document.createElement('span'), { className: 'can' });
  can.textContent = 'Zweige im Skilltree: ' + c.branches.map(b => b.name).join(', ');
  label.append(input, name, what, can);
  classList.append(label);
}
const savedCls = localStorage.getItem('rabenfels.klasse');
(classList.querySelector(`input[value="${savedCls}"]`) ?? classList.querySelector('input')).checked = true;
$('name-input').value = localStorage.getItem('rabenfels.name') ?? '';
$('enter-btn').disabled = true;

socket.on('connect', () => {
  $('conn').textContent = 'Die Wache erwartet dich.';
  $('enter-btn').disabled = false;
  if (S.joined) join(S.name, S.cls);               // nach Verbindungsabbruch wieder hinein
});
socket.on('disconnect', () => {
  $('conn').textContent = 'Keine Verbindung zur Burg. Läuft der Server noch?';
  $('enter-btn').disabled = true;
  if (S.joined) ui.lost(true);
});

$('ledger').addEventListener('submit', e => {
  e.preventDefault();
  sfx.unlock();
  const name = $('name-input').value.trim();
  const cls = classList.querySelector('input:checked').value;
  $('gate-error').textContent = '';
  join(name, cls);
});

function join(name, cls) {
  $('enter-btn').disabled = true;
  socket.emit('join', { name, cls }, res => {
    $('enter-btn').disabled = false;
    if (!res || res.error) {
      if (S.joined) location.reload();              // Wiedereinstieg gescheitert -> sauber neu anfangen
      $('gate-error').textContent = res?.error ?? 'Die Burg antwortet nicht.';
      return;
    }
    localStorage.setItem('rabenfels.name', name);
    localStorage.setItem('rabenfels.klasse', cls);
    S.name = name; S.cls = res.you.cls;
    start(res);
  });
}

// ============================================================== Spielstart
function start(res) {
  if (!world) initScene(res.world);
  for (const e of S.ents.values()) removeEnt(e);
  S.ents.clear();
  S.id = res.id; S.you = res.you; S.joined = true;
  S.me = makeEnt(res.id, 'p', res.you.cls, res.you.name);
  S.me.x = S.me.tx = res.x; S.me.z = S.me.tz = res.z;
  camT.set(res.x, 0, res.z);
  enterMap(world.mapAt(res.x, res.z));
  meRing.material.color.set(D.classes[res.you.cls].color);
  ui.buildBar(res.you.cls);
  ui.you = null;
  onYou(res.you);
  ui.lost(false);
  $('gate').hidden = true;
  $('hud').hidden = false;
  if (res.returning) ui.toast(`Willkommen zurück, ${res.you.name}.`);
  else {                                            // erster Auftrag: die erste Quest ohne Voraussetzung
    const first = Object.values(D.quests).find(q => !q.req && q.minlvl <= 1);
    if (first) ui.toast(`Sprich mit ${ui.npcs[first.npc].name} – dort wartet Arbeit auf dich.`, 'quest');
  }
  if (res.you.ap > 0 || res.you.sp > 0) ui.toast('Du hast Punkte zu vergeben: Charakterbogen (C) und Skilltree (K).', 'level');
  if (res.dev) ui.chat({ sys: true, text: 'Entwicklermodus: /tp x z, /tp karte x z, /lvl n, /gold n, /tiefe n, /beute n, /elite' });
}

function initScene(data) {
  renderer = new THREE.WebGLRenderer({ canvas: $('game'), antialias: true, powerPreference: 'high-performance' });
  renderer.setPixelRatio(Math.min(devicePixelRatio, 2));
  renderer.setSize(innerWidth, innerHeight, false);
  renderer.shadowMap.enabled = true;
  renderer.shadowMap.type = THREE.PCFShadowMap;
  renderer.toneMapping = THREE.ACESFilmicToneMapping;
  renderer.toneMappingExposure = 1.08;
  scene = new THREE.Scene();
  scene.background = new THREE.Color(0x11141d);
  scene.fog = new THREE.Fog(0x11141d, 48, 96);
  camera = new THREE.PerspectiveCamera(40, innerWidth / innerHeight, 1, 240);

  world = new World(scene, data, renderer);
  fx = new Effects(scene, $('labels'), project);
  const npcs = {};                                  // Bewohner aller Karten, jeder kennt seine Karte
  for (const m of data.maps) for (const [id, n] of Object.entries(m.npcs)) npcs[id] = { ...n, map: m.id };
  ui = new UI(D, npcs, {
    quest: (id, what) => { socket.emit('quest', { id, do: what }); sfx.play('talk'); },
    shop: (npc, item, extra) => socket.emit('shop', { npc, item, ...extra }),
    item: (act, extra) => socket.emit('item', { act, ...extra }),
    attr: (k, n) => socket.emit('attr', { k, n }),
    learn: id => { socket.emit('learn', { id }); sfx.play('quest'); },
    bind: (slot, id) => socket.emit('bind', { slot, id }),
  });

  // Bewohner: Aussehen kommt aus den Inhalten; zu sehen sind nur die der eigenen Karte
  for (const [id, n] of Object.entries(npcs)) {
    const model = figure(n.look);
    model.root.position.set(n.x, 0, n.z);
    model.root.visible = false;
    scene.add(model.root);
    const label = makeLabel('npc', n.name);
    S.npcs.push({ id, map: n.map, x: n.x, z: n.z, name: n.name, model, label, state: {}, mark: '', height: model.height });
  }

  // Ring unter der eigenen Figur (auch hinter Mauern sichtbar) und Zielmarke am Boden
  const ringMat = color => new THREE.MeshBasicMaterial({ color, transparent: true, opacity: 0.6, depthTest: false, depthWrite: false });
  meRing = new THREE.Mesh(new THREE.RingGeometry(0.58, 0.74, 32), ringMat(0xffffff));
  aimRing = new THREE.Mesh(new THREE.RingGeometry(0.16, 0.25, 20), ringMat(0xfff3d0));
  for (const r of [meRing, aimRing]) { r.rotation.x = -Math.PI / 2; r.renderOrder = 10; scene.add(r); }

  const savedQ = localStorage.getItem('rabenfels.grafik');
  if (savedQ !== null) { S.autoQuality = false; setQuality(+savedQ); }
  bindInput();
  addEventListener('resize', () => {
    renderer.setSize(innerWidth, innerHeight, false);
    camera.aspect = innerWidth / innerHeight;
    camera.updateProjectionMatrix();
  });
  requestAnimationFrame(frame);
}

// Der Held hat eine andere Karte betreten: Ansicht bauen oder zeigen, Minimap und Bewohner umstellen.
// m: Kartendaten vom Server (id, name, ox, oz, w, h, light ...)
function enterMap(m) {
  S.map = m.id;
  world.enter(m.id);
  sfx.ambient(D.maps[m.id]?.ambient);
  const base = world.minimap(m.id), cv = $('minimap');
  const scale = Math.min(cv.width / base.width, cv.height / base.height);
  S.mini = { base, scale, dx: (cv.width - base.width * scale) / 2, dy: (cv.height - base.height * scale) / 2, ox: m.ox * 2, oz: m.oz * 2 };
  for (const n of S.npcs) {
    n.model.root.visible = n.map === m.id;
    if (n.map !== m.id) placeLabel(n.label, 0, 0, 0, false);
  }
  ui.closeDialog();
  S.perf.t = S.perf.n = 0; S.perf.warm = 0;         // der Aufbau einer Karte zählt nicht als schlechte Bildrate
}

// Grafikstufen: Das Spiel schaltet auf schwächeren Rechnern selbst herunter, Taste G wählt von Hand.
const QUALITY = [
  { name: 'hoch', ratio: () => Math.min(devicePixelRatio, 2), shadows: true, lights: 6 },
  { name: 'mittel', ratio: () => 1, shadows: true, lights: 6 },
  { name: 'niedrig', ratio: () => 1, shadows: false, lights: 4 },
  { name: 'sehr niedrig', ratio: () => 0.6, shadows: false, lights: 3 },
];
function setQuality(q, how) {
  S.quality = clamp(q | 0, 0, QUALITY.length - 1);
  const Q = QUALITY[S.quality];
  renderer.setPixelRatio(Q.ratio());
  renderer.setSize(innerWidth, innerHeight, false);
  world.sun.castShadow = Q.shadows;
  world.pool.forEach((l, i) => { l.visible = i < Q.lights; });
  S.perf.t = S.perf.n = 0; S.perf.warm = -2;
  if (how === 'manual') { S.autoQuality = false; localStorage.setItem('rabenfels.grafik', S.quality); ui.toast(`Grafik: ${Q.name}`); }
  if (how === 'auto') ui.toast(`Grafik auf „${Q.name}“ gestellt, damit es flüssig läuft. Taste G ändert das.`);
}

// ============================================================ Namensschilder
const pv = new THREE.Vector3(), pr = { x: 0, y: 0, ok: false };
function project(x, y, z) {
  pv.set(x, y, z).project(camera);
  pr.x = (pv.x * 0.5 + 0.5) * innerWidth;
  pr.y = (-pv.y * 0.5 + 0.5) * innerHeight;
  pr.ok = pv.z < 1 && Math.abs(pv.x) < 1.1 && Math.abs(pv.y) < 1.15;
  return pr;
}

function makeLabel(cls, name) {
  const el = document.createElement('div');
  el.className = 'lbl ' + cls;
  const mark = document.createElement('span'); mark.className = 'mark';
  const nm = document.createElement('div'); nm.className = 'nm'; nm.textContent = name;
  const hb = document.createElement('div'); hb.className = 'hb';
  const fill = document.createElement('i'); hb.append(fill);
  const pips = document.createElement('span'); pips.className = 'pips';
  el.append(mark, nm);
  if (cls !== 'npc') el.append(hb);
  if (cls.startsWith('enemy')) el.append(pips);
  el.style.display = 'none';
  $('labels').append(el);
  return { el, nm, fill, mark, pips, shown: false, w: -1, mask: 0 };
}

function placeLabel(l, x, y, z, show) {
  const p = show ? project(x, y, z) : pr;
  const on = show && p.ok;
  if (on !== l.shown) { l.shown = on; l.el.style.display = on ? '' : 'none'; }
  if (on) l.el.style.transform = `translate(${p.x.toFixed(1)}px, ${p.y.toFixed(1)}px) translate(-50%, -100%)`;
}

function nameWithLevel(label, name, lvl, elite) {
  label.nm.textContent = name;
  label.nm.append(Object.assign(document.createElement('small'), { textContent: (elite ? `Elite · ${D.elites[elite]} · ` : '') + 'St. ' + lvl }));
}

// ================================================================ Figuren
function makeEnt(id, type, kind, name, elite = '') {
  const model = figure(type === 'p' ? D.classes[kind].look : D.enemies[kind].look);
  if (elite) model.root.scale.multiplyScalar(1.2);          // Elite-Gegner sind etwas größer
  scene.add(model.root);
  const boss = type === 'e' && D.enemies[kind].boss;
  const e = { id, type, kind, name, model, boss, elite, x: 0, z: 0, rot: 0, tx: 0, tz: 0, trot: 0, hp: 1, mhp: 1, lvl: 0, flags: 0, mask: 0,
    state: {}, flash: 0, height: model.height * (elite ? 1.2 : 1), label: null, fresh: true };
  if (id !== S.id) {
    e.label = makeLabel(type === 'p' ? 'player' : boss ? 'enemy boss' : elite ? 'enemy elite' : 'enemy', name);
    if (type === 'p') e.label.nm.style.color = D.classes[kind].color;
  }
  S.ents.set(id, e);
  return e;
}

function removeEnt(e) {
  scene.remove(e.model.root);
  e.label?.el.remove();
  S.ents.delete(e.id);
}

function startAtk(id, kind, dur = 0.3) {
  const e = S.ents.get(id);
  if (!e || (id === S.id && e.state.atk)) return;
  e.state.atk = { t: 0, dur: kind === 'spin' ? 0.4 : dur, kind };
}

// ================================================================= Netzwerk
socket.on('state', s => {
  if (!S.joined) return;
  const seen = new Set();
  for (const [id, name, cls, x, z, rot, hp, mhp, lvl, flags, res, resmax] of s.p) {
    let e = S.ents.get(id);
    if (!e) e = makeEnt(id, 'p', cls, name);
    seen.add(id);
    if (e.lvl !== lvl && e.label) nameWithLevel(e.label, name, lvl);
    e.hp = hp; e.mhp = mhp; e.lvl = lvl; e.flags = flags;
    if (id === S.id) { S.res = res; ui.setVitals(hp, mhp, res, resmax); continue; }
    e.tx = x; e.tz = z; e.trot = rot;
    if (e.fresh) { e.x = x; e.z = z; e.rot = rot; e.fresh = false; }
  }
  for (const [id, kind, x, z, rot, hp, mhp, flags, lvl, mask, elite] of s.e) {
    let e = S.ents.get(id);
    if (e && (e.elite || '') !== (elite || '')) removeEnt(e), e = null;     // als Elite wiedergekehrt
    if (!e) e = makeEnt(id, 'e', kind, D.enemies[kind].name, elite);
    seen.add(id);
    if (e.lvl !== lvl) nameWithLevel(e.label, e.name, lvl, e.elite);
    e.tx = x; e.tz = z; e.trot = rot; e.hp = hp; e.mhp = mhp; e.flags = flags; e.lvl = lvl; e.mask = mask;
    if (e.fresh) { e.x = x; e.z = z; e.rot = rot; e.fresh = false; }
  }
  for (const f of s.fx) onFx(f);
  for (const e of [...S.ents.values()]) if (!seen.has(e.id) && e.id !== S.id) removeEnt(e);

  sync(S.shots, s.s, ([, kind, , , , c]) => { const g = shotModel(kind, c); scene.add(g); return { g, kind, c }; },
    (o, [, , x, z, rot], fresh) => { o.tx = x; o.tz = z; o.g.rotation.y = rot; if (fresh) { o.x = x; o.z = z; } });
  sync(S.picks, s.k, ([, kind, x, z]) => { const m = pickupModel(D.pickups[kind]); m.root.position.set(x, 0, z); scene.add(m.root); return { g: m.root, m, x, z, kind }; }, () => {});
  sync(S.zones, s.z, ([, , , r, c]) => { const m = zoneModel(r, c); scene.add(m.root); return { g: m.root, m }; },
    (o, [, x, z]) => o.g.position.set(x, 0, z));
  S.cata = s.c;                                    // Verlies dieser Karte (oder null)
  ui.setParty(s.r.map(([name, cls, lvl, map]) => ({ name, cls, lvl, map })), S.map);
});

// Gleicht eine Map von 3D-Objekten mit einer Liste [id, ...] vom Server ab
function sync(map, list, create, update) {
  const seen = new Set();
  for (const row of list) {
    let o = map.get(row[0]);
    const fresh = !o;
    if (fresh) { o = create(row); map.set(row[0], o); }
    update(o, row, fresh);
    seen.add(row[0]);
  }
  for (const [id, o] of map) if (!seen.has(id)) { scene.remove(o.g); map.delete(id); }
}

socket.on('you', onYou);
function onYou(you) {
  const before = S.you;
  S.you = you;
  ui.setYou(you);
  if (you.dead) S.deadUntil = secs() + you.dead;
  for (const n of S.npcs) {
    n.mark = npcMark(you, n.id, D);
    n.label.mark.textContent = n.mark;
  }
  if (before && you.pot > before.pot) sfx.play('pick');
}

socket.on('correct', d => {
  if (!S.me) return;
  S.me.x = d.x; S.me.z = d.z;
  if (d.tp) camT.set(d.x, 0, d.z);
});
socket.on('toast', t => { ui.toast(t.text, t.kind); if (t.kind === 'quest') sfx.play('quest'); if (t.kind === 'warn') sfx.play('warn'); });
socket.on('chat', m => ui?.chat(m));

const statusColor = id => D.status.find(s => s.id === id)?.color;

function vol(x, z) {                                // Lautstärke nach Entfernung
  return clamp(1 - Math.hypot(x - S.me.x, z - S.me.z) / 26, 0, 1);
}

function onFx(f) {
  const e = f.id ? S.ents.get(f.id) : null, mine = f.id === S.id;
  switch (f.t) {
    case 'dmg':
      if (f.p) {
        if (e) e.flash = 1;
        fx.text(f.x, 2.3, f.z, '-' + f.v, 'hurt');
        if (mine) { fx.shake = Math.min(1, fx.shake + 0.4); sfx.play('hurt'); }
      } else if (f.s) {                              // Brand, Blutung, Gift
        fx.text(f.x, (e?.height ?? 1.4) + 0.2, f.z, String(f.v), 'dot', 0.8, statusColor(f.s));
      } else {
        if (e) e.flash = 1;
        fx.text(f.x, (e?.height ?? 1.4) + 0.5, f.z, String(f.v), f.c ? 'crit' : '');
        fx.burst(f.x, 0.9, f.z, 0xffe6c0, f.c ? 7 : 3, 3.5);
        sfx.play('hit', vol(f.x, f.z));
      }
      break;
    case 'miss': fx.text(f.x, 2, f.z, 'weicht aus', 'miss'); break;
    case 'block': if (e) fx.text(e.x, 2.4, e.z, 'abgefangen', 'block'); break;
    case 'slash':
      if (!mine || f.sk) fx.slash(f.x, f.z, f.a, f.r, f.c ?? 0xfff0cf, f.w ?? 2);
      if (!mine) { startAtk(f.id, 'melee'); sfx.play('swing', vol(f.x, f.z) * 0.7); } else if (f.sk) sfx.play('swing');
      break;
    case 'atk':
      startAtk(f.id, f.k);
      if (!mine && e) sfx.play(f.k === 'shoot' ? 'shoot' : f.k === 'cast' ? 'fire' : 'swing', vol(e.x, e.z) * 0.6);
      break;
    case 'eatk': if (e) e.state.atk = { t: 0, dur: 0.5, kind: f.k ?? (e.model.kind === 'quad' ? 'bite' : 'melee') }; break;
    case 'edie': {
      if (e) {
        S.ents.delete(e.id); e.label?.el.remove();
        e.state.dead = true; e.state.atk = null; e.state.moving = false;
        S.dying.push({ e, t: 0 });
      }
      const big = D.enemies[f.k]?.boss;
      const dust = D.enemies[f.k]?.dust ?? '#cccccc';
      fx.burst(f.x, 0.8, f.z, dust, big ? 40 : 10, big ? 9 : 4.5);
      if (big) { fx.ring(f.x, f.z, 7, dust, 1.1); fx.shake = 1; sfx.play('boom'); }
      sfx.play('kill', vol(f.x, f.z));
      break;
    }
    case 'pdie': if (mine) sfx.play('boom', 0.6); break;
    case 'ring': fx.ring(f.x, f.z, f.r, f.c, f.soft ? 0.8 : 0.5, !!f.soft); sfx.play('swing', vol(f.x, f.z) * 0.5); break;
    case 'tele':
      fx.telegraph(f.x, f.z, f.r, f.d, f.c);
      if (f.fall) fx.meteor(f.x, f.z, f.r, f.d, f.c);
      sfx.play('warn', vol(f.x, f.z) * 0.7);
      break;
    case 'boom':
      fx.boom(f.x, f.z, f.r, f.c, !!f.big);
      if (f.big) sfx.play('boom', vol(f.x, f.z));
      break;
    case 'bolt': fx.bolt(f.pts, f.c); sfx.play('zap', vol(f.pts[0][0], f.pts[0][1])); break;
    case 'dash': fx.trail(f.x0, f.z0, f.x, f.z, f.c); sfx.play('swing', vol(f.x, f.z)); break;
    case 'combo': {
      const k = D.combos.find(c => c.id === f.k), col = D.tags[k.pairs[0][1]].color;
      fx.text(f.x, 3.4, f.z, k.name + '!', 'combo', 1.5, col);
      fx.ring(f.x, f.z, 2.2, col, 0.45);
      fx.burst(f.x, 1.2, f.z, col, 12, 6);
      sfx.play('combo', vol(f.x, f.z));
      break;
    }
    case 'lvl':
      if (e) { fx.pillar(e, 0xffd76a, 1.6, 7); fx.ring(e.x, e.z, 3, 0xffd76a, 0.9); fx.text(e.x, 3.2, e.z, 'Stufe ' + f.lvl, 'big', 1.8); sfx.play('level', mine ? 1 : vol(e.x, e.z) * 0.6); }
      break;
    case 'heal': if (e) { fx.text(e.x, 2.6, e.z, '+' + f.v, 'heal'); fx.pillar(e, 0x8fe07a, 0.8, 3); if (mine) sfx.play('heal'); } break;
    case 'buff': if (e) fx.pillar(e, f.c ?? 0xffa040, 1.0, 4); break;
    case 'loot':
      if (mine) { fx.text(S.me.x, 3.0, S.me.z, `+${f.xp} EP`, 'xp', 1.3); fx.text(S.me.x, 2.5, S.me.z, `+${f.gold} Gold`, 'gold', 1.3); }
      break;
    case 'pick': fx.burst(f.x, 0.6, f.z, D.pickups[f.k]?.color ?? '#ffd76a', 10); fx.ring(f.x, f.z, 1.6, 0xffe9a8, 0.4); sfx.play('pick', vol(f.x, f.z)); break;
    case 'spawn': fx.ring(f.x, f.z, 1.3, 0xb0b0b0, 0.45); break;
    case 'enrage':
      fx.text(f.x, 4.6, f.z, 'Raserei!', 'combo', 1.8, '#ff4a3a');
      fx.ring(f.x, f.z, 5, 0xff3a28, 0.9); fx.burst(f.x, 1.5, f.z, 0xff3a28, 24, 7);
      fx.shake = Math.min(1, fx.shake + 0.5); sfx.play('boom', vol(f.x, f.z));
      break;
    case 'drop':                                     // Beute: Lichtsäule in der Farbe der Seltenheit
      fx.pillar({ x: f.x, z: f.z }, f.c, 1.6 + f.rar * 0.4, 5 + f.rar * 2);
      fx.ring(f.x, f.z, 1.8, f.c, 0.8); fx.burst(f.x, 0.8, f.z, f.c, 10 + f.rar * 6, 4);
      sfx.play(f.rar >= 2 ? 'level' : 'pick', vol(f.x, f.z));
      break;
    case 'questdone': if (e) { fx.pillar(e, 0xa9e07f, 1.4, 6); fx.ring(e.x, e.z, 2.5, 0xa9e07f, 0.8); } break;
  }
}

// =================================================================== Eingabe
function bindInput() {
  const canvas = $('game'), chat = ui.chatInput;
  addEventListener('keydown', e => {
    if (!S.joined) return;
    sfx.unlock();
    const typing = document.activeElement === chat;
    if (e.key === 'Enter') {
      e.preventDefault();
      if (typing) {
        const text = chat.value.trim();
        if (text) socket.emit('chat', { text });
        chat.value = ''; chat.blur();
      } else { S.keys.clear(); chat.focus(); }
      return;
    }
    if (e.key === 'Escape') { chat.blur(); ui.closeDialog(); ui.closeWins(); ui.toggleHelp(false); return; }
    if (typing || e.ctrlKey || e.metaKey || e.altKey) return;
    S.keys.add(e.code);
    if (e.repeat) return;
    switch (e.code) {
      case 'Digit1': case 'Numpad1': useSkill(1); break;
      case 'Digit2': case 'Numpad2': useSkill(2); break;
      case 'Digit3': case 'Numpad3': useSkill(3); break;
      case 'Digit4': case 'Numpad4': useSkill(4); break;
      case 'KeyQ': usePotion(); break;
      case 'KeyE': interact(); break;
      case 'KeyC': ui.toggleWin('sheet'); break;
      case 'KeyK': ui.toggleWin('tree'); break;
      case 'KeyH': ui.toggleHelp(); break;
      case 'KeyM': ui.toast(sfx.toggle() ? 'Ton an' : 'Ton aus'); break;
      case 'KeyG': setQuality((S.quality + 1) % QUALITY.length, 'manual'); break;
    }
    if (['Space', 'ArrowUp', 'ArrowDown', 'ArrowLeft', 'ArrowRight', 'Tab'].includes(e.code)) e.preventDefault();
  });
  addEventListener('keyup', e => S.keys.delete(e.code));
  addEventListener('blur', () => { S.keys.clear(); S.mouse.down = false; });
  addEventListener('mousemove', e => { S.mouse.x = e.clientX; S.mouse.y = e.clientY; });
  canvas.addEventListener('mousedown', e => {
    sfx.unlock();
    chat.blur();
    if (e.button === 0) S.mouse.down = true;
    else if (e.button === 2) useSkill(1);
  });
  addEventListener('mouseup', e => { if (e.button === 0) S.mouse.down = false; });
  canvas.addEventListener('contextmenu', e => e.preventDefault());
  canvas.addEventListener('wheel', e => { S.zoom = clamp(S.zoom + Math.sign(e.deltaY) * 0.08, 0.6, 1.35); }, { passive: true });
}

const alive = () => S.me && !(S.me.flags & 1);

function faceAim(now) {
  S.me.faceUntil = now + 0.32;
  S.me.trot = Math.atan2(S.aim.x - S.me.x, S.aim.z - S.me.z);
}

function attack(now) {
  if (!alive() || now < S.cd.atk) return;
  const a = D.classes[S.cls].atk;
  S.cd.atk = now + S.you.atkcd;
  socket.emit('attack', { x: S.aim.x, z: S.aim.z });
  faceAim(now);
  if (a.type === 'melee') {
    S.me.state.atk = { t: 0, dur: Math.min(0.28, S.you.atkcd * 0.6), kind: 'melee' };
    fx.slash(S.me.x, S.me.z, S.me.trot, a.range, 0xfff0cf, a.arc);
    sfx.play('swing');
  } else {
    const bow = D.classes[S.cls].style === 'bogen';   // Bewegungsstil der Klasse: Bogenschütze oder Zaubernder
    S.me.state.atk = { t: 0, dur: Math.min(0.3, S.you.atkcd * 0.7), kind: bow ? 'shoot' : 'cast' };
    sfx.play(bow ? 'shoot' : 'fire');
  }
}

// Fähigkeit auf Taste n (1–4). Der Server bestätigt und nennt die Abklingzeit.
function useSkill(n) {
  const now = secs(), key = S.you.bar[n - 1];
  if (!alive()) return;
  if (!key) { ui.toast(`Taste ${n} ist frei. Im Fähigkeitenfenster (K) kannst du sie belegen.`, 'warn'); return; }
  const sk = D.skills[key];
  if (now < (S.cd[key] ?? 0) || now < S.pending) return;
  if (S.res < sk.cost) { ui.toast(`Nicht genug ${ui.resName()} für ${sk.name}.`, 'warn'); return; }
  S.pending = now + 0.3;
  socket.emit('skill', { n, x: S.aim.x, z: S.aim.z }, res => {
    S.pending = 0;
    if (res?.cd) { S.cd[key] = secs() + res.cd; S.cdLen[key] = Math.max(res.cd, S.cdLen[key] ?? 0); }
    if (res?.ok) S.cdLen[key] = res.cd;
    else if (res?.why === 'res') ui.toast(`Nicht genug ${ui.resName()} für ${sk.name}.`, 'warn');
  });
  faceAim(now);
}

function usePotion() {
  const now = secs();
  if (!alive() || now < (S.cd.potion ?? 0)) return;
  if (S.you.pot <= 0) {
    const seller = ui.whoOffers('potion');
    ui.toast('Du hast keinen Heiltrank mehr.' + (seller ? ` ${seller} verkauft welche.` : ''), 'warn');
    return;
  }
  if (S.me.hp >= S.me.mhp) return;
  S.cd.potion = now + D.potion.cd;
  socket.emit('potion', {});
}

function nearestNpc() {
  let best = null, bd = 4.5;
  for (const n of S.npcs) {
    if (n.map !== S.map) continue;
    const d = Math.hypot(n.x - S.me.x, n.z - S.me.z);
    if (d < bd) { best = n; bd = d; }
  }
  return best;
}

function interact() {
  const n = nearestNpc();
  if (!n || !alive()) return;
  if (ui.dialogNpc === n.id) ui.closeDialog(); else { ui.closeWins(); ui.openDialog(n.id); sfx.play('talk'); }
}

// ================================================================ Spielschleife
const ray = new THREE.Raycaster(), ndc = new THREE.Vector2(), ground = new THREE.Plane(new THREE.Vector3(0, 1, 0), 0), hit = new THREE.Vector3();
let last = performance.now();

function frame(t) {
  const raw = (t - last) / 1000, dt = Math.min(0.05, raw), now = t / 1000;
  last = t;
  // Dauert ein Bild lange, erst andere Aufgaben (Netzwerk, Eingaben) drankommen lassen
  if (raw > 0.07) setTimeout(() => requestAnimationFrame(frame), 0); else requestAnimationFrame(frame);
  const me = S.me;
  if (!me) return;
  if (S.autoQuality && raw < 1) {
    const P = S.perf;
    if (P.warm < 3) P.warm += raw;                       // Anlaufzeit (Shader werden übersetzt) nicht werten
    else {
      P.t += raw; P.n++;
      if (P.t > 2.5) {
        if (P.n / P.t < 26 && S.quality < QUALITY.length - 1) setQuality(S.quality + 1, 'auto');
        P.t = P.n = 0;
      }
    }
  }

  const here = world.mapAt(me.x, me.z);
  if (here && here.id !== S.map) enterMap(here);

  // ---- eigene Bewegung (wird vorausberechnet, der Server prüft nach)
  let dx = 0, dz = 0;
  const K = S.keys;
  if (alive()) {
    if (K.has('KeyW') || K.has('ArrowUp')) dz -= 1;
    if (K.has('KeyS') || K.has('ArrowDown')) dz += 1;
    if (K.has('KeyA') || K.has('ArrowLeft')) dx -= 1;
    if (K.has('KeyD') || K.has('ArrowRight')) dx += 1;
  }
  const moving = dx !== 0 || dz !== 0;
  if (moving) {
    const l = Math.hypot(dx, dz), step = S.you.speed * dt;
    dx /= l; dz /= l;
    if (!world.blocked(me.x + dx * step, me.z, D.radius)) me.x += dx * step;
    if (!world.blocked(me.x, me.z + dz * step, D.radius)) me.z += dz * step;
    if (!(now < (me.faceUntil ?? 0))) me.trot = Math.atan2(dx, dz);
  }
  me.state.moving = moving;
  me.rot = lerpAngle(me.rot, me.trot, 1 - Math.exp(-18 * dt));
  if (now - S.lastSend > 0.066 && (Math.abs(me.x - S.sent.x) > 0.01 || Math.abs(me.z - S.sent.z) > 0.01 || Math.abs(me.rot - S.sent.r) > 0.05)) {
    S.lastSend = now;
    S.sent = { x: me.x, z: me.z, r: me.rot };
    socket.emit('move', { x: +me.x.toFixed(2), z: +me.z.toFixed(2), r: +me.rot.toFixed(2) });
  }

  // ---- Kamera folgt weich, wackelt bei Treffern
  const ck = 1 - Math.exp(-9 * dt);
  camT.x += (me.x - camT.x) * ck; camT.z += (me.z - camT.z) * ck;
  const sh = fx.shake, ox = (Math.random() - 0.5) * sh * 0.7, oz = (Math.random() - 0.5) * sh * 0.7;
  camera.position.set(camT.x + ox, 26 * S.zoom, camT.z + 14 * S.zoom + oz);
  camera.lookAt(camT.x + ox, 0.8, camT.z + oz);
  camera.updateMatrixWorld();

  // ---- Zielpunkt der Maus auf dem Boden
  ndc.set(S.mouse.x / innerWidth * 2 - 1, -(S.mouse.y / innerHeight) * 2 + 1);
  ray.setFromCamera(ndc, camera);
  if (ray.ray.intersectPlane(ground, hit)) { S.aim.x = hit.x; S.aim.z = hit.z; }
  aimRing.position.set(S.aim.x, 0.08, S.aim.z);
  aimRing.visible = alive();
  meRing.position.set(me.x, 0.06, me.z);
  if ((S.mouse.down || K.has('Space')) && document.activeElement !== ui.chatInput) attack(now);

  // ---- Figuren
  for (const e of S.ents.values()) {
    if (e !== me) {
      const k = 1 - Math.exp(-14 * dt), ddx = e.tx - e.x, ddz = e.tz - e.z;
      e.state.moving = Math.hypot(ddx, ddz) > 0.06;
      e.x += ddx * k; e.z += ddz * k;
      e.rot = lerpAngle(e.rot, e.trot, 1 - Math.exp(-12 * dt));
    }
    const foe = e.type === 'e', stunned = foe && !!(e.flags & 4);
    e.state.dead = !foe && !!(e.flags & 1);
    e.state.windup = foe && !!(e.flags & 1) && !e.state.atk && !stunned;
    if (stunned) e.state.moving = false;
    e.model.root.position.set(e.x, 0, e.z);
    e.model.root.rotation.set(0, e.rot, stunned ? Math.sin(now * 16) * 0.1 : 0);
    animateModel(e.model, e.state, dt);
    const tint = foe ? (e.flags & 8 ? RAGE_TINT(now) : tintOf(e.mask)) : null;
    if (e.flash > 0 || tint || e.tinted) {
      e.flash = Math.max(0, e.flash - dt * 6);
      flashModel(e.model, e.flash, tint);
      e.tinted = !!tint;
    }
    if (e.label) {
      const d = Math.hypot(e.x - me.x, e.z - me.z);
      const show = d < 36 && (!foe || e.boss || e.hp < e.mhp || d < 9);
      placeLabel(e.label, e.x, e.height + 0.3, e.z, show);
      const w = Math.round(e.hp / e.mhp * 100);
      if (w !== e.label.w) { e.label.w = w; e.label.fill.style.width = w + '%'; }
      if (foe && e.mask !== e.label.mask) {                // Zustände als farbige Punkte unter dem Balken
        e.label.mask = e.mask;
        e.label.pips.replaceChildren(...D.status.filter((s, i) => e.mask & (1 << i)).map(s => {
          const pip = document.createElement('i'); pip.style.background = s.color; pip.title = s.name; return pip;
        }));
      }
    }
  }
  for (let i = S.dying.length - 1; i >= 0; i--) {
    const d = S.dying[i];
    d.t += dt;
    animateModel(d.e.model, d.e.state, dt);
    d.e.model.root.position.y = -Math.max(0, d.t - 0.35) * 2.2;
    d.e.flash = Math.max(0, d.e.flash - dt * 6);
    flashModel(d.e.model, d.e.flash, null);
    if (d.t > 0.9) { scene.remove(d.e.model.root); S.dying.splice(i, 1); }
  }
  for (const n of S.npcs) {
    if (n.map !== S.map) continue;
    const d = Math.hypot(n.x - me.x, n.z - me.z);
    if (d < 7) n.model.root.rotation.y = lerpAngle(n.model.root.rotation.y, Math.atan2(me.x - n.x, me.z - n.z), 1 - Math.exp(-5 * dt));
    animateModel(n.model, n.state, dt);
    placeLabel(n.label, n.x, n.height + 0.3, n.z, d < 40);
  }
  for (const o of S.shots.values()) {
    const k = 1 - Math.exp(-30 * dt);
    o.x += (o.tx - o.x) * k; o.z += (o.tz - o.z) * k;
    o.g.position.x = o.x; o.g.position.z = o.z;
    if (o.kind !== 'arrow' && o.kind !== 'welle' && Math.random() < 0.5) fx.burst(o.x, 1.15, o.z, o.c, 1, 1.2);
  }
  for (const o of S.zones.values()) {
    o.m.fill.material.opacity = 0.2 + Math.sin(now * 5) * 0.06;
    o.m.edge.rotation.z = now * 0.3;
  }
  const wanted = Object.entries(S.you.quests).filter(([, st]) => st.s === 'active').map(([q]) => D.quests[q].target);
  for (const o of S.picks.values()) {
    const want = wanted.includes(o.kind);               // nur für die eigene Quest hervorheben
    o.m.ring.visible = want;
    o.m.inner.position.y = want ? 0.25 + Math.sin(now * 2.4 + o.x) * 0.12 : 0;
    o.m.inner.rotation.y = want ? now * 1.2 : o.x;
    o.m.ring.material.opacity = 0.4 + Math.sin(now * 4 + o.z) * 0.2;
  }

  // ---- Umgebung, Effekte, Anzeige
  world.update(dt, now, me.x, me.z);
  fx.update(dt);
  ui.tickCooldowns(now, S.cd, S.cdLen, S.res);
  ui.death(alive() ? 0 : S.deadUntil - now);
  if (now - S.zoneT > 0.25) {
    S.zoneT = now;
    const region = world.regionAt(me.x, me.z);
    ui.zone(region);
    ui.setDungeon(S.cata);
    const n = alive() ? nearestNpc() : null;
    ui.hint(n && ui.dialogNpc !== n.id ? `Mit ${n.name} sprechen` : null);
    if (ui.dialogNpc) {
      const dn = S.npcs.find(x => x.id === ui.dialogNpc);
      if (!alive() || Math.hypot(dn.x - me.x, dn.z - me.z) > 6.5) ui.closeDialog();
    }
  }
  const all = [...S.ents.values()];
  ui.drawMinimap(S.mini, me,
    all.filter(e => e.type === 'p' && e !== me),
    all.filter(e => e.type === 'e' && Math.hypot(e.x - me.x, e.z - me.z) < 30),
    S.npcs.filter(n => n.map === S.map), [...S.picks.values()].filter(p => wanted.includes(p.kind)));
  renderer.render(scene, camera);
}
