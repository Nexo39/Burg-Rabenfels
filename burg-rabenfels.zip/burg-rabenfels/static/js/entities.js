// Figuren aus einfachen Klötzen: Helden, Bewohner, Gegner, Geschosse und Questgegenstände.
// Wie eine Figur aussieht, steht in den Inhalten (content/) und kommt als `look` vom Server.
import * as THREE from 'three';

const geoCache = new Map();
function boxGeo(w, h, d) {
  const key = `${w}|${h}|${d}`;
  if (!geoCache.has(key)) geoCache.set(key, new THREE.BoxGeometry(w, h, d));
  return geoCache.get(key);
}
const SKIN = '#e2b48c', STEEL = '#9aa1a8', GOLD = '#c8a45a', WOOD = '#5a4027';

// Sammelt die Materialien einer Figur, damit sie bei Treffern aufblitzen kann
function kit(opacity = 1) {
  const mats = [];
  const lam = color => {
    const m = new THREE.MeshLambertMaterial({ color, flatShading: true, transparent: opacity < 1, opacity });
    mats.push(m); return m;
  };
  const glow = color => new THREE.MeshBasicMaterial({ color });
  const box = (parent, w, h, d, mat, x = 0, y = 0, z = 0) => {
    const m = new THREE.Mesh(boxGeo(w, h, d), mat);
    m.position.set(x, y, z); m.castShadow = true; parent.add(m); return m;
  };
  // Gliedmaße mit Drehpunkt am oberen Ende
  const limb = (parent, w, h, d, mat, x, y, z = 0) => {
    const g = new THREE.Group(); g.position.set(x, y, z); parent.add(g);
    box(g, w, h, d, mat, 0, -h / 2, 0);
    return g;
  };
  return { mats, lam, glow, box, limb };
}

function humanoid(o) {
  const { mats, lam, glow, box, limb } = kit(o.opacity);
  const root = new THREE.Group(), body = new THREE.Group();
  root.add(body);
  const w = o.thin ? 0.7 : 1;
  const skin = lam(o.skin ?? SKIN), cloth = lam(o.cloth), arms = lam(o.arms ?? o.cloth);
  const P = { body };
  if (o.robe) {
    P.robe = new THREE.Mesh(new THREE.CylinderGeometry(0.3, 0.54, 0.7, 7), lam(o.robe));
    P.robe.position.y = 0.35; P.robe.castShadow = true; body.add(P.robe);
  } else {
    const legs = lam(o.legs ?? '#4a4038');
    P.legL = limb(body, 0.24 * w, 0.6, 0.26 * w, legs, -0.16 * w, 0.6);
    P.legR = limb(body, 0.24 * w, 0.6, 0.26 * w, legs, 0.16 * w, 0.6);
  }
  box(body, 0.66 * w, 0.62, 0.4 * w, cloth, 0, 0.93, 0);
  P.armL = limb(body, 0.2 * w, 0.6, 0.22 * w, arms, -0.44 * w, 1.2);
  P.armR = limb(body, 0.2 * w, 0.6, 0.22 * w, arms, 0.44 * w, 1.2);
  P.head = box(body, 0.44, 0.44, 0.44, skin, 0, 1.5, 0);
  const eye = o.eyeGlow ? glow(o.eyeGlow) : lam(o.eye ?? '#1b1410');
  box(body, 0.08, 0.08, 0.03, eye, -0.1, 1.53, 0.225).castShadow = false;
  box(body, 0.08, 0.08, 0.03, eye, 0.1, 1.53, 0.225).castShadow = false;

  if (o.apron) box(body, 0.5 * w, 0.62, 0.04, lam(o.apron), 0, 0.82, 0.21 * w + 0.01);
  if (o.sash) box(body, 0.14, 0.9, 0.04, lam(o.sash), 0, 0.72, 0.28);
  if (o.cape) { const c = box(body, 0.62 * w, 0.95, 0.06, lam(o.cape), 0, 0.82, -0.25 * w - 0.02); c.rotation.x = 0.12; }
  if (o.pads) { const pm = lam(o.pads); box(body, 0.28, 0.14, 0.32, pm, -0.46 * w, 1.24, 0); box(body, 0.28, 0.14, 0.32, pm, 0.46 * w, 1.24, 0); }
  if (o.ears) {
    const em = lam(o.ears);
    for (const s of [-1, 1]) {
      const e = new THREE.Mesh(new THREE.ConeGeometry(0.09, 0.34, 4), em);
      e.position.set(s * 0.36, 1.55, 0); e.rotation.z = -s * Math.PI / 2.4; e.castShadow = true; body.add(e);
    }
  }

  switch (o.hat) {
    case 'helmet': {
      const hm = lam(o.hatColor ?? STEEL);
      box(body, 0.5, 0.26, 0.5, hm, 0, 1.68, 0); box(body, 0.07, 0.2, 0.05, hm, 0, 1.5, 0.24);
      if (o.plume) box(body, 0.08, 0.22, 0.42, lam(o.plume), 0, 1.9, -0.02);
      break;
    }
    case 'wizard': {
      const hm = lam(o.hatColor ?? o.cloth);
      const brim = new THREE.Mesh(new THREE.CylinderGeometry(0.44, 0.44, 0.05, 10), hm);
      brim.position.y = 1.74; brim.castShadow = true; body.add(brim);
      const cone = new THREE.Mesh(new THREE.ConeGeometry(0.28, 0.66, 8), hm);
      cone.position.set(0, 2.08, -0.04); cone.rotation.x = -0.18; cone.castShadow = true; body.add(cone);
      box(body, 0.5, 0.07, 0.5, lam(GOLD), 0, 1.79, 0);
      break;
    }
    case 'hood': {
      const hm = lam(o.hatColor ?? o.cloth);
      box(body, 0.52, 0.34, 0.52, hm, 0, 1.62, -0.03); box(body, 0.42, 0.3, 0.14, hm, 0, 1.4, -0.26);
      break;
    }
    case 'crown': {
      if (o.hair) { const h = lam(o.hair ?? '#3a2a1c'); box(body, 0.5, 0.16, 0.5, h, 0, 1.72, 0); box(body, 0.5, 0.5, 0.1, h, 0, 1.45, -0.26); }
      const gm = lam(GOLD), y = o.hair ? 1.86 : 1.78;
      for (const [x, z, ww, dd] of [[0, 0.21, 0.48, 0.06], [0, -0.21, 0.48, 0.06], [0.21, 0, 0.06, 0.48], [-0.21, 0, 0.06, 0.48]]) box(body, ww, 0.14, dd, gm, x, y, z);
      for (const [x, z] of [[0.21, 0.21], [-0.21, 0.21], [0.21, -0.21], [-0.21, -0.21], [0, 0.21]]) box(body, 0.07, 0.12, 0.07, gm, x, y + 0.12, z);
      break;
    }
    case 'bonnet': box(body, 0.5, 0.2, 0.5, lam('#f1ead8'), 0, 1.73, -0.02); break;
    case 'hair': { const h = lam(o.hair ?? '#3a2a1c'); box(body, 0.5, 0.16, 0.5, h, 0, 1.72, 0); box(body, 0.5, 0.3, 0.1, h, 0, 1.56, -0.25); break; }
    case 'tonsure': { const h = lam(o.hair ?? '#3a2a1c'); box(body, 0.5, 0.12, 0.5, h, 0, 1.62, -0.01); box(body, 0.3, 0.05, 0.3, skin, 0, 1.73, 0); break; }
  }

  // Waffe in der rechten Hand; zeigt bei hängendem Arm nach vorn
  const hand = new THREE.Group(); hand.position.set(0, -0.56, 0.04); P.armR.add(hand);
  const blade = (len, wide, col) => {
    hand.rotation.x = Math.PI / 2;
    box(hand, wide, len, 0.035, lam(col), 0, len / 2 + 0.1, 0);
    box(hand, wide * 3.4, 0.06, 0.09, lam(o.hilt ?? GOLD), 0, 0.08, 0);
    box(hand, 0.06, 0.18, 0.06, lam('#2e241a'), 0, -0.03, 0);
  };
  switch (o.weapon) {
    case 'sword': blade(0.82, 0.09, o.bladeColor ?? '#cfd5da'); break;
    case 'greatsword': blade(1.25, 0.13, o.bladeColor ?? '#9fb6c9'); break;
    case 'staff': {
      const s = new THREE.Mesh(new THREE.CylinderGeometry(0.035, 0.045, 1.7, 6), lam(WOOD));
      s.position.set(0, 0.35, 0.08); s.castShadow = true; hand.add(s);
      const orb = new THREE.Mesh(new THREE.IcosahedronGeometry(0.13, 1), glow(o.orb ?? '#8fd0ff'));
      orb.position.set(0, 1.28, 0.08); hand.add(orb);
      break;
    }
    case 'club': hand.rotation.x = Math.PI / 2; box(hand, 0.1, 0.5, 0.1, lam(WOOD), 0, 0.2, 0); box(hand, 0.2, 0.3, 0.2, lam('#6b4d30'), 0, 0.55, 0); break;
    case 'hammer': hand.rotation.x = Math.PI / 2; box(hand, 0.07, 0.6, 0.07, lam(WOOD), 0, 0.25, 0); box(hand, 0.34, 0.2, 0.2, lam('#3a3d42'), 0, 0.6, 0); break;
  }
  if (o.bow) {
    const bow = new THREE.Group(); bow.position.set(0, -0.5, 0.12); P.armL.add(bow);
    const arc = new THREE.Mesh(new THREE.TorusGeometry(0.44, 0.03, 4, 10, Math.PI), lam('#6b4d30'));
    arc.rotation.set(0, -Math.PI / 2, -Math.PI / 2); arc.castShadow = true; bow.add(arc);
    box(bow, 0.012, 0.88, 0.012, lam('#e8dcc0'), 0, 0, 0).castShadow = false;
    box(body, 0.16, 0.5, 0.12, lam('#6b4d30'), 0.14, 1.0, -0.27).rotation.z = 0.35;      // Köcher
  }
  if (o.shield) {
    box(P.armL, 0.07, 0.58, 0.48, lam(o.shield), -0.15, -0.34, 0.04);
    box(P.armL, 0.05, 0.16, 0.16, lam(GOLD), -0.2, -0.34, 0.04);
  }
  const scale = o.scale ?? 1;
  root.scale.setScalar(scale);
  return { root, parts: P, mats, kind: 'human', height: 1.95 * scale, scale };
}

function quadruped(o) {
  const { mats, lam, glow, box, limb } = kit();
  const root = new THREE.Group(), body = new THREE.Group();
  root.add(body);
  const fur = lam(o.fur), dark = lam(o.dark ?? o.fur), ear = lam(o.ear ?? o.fur);
  box(body, 0.5, 0.42, 1.05, fur, 0, 0.5, 0);
  const head = new THREE.Group(); head.position.set(0, 0.56, 0.55); body.add(head);
  box(head, 0.38, 0.34, 0.42, fur, 0, 0, 0.14);
  box(head, 0.2, 0.16, 0.22, dark, 0, -0.06, 0.44);
  box(head, 0.1, 0.16, 0.05, ear, -0.13, 0.24, 0.02); box(head, 0.1, 0.16, 0.05, ear, 0.13, 0.24, 0.02);
  const eye = o.eyeGlow ? glow(o.eyeGlow) : lam('#140c0c');
  box(head, 0.07, 0.07, 0.03, eye, -0.11, 0.05, 0.36).castShadow = false;
  box(head, 0.07, 0.07, 0.03, eye, 0.11, 0.05, 0.36).castShadow = false;
  const legs = [[-0.17, 0.36], [0.17, 0.36], [-0.17, -0.36], [0.17, -0.36]].map(([x, z]) => limb(body, 0.13, 0.34, 0.13, dark, x, 0.34, z));
  const tail = new THREE.Group(); tail.position.set(0, 0.6, -0.5); tail.rotation.x = 0.5; body.add(tail);
  const tw = o.bushy ? 0.16 : 0.06;
  box(tail, tw, tw, 0.75, lam(o.tail ?? o.fur), 0, 0, -0.36);
  const scale = o.scale ?? 1;
  root.scale.setScalar(scale);
  return { root, parts: { body, head, legs, tail }, mats, kind: 'quad', height: 0.95 * scale, scale };
}

// Baut eine Figur aus den Angaben des Servers (look): Zweibeiner oder – mit body: 'beast' – Vierbeiner.
// Welche Angaben es gibt, prüft game/registry.py (HUMAN_LOOK, BEAST_LOOK). Klassen, Bewohner und Gegner
// bringen ihr Aussehen aus content/ mit; für neue Figuren muss hier nichts geändert werden.
export function figure(look) {
  return look.body === 'beast' ? quadruped(look) : humanoid(look);
}

// Questgegenstand zum Aufsammeln. def: { form: 'kiste' | 'brocken', color }
export function pickupModel(def) {
  const { lam, glow, box } = kit();
  const g = new THREE.Group(), inner = new THREE.Group();
  g.add(inner);
  if (def.form === 'kiste') {
    box(inner, 0.75, 0.6, 0.75, lam('#9a7646'), 0, 0.3, 0);
    box(inner, 0.8, 0.1, 0.16, lam('#5b4328'), 0, 0.62, 0); box(inner, 0.16, 0.1, 0.8, lam('#5b4328'), 0, 0.62, 0);
  } else {
    const rock = new THREE.Mesh(new THREE.IcosahedronGeometry(0.46, 0), lam('#3a3d48'));
    rock.position.y = 0.4; rock.castShadow = true; inner.add(rock);
    for (const [x, y, z] of [[0.24, 0.6, 0.18], [-0.26, 0.42, 0.2], [0.05, 0.72, -0.22], [-0.1, 0.3, -0.34]]) box(inner, 0.13, 0.13, 0.13, glow(def.color), x, y, z).rotation.set(x * 9, y * 9, z * 9);
  }
  const ring = new THREE.Mesh(new THREE.RingGeometry(0.75, 0.92, 28),
    new THREE.MeshBasicMaterial({ color: def.color, transparent: true, opacity: 0.6, blending: THREE.AdditiveBlending, depthWrite: false }));
  ring.rotation.x = -Math.PI / 2; ring.position.y = 0.06; g.add(ring);
  return { root: g, inner, ring };
}

// Geschosse: Pfeile als Stäbchen, Schockwellen als breiter Balken, alles andere als leuchtende Kugel in der Farbe der Schadensart
export function shotModel(kind, color) {
  const g = new THREE.Group();
  const halo = (size, opacity) => new THREE.Mesh(new THREE.IcosahedronGeometry(size, 1),
    new THREE.MeshBasicMaterial({ color, transparent: true, opacity, blending: THREE.AdditiveBlending, depthWrite: false }));
  if (kind === 'arrow' || kind === 'poison') {
    const shaft = new THREE.Mesh(boxGeo(0.05, 0.05, 0.95), new THREE.MeshBasicMaterial({ color: kind === 'poison' ? color : 0xe8dcc0 }));
    const tip = new THREE.Mesh(boxGeo(0.1, 0.1, 0.16), new THREE.MeshBasicMaterial({ color: kind === 'poison' ? color : 0xb8c4cc }));
    tip.position.z = 0.5; g.add(shaft, tip);
    if (kind === 'poison') g.add(halo(0.25, 0.4));
  } else if (kind === 'welle') {
    const wave = new THREE.Mesh(boxGeo(2.4, 0.5, 0.5), new THREE.MeshBasicMaterial({ color, transparent: true, opacity: 0.75, blending: THREE.AdditiveBlending, depthWrite: false }));
    wave.position.y = -0.8; g.add(wave);
  } else {
    const core = new THREE.Mesh(new THREE.IcosahedronGeometry(kind === 'ice' ? 0.18 : 0.24, 1), new THREE.MeshBasicMaterial({ color: 0xffffff }));
    if (kind === 'ice') core.scale.set(1, 1, 3);
    g.add(core, halo(kind === 'dark' ? 0.36 : 0.42, 0.55));
  }
  g.position.y = 1.15;
  return g;
}

// Feld am Boden (Blizzard, Giftwolke, Banner …): Rand und zarte Füllung in der Farbe der Schadensart
export function zoneModel(r, color) {
  const g = new THREE.Group();
  const mat = opacity => new THREE.MeshBasicMaterial({ color, transparent: true, opacity, depthWrite: false, side: THREE.DoubleSide });
  const edge = new THREE.Mesh(new THREE.RingGeometry(r - 0.14, r, 56, 1, 0, Math.PI * 1.9), mat(0.9));
  const fill = new THREE.Mesh(new THREE.CircleGeometry(r, 44), mat(0.2));
  for (const m of [edge, fill]) { m.rotation.x = -Math.PI / 2; g.add(m); }
  edge.position.y = 0.1; fill.position.y = 0.08;
  return { root: g, edge, fill };
}

// ---------------------------------------------------------------- Animation
// s: { moving, atk: {t, dur, kind} | null, windup, dead, phase, amp, fall }
export function animateModel(m, s, dt) {
  s.phase = (s.phase ?? 0) + dt * (s.moving ? 11 : 0);
  s.amp = (s.amp ?? 0) + ((s.moving ? 1 : 0) - (s.amp ?? 0)) * Math.min(1, dt * 12);
  s.fall = (s.fall ?? 0) + ((s.dead ? 1 : 0) - (s.fall ?? 0)) * Math.min(1, dt * 9);
  const sw = Math.sin(s.phase) * s.amp, P = m.parts;
  let e = 0, kind = null;
  if (s.atk) {
    s.atk.t += dt / s.atk.dur;
    if (s.atk.t >= 1) s.atk = null; else { e = Math.sin(s.atk.t * Math.PI); kind = s.atk.kind; }
  }
  if (m.kind === 'human') {
    if (P.legL) { P.legL.rotation.x = sw * 0.75; P.legR.rotation.x = -sw * 0.75; }
    if (P.robe) P.robe.rotation.z = sw * 0.07;
    let aL = -sw * 0.6, aR = sw * 0.6, lean = 0, spin = 0;
    if (s.windup) aR = -2.5;
    if (kind === 'melee') { aR = -0.3 - 2.3 * (1 - s.atk.t) * (s.atk.t < 0.25 ? s.atk.t * 4 : 1); lean = 0.22 * e; }
    else if (kind === 'cast') { aR = -2.7 * e; aL = -2.1 * e; }
    else if (kind === 'shoot') { aL = -1.55 * e; aR = -1.1 * e; }
    else if (kind === 'spin') { spin = s.atk.t * Math.PI * 2; aR = aL = -1.5; }
    P.armL.rotation.x = aL; P.armR.rotation.x = aR;
    P.body.rotation.set(lean - s.fall * 1.5, spin, 0);
    P.body.position.y = Math.abs(sw) * 0.06 + s.fall * 0.22;
  } else {
    P.legs.forEach((l, i) => { l.rotation.x = (i === 0 || i === 3 ? sw : -sw) * 0.8; });
    P.tail.rotation.y = Math.sin(s.phase * 0.8 + 1) * 0.35 * (0.3 + s.amp);
    P.head.rotation.x = kind === 'melee' || kind === 'bite' ? -0.5 * e : (s.windup ? 0.3 : 0);
    P.body.position.z = (kind ? 0.55 * e : 0) - (s.windup ? 0.15 : 0);
    P.body.position.y = Math.abs(sw) * 0.05;
    P.body.rotation.z = s.fall * 1.5;
  }
}

// Trefferblitz (f von 1 nach 0) plus Färbung durch einen Zustand (tint: [r, g, b] oder null)
export function flashModel(m, f, tint) {
  const r = f * 0.9 + (tint ? tint[0] : 0), g = f * 0.2 + (tint ? tint[1] : 0), b = f * 0.15 + (tint ? tint[2] : 0);
  for (const mat of m.mats) mat.emissive.setRGB(r, g, b);
}
