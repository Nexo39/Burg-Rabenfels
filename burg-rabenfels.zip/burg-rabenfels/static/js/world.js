// Baut die Karten in 3D aus den Kacheldaten des Servers und stellt die Kollision bereit.
// World verwaltet alle Karten; eine MapView ist die 3D-Ansicht einer einzelnen Karte und entsteht erst,
// wenn der Held sie zum ersten Mal betritt. Neue Karten brauchen hier keine Änderung – nur neue
// Kachelzeichen (siehe game/world.py) müssten in buildGround/buildWalls/buildObjects/minimap ergänzt werden.
import * as THREE from 'three';

export const TS = 2;                       // Kantenlänge einer Kachel in Welteinheiten
const WALL_H = 3.0, HOUSE_H = 2.6;

function mulberry(seed) {
  return () => {
    seed = (seed + 0x6D2B79F5) | 0;
    let t = Math.imul(seed ^ (seed >>> 15), 1 | seed);
    t = (t + Math.imul(t ^ (t >>> 7), 61 | t)) ^ t;
    return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
  };
}

const lam = (color, extra = {}) => new THREE.MeshLambertMaterial({ color, flatShading: true, ...extra });

function canvasTexture(w, h, draw, repeat) {
  const c = document.createElement('canvas');
  c.width = w; c.height = h;
  draw(c.getContext('2d'), w, h);
  const t = new THREE.CanvasTexture(c);
  t.colorSpace = THREE.SRGBColorSpace;
  if (repeat) { t.wrapS = t.wrapT = THREE.RepeatWrapping; t.repeat.set(repeat[0], repeat[1]); }
  return t;
}

class MapView {
  // data: eine Karte vom Server (Kacheln in eigenen Koordinaten, ox/oz = Lage in der Welt)
  constructor(data, shared) {
    this.data = data;
    this.W = data.w; this.H = data.h;
    this.floor = data.floor; this.obj = data.obj;
    this.solidFloor = shared.solidFloor;
    this.solidObj = shared.solidObj;
    this.rnd = mulberry(4711);
    this.flames = [];                      // flackernde Flammen
    this.sources = [];                     // Lichtquellen, aus denen die nächsten sechs leuchten
    this.portals = [];
    this.group = new THREE.Group();        // alles in Kartenkoordinaten; die Gruppe sitzt an der Lage der Karte
    this.group.position.set(data.ox * TS, 0, data.oz * TS);
    this.maxAniso = shared.maxAniso;
    this.buildGround();
    this.buildWalls();
    this.buildObjects();
    this.buildDeco(data.deco);
    for (const s of this.sources) { s.x += data.ox * TS; s.z += data.oz * TS; }      // Lichter in Weltkoordinaten
  }

  // ------------------------------------------------------------ Abfragen
  f(x, z) { return (x < 0 || z < 0 || x >= this.W || z >= this.H) ? '#' : this.floor[z][x]; }
  o(x, z) { return (x < 0 || z < 0 || x >= this.W || z >= this.H) ? ' ' : this.obj[z][x]; }
  solidAt(tx, tz) {
    if (tx < 0 || tz < 0 || tx >= this.W || tz >= this.H) return true;
    return this.solidFloor.has(this.floor[tz][tx]) || this.solidObj.has(this.obj[tz][tx]);
  }
  each(fn) { for (let z = 0; z < this.H; z++) for (let x = 0; x < this.W; x++) fn(x, z, this.floor[z][x], this.obj[z][x]); }
  add(mesh, shadow = true) { mesh.castShadow = shadow; mesh.receiveShadow = true; this.group.add(mesh); return mesh; }

  // -------------------------------------------------------------- Boden
  buildGround() {
    const S = 32, rnd = this.rnd;
    const pick = a => a[(rnd() * a.length) | 0];
    const tex = canvasTexture(this.W * S, this.H * S, g => {
      const speck = (px, py, n, cols, s = 3) => {
        for (let i = 0; i < n; i++) {
          g.fillStyle = pick(cols);
          g.fillRect(px + rnd() * (S - s), py + rnd() * (S - s), 1 + rnd() * s, 1 + rnd() * s);
        }
      };
      const slab = (x, y, w, h, r, col) => {
        g.fillStyle = col; g.beginPath();
        if (g.roundRect) g.roundRect(x, y, w, h, r); else g.rect(x, y, w, h);
        g.fill();
      };
      const planks = (px, py, cols, vertical) => {
        for (let i = 0; i < 4; i++) {
          g.fillStyle = pick(cols);
          if (vertical) g.fillRect(px + i * 8, py, 8, S); else g.fillRect(px, py + i * 8, S, 8);
          g.fillStyle = 'rgba(30,20,10,.55)';
          if (vertical) { g.fillRect(px + i * 8, py, 1, S); g.fillRect(px + i * 8 + 1, py + rnd() * S, 6, 1); }
          else { g.fillRect(px, py + i * 8, S, 1); g.fillRect(px + rnd() * S, py + i * 8 + 1, 1, 7); }
        }
      };
      this.each((x, z, ch) => {
        const px = x * S, py = z * S;
        switch (ch) {
          case ',':
            g.fillStyle = '#4b6b34'; g.fillRect(px, py, S, S);
            speck(px, py, 16, ['#557a3b', '#41602d', '#5f8641', '#476732']);
            if (rnd() < 0.06) speck(px, py, 2, ['#d9c96a', '#e8e2d0'], 1);
            break;
          case ':':
            g.fillStyle = '#7b6648'; g.fillRect(px, py, S, S);
            speck(px, py, 12, ['#8a7453', '#6c593f', '#94805f', '#5f4f39']);
            break;
          case '.': case 'D': case 'd':
            g.fillStyle = '#46423c'; g.fillRect(px, py, S, S);
            for (let i = 0; i < 3; i++) for (let j = 0; j < 3; j++) {
              slab(px + i * 10.7 + 1 + rnd(), py + j * 10.7 + 1 + rnd(), 8 + rnd() * 1.4, 8 + rnd() * 1.4, 3,
                pick(['#8b867c', '#7c776e', '#969085', '#726d65', '#857f73']));
            }
            break;
          case '_':
            planks(px, py, ['#7a5a3a', '#84623f', '#6f5134', '#7d5c3c'], false);
            break;
          case '=':
            planks(px, py, ['#6b4d30', '#74552f', '#5f4329'], true);
            break;
          case 'c':
            g.fillStyle = '#34322f'; g.fillRect(px, py, S, S);
            for (let i = 0; i < 2; i++) for (let j = 0; j < 2; j++) slab(px + i * 16 + 1, py + j * 16 + 1, 14, 14, 1, pick(['#55524d', '#4c4945', '#5c5853']));
            break;
          case 'g':
            g.fillStyle = '#3e4a31'; g.fillRect(px, py, S, S);
            speck(px, py, 16, ['#48553a', '#35402a', '#4c4234', '#55493a']);
            break;
          case 'k':
            g.fillStyle = '#2b2d36'; g.fillRect(px, py, S, S);
            for (let i = 0; i < 2; i++) for (let j = 0; j < 2; j++) slab(px + i * 16 + 1, py + j * 16 + 1, 14, 14, 1, pick(['#4a4d5b', '#424552', '#515466']));
            break;
          case '~':
            g.fillStyle = '#1d4651'; g.fillRect(px, py, S, S);
            speck(px, py, 5, ['#255561', '#19404a'], 6);
            break;
          case 'v': case 'u':                              // Treppe zwischen Kapelle und Katakomben
            g.fillStyle = '#3a3742'; g.fillRect(px, py, S, S);
            for (let i = 0; i < 4; i++) { g.fillStyle = i % 2 ? '#5a5666' : '#4a4656'; g.fillRect(px + 2, py + i * 8 + 1, S - 4, 6); }
            break;
          case 'M':
            g.fillStyle = '#0c0b0d'; g.fillRect(px, py, S, S);
            break;
          default:
            g.fillStyle = '#262422'; g.fillRect(px, py, S, S);
        }
      });
      // Weiche Schatten am Fuß der Mauern und Ufer am Wasser
      const wall = (x, z) => '#HOM'.includes(this.f(x, z));
      const water = (x, z) => this.f(x, z) === '~';
      const edge = (px, py, dx, dz, col, depth) => {
        const gr = dx ? g.createLinearGradient(dx > 0 ? px + S : px, 0, dx > 0 ? px + S - depth : px + depth, 0)
                      : g.createLinearGradient(0, dz > 0 ? py + S : py, 0, dz > 0 ? py + S - depth : py + depth);
        gr.addColorStop(0, col); gr.addColorStop(1, 'rgba(0,0,0,0)');
        g.fillStyle = gr; g.fillRect(px, py, S, S);
      };
      this.each((x, z) => {
        if (wall(x, z)) return;
        for (const [dx, dz] of [[1, 0], [-1, 0], [0, 1], [0, -1]]) {
          if (wall(x + dx, z + dz)) edge(x * S, z * S, dx, dz, 'rgba(0,0,0,.5)', 11);
          else if (water(x, z) && !water(x + dx, z + dz)) edge(x * S, z * S, dx, dz, 'rgba(150,200,190,.35)', 6);
        }
      });
    });
    tex.anisotropy = this.maxAniso;
    const geo = new THREE.PlaneGeometry(this.W * TS, this.H * TS);
    const ground = new THREE.Mesh(geo, new THREE.MeshLambertMaterial({ map: tex }));
    ground.rotation.x = -Math.PI / 2;
    ground.position.set(this.W * TS / 2, 0, this.H * TS / 2);
    ground.receiveShadow = true;
    this.group.add(ground);

    // Schimmer auf dem Burggraben
    const tiles = [];
    this.each((x, z, ch) => { if (ch === '~') tiles.push([x, z]); });
    this.waterTex = canvasTexture(64, 64, g => {
      g.strokeStyle = 'rgba(190,235,240,.9)'; g.lineWidth = 2; g.lineCap = 'round';
      for (const [x, y, w] of [[6, 12, 20], [38, 30, 18], [14, 48, 22], [44, 6, 12]]) {
        g.beginPath(); g.moveTo(x, y); g.quadraticCurveTo(x + w / 2, y - 4, x + w, y); g.stroke();
      }
    }, [1, 1]);
    const wmat = new THREE.MeshBasicMaterial({ map: this.waterTex, transparent: true, opacity: 0.28, depthWrite: false, blending: THREE.AdditiveBlending });
    const water = new THREE.InstancedMesh(new THREE.PlaneGeometry(TS, TS).rotateX(-Math.PI / 2), wmat, tiles.length);
    const m = new THREE.Matrix4();
    tiles.forEach(([x, z], i) => water.setMatrixAt(i, m.makeTranslation((x + 0.5) * TS, 0.03, (z + 0.5) * TS)));
    this.group.add(water);
  }

  // ------------------------------------------------------------- Mauern
  buildWalls() {
    const rnd = this.rnd;
    const brick = (base, mortar, rows) => canvasTexture(128, 192, (g, w, h) => {
      g.fillStyle = mortar; g.fillRect(0, 0, w, h);
      const rh = h / rows;
      for (let r = 0; r < rows; r++) {
        const off = (r % 2) * 16;
        for (let x = -32; x < w; x += 32) {
          const v = 0.86 + rnd() * 0.28;
          g.fillStyle = `rgb(${base.map(c => Math.min(255, c * v) | 0).join(',')})`;
          g.fillRect(x + off + 1.5, r * rh + 1.5, 29, rh - 3);
        }
      }
    });
    const stone = brick([146, 140, 128], '#4b4741', 8);
    const plaster = canvasTexture(128, 128, (g, w, h) => {
      g.fillStyle = '#cbb98f'; g.fillRect(0, 0, w, h);
      for (let i = 0; i < 260; i++) { g.fillStyle = rnd() < 0.5 ? 'rgba(255,255,255,.06)' : 'rgba(60,40,20,.07)'; g.fillRect(rnd() * w, rnd() * h, 3, 3); }
      g.fillStyle = '#4a3524';
      g.fillRect(0, 0, w, 11); g.fillRect(0, h - 11, w, 11); g.fillRect(0, 0, 9, h); g.fillRect(w - 9, 0, 9, h);
      g.fillRect(0, h / 2 - 5, w, 10);
      g.save(); g.translate(w / 2, h * 0.75); g.rotate(-0.5); g.fillRect(-70, -4, 140, 9); g.restore();
    });

    const walls = [], houses = [], towers = [], merlons = [], rocks = [];
    const castle = (x, z) => '#O'.includes(this.f(x, z));
    const open = (x, z) => x >= 0 && z >= 0 && x < this.W && z < this.H && this.floor[z][x] !== 'M';
    this.each((x, z, ch) => {
      if (ch === 'M') {                                    // Fels nur dort bauen, wo er an einen Raum grenzt
        for (let dx = -1; dx <= 1; dx++) for (let dz = -1; dz <= 1; dz++) if (open(x + dx, z + dz)) { rocks.push([x, z]); return; }
        return;
      }
      if (ch === '#') {
        walls.push([x, z]);
        for (const sx of [-1, 1]) for (const sz of [-1, 1]) {
          if (!(castle(x + sx, z) && castle(x, z + sz) && castle(x + sx, z + sz))) merlons.push([(x + 0.5) * TS + sx * 0.7, (z + 0.5) * TS + sz * 0.7]);
        }
      } else if (ch === 'H') houses.push([x, z]);
      else if (ch === 'O') towers.push([x, z]);
    });

    const m = new THREE.Matrix4(), col = new THREE.Color();
    const instanced = (geo, mat, list, tint = 0.14) => {
      if (!list.length) return null;                 // Karten ohne Mauern, Häuser oder Türme
      const mesh = new THREE.InstancedMesh(geo, mat, list.length);
      list.forEach(([x, z], i) => {
        mesh.setMatrixAt(i, m.makeTranslation(x, 0, z));
        mesh.setColorAt(i, col.setScalar(1 - tint + rnd() * tint));
      });
      mesh.instanceColor.needsUpdate = true;
      return this.add(mesh);
    };
    const centers = l => l.map(([x, z]) => [(x + 0.5) * TS, (z + 0.5) * TS]);
    const stoneMat = new THREE.MeshLambertMaterial({ map: stone });
    this.stoneMat = stoneMat;
    instanced(new THREE.BoxGeometry(TS, WALL_H, TS).translate(0, WALL_H / 2, 0), stoneMat, centers(walls));
    if (rocks.length) {
      const rockTex = brick([86, 84, 98], '#1e1d24', 6);
      instanced(new THREE.BoxGeometry(TS, 3.4, TS).translate(0, 1.7, 0), new THREE.MeshLambertMaterial({ map: rockTex }), centers(rocks), 0.3);
    }
    instanced(new THREE.BoxGeometry(0.56, 0.5, 0.56).translate(0, WALL_H + 0.25, 0), lam('#8f897d'), merlons);
    instanced(new THREE.BoxGeometry(TS, HOUSE_H, TS).translate(0, HOUSE_H / 2, 0), new THREE.MeshLambertMaterial({ map: plaster }), centers(houses), 0.1);
    instanced(new THREE.BoxGeometry(TS + 0.14, 0.2, TS + 0.14).translate(0, HOUSE_H + 0.1, 0), lam('#9a5a42'), centers(houses), 0.16);   // Ziegelabdeckung

    const towerTex = brick([150, 144, 132], '#4b4741', 12);
    towerTex.wrapS = THREE.RepeatWrapping; towerTex.repeat.set(3, 1);
    const towerMat = new THREE.MeshLambertMaterial({ map: towerTex });
    instanced(new THREE.CylinderGeometry(1.42, 1.55, 4.4, 14).translate(0, 2.2, 0), towerMat, centers(towers), 0.08);
    instanced(new THREE.CylinderGeometry(1.7, 1.7, 0.3, 14).translate(0, 4.45, 0), lam('#8f897d'), centers(towers), 0.05);
    instanced(new THREE.ConeGeometry(1.75, 1.9, 14).translate(0, 5.5, 0), lam('#6e3a2c'), centers(towers), 0.12);

    // Burgtor mit Fallgatter und Türstürze
    const wood = lam('#4a3524'), iron = lam('#2b2a2c');
    this.each((x, z, ch) => {
      const cx = (x + 0.5) * TS, cz = (z + 0.5) * TS;
      if (ch === 'D') {
        const lintel = this.add(new THREE.Mesh(new THREE.BoxGeometry(TS, 0.7, TS * 0.85), stoneMat));
        lintel.position.set(cx, 2.75, cz);
        for (let i = 0; i < 4; i++) {
          const tooth = this.add(new THREE.Mesh(new THREE.BoxGeometry(0.09, 0.45, 0.09), iron));
          tooth.position.set(cx - 0.75 + i * 0.5, 2.2, cz);
        }
      } else if (ch === 'd') {
        const alongX = '#H'.includes(this.f(x - 1, z)) || '#H'.includes(this.f(x + 1, z));
        const beam = this.add(new THREE.Mesh(new THREE.BoxGeometry(alongX ? TS : 0.7, 0.3, alongX ? 0.7 : TS), wood));
        beam.position.set(cx, 2.45, cz);
      }
    });
  }

  // --------------------------------------------------------- Gegenstände
  buildObjects() {
    const rnd = this.rnd, add = m => this.add(m);
    const mesh = (geo, mat, x, y, z) => { const m = new THREE.Mesh(geo, mat); m.position.set(x, y, z); return add(m); };
    const M = {
      rock: lam('#7d7a74'), grave: lam('#9a9c96'), mound: lam('#4a3d2e'), barrel: lam('#6b4a2c'), band: lam('#2e2a26'),
      wood: lam('#4a3524'), stone: lam('#8b867c'), steel: lam('#3a3d42'), tent: lam('#8b6b47'), gold: lam('#c8a45a'),
      crypt: lam('#6c6f7c'), block: lam('#8f8a80'), coal: new THREE.MeshBasicMaterial({ color: '#ff7a1a' }),
      well: new THREE.MeshBasicMaterial({ color: '#123039' }),
      crate: new THREE.MeshLambertMaterial({
        map: canvasTexture(64, 64, g => {
          g.fillStyle = '#8a6a42'; g.fillRect(0, 0, 64, 64);
          g.strokeStyle = '#5b4328'; g.lineWidth = 7; g.strokeRect(3, 3, 58, 58);
          g.lineWidth = 6; g.beginPath(); g.moveTo(4, 4); g.lineTo(60, 60); g.moveTo(60, 4); g.lineTo(4, 60); g.stroke();
        }),
      }),
    };
    const G = {
      rock: new THREE.IcosahedronGeometry(0.95, 0), grave: new THREE.BoxGeometry(0.85, 1.15, 0.24), mound: new THREE.BoxGeometry(0.95, 0.18, 1.4),
      barrel: new THREE.CylinderGeometry(0.42, 0.42, 1.0, 10), band: new THREE.CylinderGeometry(0.44, 0.44, 0.08, 10),
      crate: new THREE.BoxGeometry(1.25, 1.25, 1.25), tent: new THREE.ConeGeometry(1.4, 2.1, 4), pillar: new THREE.CylinderGeometry(0.62, 0.7, 3.0, 8),
    };
    const trees = [];
    this.each((x, z, _, o) => {
      if (o === ' ') return;
      const cx = (x + 0.5) * TS, cz = (z + 0.5) * TS, j = () => (rnd() - 0.5);
      switch (o) {
        case 'T': trees.push([cx + j() * 0.5, cz + j() * 0.5, x === 0 || z === 0 || x === this.W - 1 || z === this.H - 1]); break;
        case 'R': {
          const r = mesh(G.rock, M.rock, cx + j() * 0.3, 0.45, cz + j() * 0.3);
          r.scale.set(0.9 + rnd() * 0.3, 0.6 + rnd() * 0.3, 0.9 + rnd() * 0.3); r.rotation.set(rnd() * 3, rnd() * 3, rnd() * 3);
          break;
        }
        case '+': {
          const s = mesh(G.grave, M.grave, cx, 0.57, cz - 0.6);
          s.rotation.set(j() * 0.12, j() * 0.3, j() * 0.12);
          mesh(G.mound, M.mound, cx, 0.09, cz + 0.25);
          break;
        }
        case 'B':
          for (const [ox, oz] of [[-0.45, -0.35], [0.45, -0.28], [0.02, 0.45]]) {
            mesh(G.barrel, M.barrel, cx + ox, 0.5, cz + oz);
            mesh(G.band, M.band, cx + ox, 0.28, cz + oz).castShadow = false;
            mesh(G.band, M.band, cx + ox, 0.76, cz + oz).castShadow = false;
          }
          break;
        case 'X': {
          const c = mesh(G.crate, M.crate, cx + j() * 0.2, 0.625, cz + j() * 0.2); c.rotation.y = j() * 0.5;
          if (rnd() < 0.45) { const t = mesh(G.crate, M.crate, cx + j() * 0.3, 1.6, cz + j() * 0.3); t.scale.setScalar(0.58); t.rotation.y = rnd(); }
          break;
        }
        case 'W':
          mesh(new THREE.CylinderGeometry(0.95, 1.0, 0.8, 12), M.stone, cx, 0.4, cz);
          mesh(new THREE.CylinderGeometry(0.72, 0.72, 0.04, 12), M.well, cx, 0.81, cz).castShadow = false;
          mesh(new THREE.BoxGeometry(0.12, 1.7, 0.12), M.wood, cx - 0.85, 0.85, cz);
          mesh(new THREE.BoxGeometry(0.12, 1.7, 0.12), M.wood, cx + 0.85, 0.85, cz);
          mesh(new THREE.ConeGeometry(1.3, 0.8, 4), lam('#6e3a2c'), cx, 2.1, cz).rotation.y = Math.PI / 4;
          break;
        case '^': {
          const t = mesh(G.tent, M.tent, cx, 1.05, cz); t.rotation.y = Math.PI / 4 + j() * 0.4;
          mesh(new THREE.BoxGeometry(0.06, 0.5, 0.06), M.wood, cx, 2.25, cz);
          break;
        }
        case 'A':
          mesh(new THREE.CylinderGeometry(0.34, 0.4, 0.55, 8), M.wood, cx, 0.275, cz);
          mesh(new THREE.BoxGeometry(0.95, 0.28, 0.4), M.steel, cx, 0.69, cz);
          mesh(new THREE.BoxGeometry(0.3, 0.14, 0.24), M.steel, cx + 0.6, 0.72, cz);
          break;
        case 'F':
          mesh(new THREE.BoxGeometry(1.7, 1.0, 1.7), M.stone, cx, 0.5, cz);
          mesh(new THREE.BoxGeometry(1.15, 0.1, 1.15), M.coal, cx, 1.04, cz).castShadow = false;
          mesh(new THREE.BoxGeometry(0.55, 1.6, 0.55), M.stone, cx - 0.55, 1.8, cz - 0.55);
          this.sources.push({ x: cx, y: 1.7, z: cz, color: 0xff7a2a, base: 1.0, phase: rnd() * 9 });
          break;
        case 'S':
          mesh(new THREE.BoxGeometry(1.8, 0.9, 1.3), M.block, cx, 0.45, cz);
          mesh(new THREE.BoxGeometry(1.84, 0.08, 1.34), M.gold, cx, 0.92, cz).castShadow = false;
          // Rückenlehne nur dort, wo der Block an einer Mauer steht (Thron, Sarkophag) – der Altar bleibt ein Tisch
          if ('#HM'.includes(this.f(x, z - 1))) mesh(new THREE.BoxGeometry(1.8, 1.4, 0.3), M.block, cx, 1.55, cz - 0.55);
          else if ('#H'.includes(this.f(x, z + 1))) mesh(new THREE.BoxGeometry(1.8, 0.7, 0.3), M.block, cx, 1.2, cz + 0.55);
          break;
        case 'P':
          mesh(new THREE.BoxGeometry(1.6, 0.25, 1.6), M.crypt, cx, 0.125, cz);
          mesh(G.pillar, M.crypt, cx, 1.6, cz);
          mesh(new THREE.BoxGeometry(1.5, 0.25, 1.5), M.crypt, cx, 3.1, cz);
          break;
      }
    });

    // Bäume als Instanzen: Stamm und zwei Kronenstufen
    const parts = [
      [new THREE.CylinderGeometry(0.2, 0.3, 1.2, 6).translate(0, 0.6, 0), lam('#4a3524'), false],
      [new THREE.ConeGeometry(1.35, 2.0, 7).translate(0, 1.9, 0), lam('#ffffff'), true],
      [new THREE.ConeGeometry(0.95, 1.7, 7).translate(0, 2.95, 0), lam('#ffffff'), true],
    ].map(([geo, mat]) => this.add(new THREE.InstancedMesh(geo, mat, trees.length)));
    const m = new THREE.Matrix4(), q = new THREE.Quaternion(), s = new THREE.Vector3(), p = new THREE.Vector3(), c = new THREE.Color();
    const greens = ['#3f6b35', '#356030', '#4a7a3a', '#2f5a35', '#44703a'];
    trees.forEach(([x, z, border], i) => {
      const k = (border ? 1.25 : 0.85) + rnd() * 0.35;
      q.setFromAxisAngle(new THREE.Vector3(0, 1, 0), rnd() * 6.28);
      m.compose(p.set(x, 0, z), q, s.set(k, k * (0.9 + rnd() * 0.25), k));
      c.set(rnd() < 0.06 ? '#8a6a2f' : greens[(rnd() * greens.length) | 0]);
      parts.forEach((mesh, n) => { mesh.setMatrixAt(i, m); mesh.setColorAt(i, n ? c : c.clone().set('#ffffff')); });
    });
    parts.forEach(mesh => { if (mesh.instanceColor) mesh.instanceColor.needsUpdate = true; });
  }

  // ------------------------------------------------- Fackeln, Feuer, Banner
  buildDeco(deco) {
    const wood = lam('#3d2c1e'), iron = lam('#2e2a26'), stone = lam('#70737d');
    const flame = (x, y, z, size, outer, inner) => {
      const g = new THREE.Group();
      g.add(new THREE.Mesh(new THREE.ConeGeometry(0.16 * size, 0.5 * size, 6), new THREE.MeshBasicMaterial({ color: outer })));
      const core = new THREE.Mesh(new THREE.ConeGeometry(0.08 * size, 0.3 * size, 5), new THREE.MeshBasicMaterial({ color: inner }));
      core.position.y = -0.06 * size; g.add(core);
      g.position.set(x, y, z); this.group.add(g);
      this.flames.push({ g, y, phase: this.rnd() * 9 });
    };
    const mesh = (geo, mat, x, y, z) => { const m = new THREE.Mesh(geo, mat); m.position.set(x, y, z); return this.add(m); };
    for (const d of deco) {
      const { x, z } = d;
      if (d.k === 'torch' || d.k === 'ghost') {
        const ghost = d.k === 'ghost';
        mesh(new THREE.CylinderGeometry(0.07, 0.1, 1.7, 6), ghost ? stone : wood, x, 0.85, z);
        mesh(new THREE.CylinderGeometry(0.15, 0.08, 0.16, 7), iron, x, 1.76, z);
        flame(x, 2.2, z, 1.7, ghost ? '#59ffc0' : '#ff9a2e', ghost ? '#e6fff6' : '#ffe9a8');
        this.sources.push({ x, y: 2.7, z, color: ghost ? 0x4dffc0 : 0xff9440, base: ghost ? 0.45 : 1.0, phase: this.rnd() * 9 });
      } else if (d.k === 'fire') {
        for (let i = 0; i < 3; i++) mesh(new THREE.BoxGeometry(1.0, 0.16, 0.16), wood, x, 0.1, z).rotation.y = i * 1.05;
        flame(x, 0.65, z, 2.4, '#ff8a2a', '#ffe9a8');
        this.sources.push({ x, y: 1.4, z, color: 0xff8a3a, base: 1.6, phase: 0 });
      } else if (d.k === 'portal') {                         // Treppe: Lichtsäule als Wegweiser
        const col = new THREE.Mesh(new THREE.CylinderGeometry(1.5, 1.5, 4, 20, 1, true),
          new THREE.MeshBasicMaterial({ color: 0x8d6fd0, transparent: true, opacity: 0.22, blending: THREE.AdditiveBlending, depthWrite: false, side: THREE.DoubleSide }));
        col.position.set(x, 2, z); this.group.add(col);
        const ring = new THREE.Mesh(new THREE.RingGeometry(1.5, 1.8, 32),
          new THREE.MeshBasicMaterial({ color: 0xb9a6ff, transparent: true, opacity: 0.7, blending: THREE.AdditiveBlending, depthWrite: false }));
        ring.rotation.x = -Math.PI / 2; ring.position.set(x, 0.07, z); this.group.add(ring);
        this.portals.push({ col, ring });
        this.sources.push({ x, y: 2.2, z, color: 0x8d6fd0, base: 0.6, phase: 0 });
      } else if (d.k === 'banner') {
        mesh(new THREE.BoxGeometry(0.9, 1.6, 0.05), lam('#8f2a25'), x, 1.6, z).castShadow = false;
        mesh(new THREE.BoxGeometry(0.34, 0.34, 0.07), lam('#c8a45a'), x, 1.85, z).castShadow = false;
      }
    }
  }

  // Jeden Frame: Flammen flackern, Wasser fließt, Übergänge schimmern
  update(dt, t) {
    for (const f of this.flames) {
      const s = 1 + Math.sin(t * 13 + f.phase) * 0.14 + Math.sin(t * 29 + f.phase * 2) * 0.08;
      f.g.scale.set(1 + (1 - s) * 0.4, s, 1 + (1 - s) * 0.4);
      f.g.position.y = f.y + (s - 1) * 0.12;
    }
    this.waterTex.offset.set(t * 0.03, Math.sin(t * 0.4) * 0.05);
    for (const p of this.portals) { p.col.rotation.y = t * 0.4; p.col.material.opacity = 0.18 + Math.sin(t * 2) * 0.06; }
  }

  // Grundbild für die Minimap (4 Pixel je Kachel)
  minimap(scale = 4) {
    const c = document.createElement('canvas');
    c.width = this.W * scale; c.height = this.H * scale;
    const g = c.getContext('2d');
    const floor = { ',': '#3c5a2c', ':': '#7b6648', '.': '#77726a', '_': '#7a5a3a', '=': '#6b4d30', c: '#4c4945', g: '#3a4530', k: '#3d404d',
      '~': '#1f4c58', '#': '#c9c2b2', H: '#a89877', O: '#ddd6c5', D: '#77726a', d: '#8a6a42', M: '#141217', v: '#b9a6ff', u: '#b9a6ff' };
    const obj = { T: '#274a25', R: '#6f6c66', '+': '#9a9c96', B: '#5a3e25', X: '#6e5434', W: '#2a5560', '^': '#a07d52', A: '#3a3d42', F: '#d2691e', S: '#bcb6a8', P: '#8a8d9a' };
    this.each((x, z, f, o) => {
      g.fillStyle = (o !== ' ' && obj[o]) || floor[f] || '#000';
      g.fillRect(x * scale, z * scale, scale, scale);
    });
    return c;
  }
}

// Alle Karten der Welt. Rechnet durchgehend in Weltkoordinaten; jede Karte kennt ihre Lage (ox, oz in Kacheln).
export class World {
  constructor(scene, data, renderer) {
    this.scene = scene;
    this.maps = data.maps;
    this.shared = { solidFloor: new Set(data.solidFloor), solidObj: new Set(data.solidObj), maxAniso: renderer.capabilities.getMaxAnisotropy() };
    this.views = new Map();                // Kennung -> MapView (entsteht beim ersten Betreten)
    this.current = null;
    this.last = data.maps[0];
    this.buildLights();
  }

  // ------------------------------------------------------------ Abfragen
  tileMap(tx, tz) {
    const hit = m => tx >= m.ox && tx < m.ox + m.w && tz >= m.oz && tz < m.oz + m.h;
    if (hit(this.last)) return this.last;
    for (const m of this.maps) if (hit(m)) return (this.last = m);
    return null;
  }
  mapAt(x, z) { return this.tileMap(Math.floor(x / TS), Math.floor(z / TS)); }
  solidAt(tx, tz) {
    const m = this.tileMap(tx, tz);
    if (!m) return true;                   // zwischen den Karten ist Leere
    return this.shared.solidFloor.has(m.floor[tz - m.oz][tx - m.ox]) || this.shared.solidObj.has(m.obj[tz - m.oz][tx - m.ox]);
  }
  // Kreis gegen Kacheln – dieselbe Rechnung wie auf dem Server (game/world.py: blocked)
  blocked(x, z, r) {
    const x0 = Math.floor((x - r) / TS), x1 = Math.floor((x + r) / TS);
    const z0 = Math.floor((z - r) / TS), z1 = Math.floor((z + r) / TS);
    for (let tz = z0; tz <= z1; tz++) for (let tx = x0; tx <= x1; tx++) {
      if (!this.solidAt(tx, tz)) continue;
      const cx = Math.max(tx * TS, Math.min(x, (tx + 1) * TS));
      const cz = Math.max(tz * TS, Math.min(z, (tz + 1) * TS));
      if ((x - cx) ** 2 + (z - cz) ** 2 < r * r) return true;
    }
    return false;
  }
  // Ortsname an einer Stelle: die erste passende Region der Karte, sonst der Name der Karte
  regionAt(x, z) {
    const m = this.mapAt(x, z);
    if (!m) return '';
    const tx = Math.floor(x / TS) - m.ox, tz = Math.floor(z / TS) - m.oz;
    for (const r of m.regions) {
      const [x0, z0, x1, z1] = r.rect;
      if (tx >= x0 && tx <= x1 && tz >= z0 && tz <= z1) return r.name;
    }
    return m.name;
  }

  // Der Held betritt eine Karte: Ansicht bauen (beim ersten Mal) und nur diese zeigen
  enter(id) {
    let view = this.views.get(id);
    if (!view) {
      view = new MapView(this.maps.find(m => m.id === id), this.shared);
      this.views.set(id, view);
      this.scene.add(view.group);
    }
    for (const v of this.views.values()) v.group.visible = v === view;
    this.current = view;
    return view;
  }
  minimap(id) { return this.views.get(id).minimap(4); }

  buildLights() {
    this.hemi = new THREE.HemisphereLight(0xb4c2e2, 0x4a3e30, 1.55);
    this.scene.add(this.hemi);
    const sun = new THREE.DirectionalLight(0xffd3a0, 2.5);
    sun.castShadow = true;
    sun.shadow.mapSize.set(2048, 2048);
    const c = sun.shadow.camera;
    c.left = -36; c.right = 36; c.top = 36; c.bottom = -36; c.near = 1; c.far = 110;
    sun.shadow.bias = -0.0006; sun.shadow.normalBias = 0.05;
    this.scene.add(sun, sun.target);
    this.sun = sun;
    this.pool = [];
    for (let i = 0; i < 6; i++) {
      const l = new THREE.PointLight(0xff9440, 0, 16, 1.6);
      this.scene.add(l); this.pool.push(l);
    }
  }

  // Jeden Frame: Sonne folgt dem Helden, die nächsten Lichtquellen der Karte leuchten
  update(dt, t, px, pz) {
    const view = this.current;
    if (!view) return;
    view.update(dt, t);
    // Auf dunklen Karten (light: 'dunkel') fällt kaum Tageslicht ein
    const dark = view.data.light === 'dunkel', k = Math.min(1, dt * 3);
    this.sun.intensity += ((dark ? 0.7 : 2.5) - this.sun.intensity) * k;
    this.hemi.intensity += ((dark ? 1.5 : 1.55) - this.hemi.intensity) * k;
    const sx = Math.round(px), sz = Math.round(pz);
    this.sun.position.set(sx - 20, 36, sz + 15);
    this.sun.target.position.set(sx, 0, sz);
    for (const s of view.sources) s.d = Math.hypot(s.x - px, s.z - pz);
    view.sources.sort((a, b) => a.d - b.d);
    this.pool.forEach((l, i) => {
      const s = view.sources[i];
      if (!s) { l.intensity = 0; return; }
      const fade = Math.max(0, Math.min(1, (34 - s.d) / 8));
      l.position.set(s.x, s.y, s.z);
      l.color.setHex(s.color);
      l.intensity = 15 * s.base * fade * (1 + Math.sin(t * 11 + s.phase) * 0.1 + Math.sin(t * 23 + s.phase) * 0.06);
    });
  }
}
