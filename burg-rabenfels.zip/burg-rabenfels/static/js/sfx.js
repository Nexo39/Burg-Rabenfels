// Kleine Klangeffekte, direkt im Browser erzeugt (Web Audio) – es werden keine Dateien geladen.

// Hintergrundklänge je Karte (game_map(..., ambient=...)): ein leises Rauschen als Grund, dazu
// gelegentliche Einzelklänge. bed: Tiefpass-Frequenz und Lautstärke, drone: tiefe Grundtöne,
// events: [Klang, Wahrscheinlichkeit je halbe Sekunde]
const AMB = {
  wind:   { bed: [380, 0.05], events: [['bird', 0.05]] },
  wald:   { bed: [260, 0.035], events: [['owl', 0.025], ['cricket', 0.15]] },
  sumpf:  { bed: [200, 0.03], events: [['frog', 0.12], ['bubble', 0.1]] },
  hoehle: { bed: [140, 0.035], drone: [[55, 0.012]], events: [['drip', 0.25], ['hammer', 0.02]] },
  gruft:  { bed: [120, 0.03], drone: [[41, 0.014], [61.7, 0.01]], events: [['whisper', 0.06], ['drip', 0.08]] },
  ruine:  { bed: [420, 0.055], events: [['crow', 0.04]] },
};

export class Sfx {
  constructor() {
    this.on = localStorage.getItem('rabenfels.ton') !== 'aus';
    this.ctx = null;
    this.last = {};
  }

  // Browser erlauben Ton erst nach einer Eingabe – deshalb beim ersten Klick/Tastendruck aufrufen
  unlock() {
    try {
      this.ctx ??= new (window.AudioContext || window.webkitAudioContext)();
      if (this.ctx.state === 'suspended') this.ctx.resume();
      if (this.amb && !this.ambOut) this.startAmbient();
    } catch { this.ctx = null; }
  }

  toggle() {
    this.on = !this.on;
    localStorage.setItem('rabenfels.ton', this.on ? 'an' : 'aus');
    if (this.on) this.startAmbient(); else this.stopAmbient();
    return this.on;
  }

  tone(freq, dur, { type = 'sine', vol = 0.12, to = freq, at = 0, dest = null } = {}) {
    const c = this.ctx, t = c.currentTime + at;
    const o = c.createOscillator(), g = c.createGain();
    o.type = type;
    o.frequency.setValueAtTime(freq, t);
    o.frequency.exponentialRampToValueAtTime(Math.max(20, to), t + dur);
    g.gain.setValueAtTime(0.0001, t);
    g.gain.exponentialRampToValueAtTime(vol, t + 0.012);
    g.gain.exponentialRampToValueAtTime(0.0001, t + dur);
    o.connect(g).connect(dest ?? c.destination);
    o.start(t); o.stop(t + dur + 0.02);
  }

  noise(dur, { vol = 0.12, freq = 1200, to = freq, q = 0.8, at = 0, dest = null } = {}) {
    const c = this.ctx, t = c.currentTime + at;
    const buf = c.createBuffer(1, Math.ceil(c.sampleRate * dur), c.sampleRate);
    const d = buf.getChannelData(0);
    for (let i = 0; i < d.length; i++) d[i] = Math.random() * 2 - 1;
    const src = c.createBufferSource(), f = c.createBiquadFilter(), g = c.createGain();
    src.buffer = buf;
    f.type = 'bandpass'; f.Q.value = q;
    f.frequency.setValueAtTime(freq, t);
    f.frequency.exponentialRampToValueAtTime(Math.max(40, to), t + dur);
    g.gain.setValueAtTime(vol, t);
    g.gain.exponentialRampToValueAtTime(0.0001, t + dur);
    src.connect(f).connect(g).connect(dest ?? c.destination);
    src.start(t);
  }

  play(name, vol = 1) {
    if (!this.on || !this.ctx || this.ctx.state !== 'running' || vol <= 0.02) return;
    const now = this.ctx.currentTime;
    if (now - (this.last[name] ?? -1) < 0.04) return;        // nicht dutzendfach im selben Augenblick
    this.last[name] = now;
    const v = x => x * vol;
    switch (name) {
      case 'swing': this.noise(0.13, { vol: v(0.16), freq: 2400, to: 500 }); break;
      case 'shoot': this.noise(0.09, { vol: v(0.12), freq: 3200, to: 1400, q: 2 }); this.tone(520, 0.08, { type: 'triangle', vol: v(0.05), to: 260 }); break;
      case 'fire': this.noise(0.25, { vol: v(0.14), freq: 500, to: 1600 }); this.tone(240, 0.22, { type: 'sawtooth', vol: v(0.04), to: 120 }); break;
      case 'hit': this.tone(170, 0.09, { type: 'square', vol: v(0.07), to: 90 }); this.noise(0.06, { vol: v(0.1), freq: 900 }); break;
      case 'hurt': this.tone(130, 0.2, { type: 'sawtooth', vol: v(0.11), to: 60 }); break;
      case 'kill': this.tone(300, 0.25, { type: 'triangle', vol: v(0.09), to: 70 }); break;
      case 'boom': this.noise(0.55, { vol: v(0.3), freq: 260, to: 50, q: 0.5 }); this.tone(80, 0.5, { vol: v(0.2), to: 30 }); break;
      case 'ice': this.noise(0.4, { vol: v(0.14), freq: 5200, to: 1800, q: 3 }); this.tone(1400, 0.35, { vol: v(0.05), to: 500 }); break;
      case 'shout': this.tone(196, 0.5, { type: 'sawtooth', vol: v(0.09), to: 294 }); this.tone(147, 0.5, { type: 'sawtooth', vol: v(0.07), to: 220 }); break;
      case 'heal': this.tone(523, 0.3, { vol: v(0.08), to: 784 }); this.tone(784, 0.35, { vol: v(0.06), to: 1047, at: 0.12 }); break;
      case 'pick': this.tone(880, 0.1, { type: 'triangle', vol: v(0.09) }); this.tone(1320, 0.16, { type: 'triangle', vol: v(0.09), at: 0.08 }); break;
      case 'quest': [523, 659, 784].forEach((f, i) => this.tone(f, 0.28, { type: 'triangle', vol: v(0.1), at: i * 0.11 })); break;
      case 'level': [392, 523, 659, 784, 1047].forEach((f, i) => this.tone(f, 0.4, { type: 'triangle', vol: v(0.11), at: i * 0.1 })); break;
      case 'warn': this.tone(110, 0.5, { type: 'square', vol: v(0.06), to: 98 }); break;
      case 'talk': this.tone(440, 0.07, { type: 'triangle', vol: v(0.06) }); break;
      case 'zap': this.noise(0.18, { vol: v(0.16), freq: 6000, to: 900, q: 1.5 }); this.tone(1800, 0.12, { type: 'square', vol: v(0.04), to: 200 }); break;
      case 'combo': this.tone(660, 0.12, { type: 'triangle', vol: v(0.12) }); this.tone(990, 0.2, { type: 'triangle', vol: v(0.12), at: 0.07 }); this.noise(0.2, { vol: v(0.1), freq: 3000, to: 800 }); break;
    }
  }

  // ------------------------------------------------------- Hintergrundklänge
  ambient(kind) {
    if (kind === this.amb && this.ambOut) return;
    this.amb = kind && AMB[kind] ? kind : null;
    this.startAmbient();
  }

  stopAmbient() {
    clearInterval(this.ambTimer);
    this.ambTimer = null;
    const out = this.ambOut, c = this.ctx;
    this.ambOut = null;
    if (!out || !c) return;
    out.gain.setTargetAtTime(0, c.currentTime, 0.4);              // sanft ausblenden
    const nodes = this.ambNodes;
    setTimeout(() => { for (const n of nodes) { try { n.stop?.(); } catch {} n.disconnect(); } }, 2000);
  }

  startAmbient() {
    this.stopAmbient();
    const c = this.ctx, P = AMB[this.amb];
    if (!this.on || !c || !P) return;
    const out = c.createGain(), nodes = [out];
    out.gain.setValueAtTime(0.0001, c.currentTime);
    out.gain.setTargetAtTime(1, c.currentTime, 0.8);
    out.connect(c.destination);
    if (!this.brown) {                                             // braunes Rauschen, einmal erzeugt
      const buf = c.createBuffer(1, c.sampleRate * 4, c.sampleRate), d = buf.getChannelData(0);
      let last = 0;
      for (let i = 0; i < d.length; i++) { last = (last + 0.02 * (Math.random() * 2 - 1)) / 1.02; d[i] = last * 3.5; }
      this.brown = buf;
    }
    const [freq, vol] = P.bed;
    const src = c.createBufferSource(), f = c.createBiquadFilter(), g = c.createGain();
    src.buffer = this.brown; src.loop = true;
    f.type = 'lowpass'; f.frequency.value = freq;
    g.gain.value = vol;
    const lfo = c.createOscillator(), depth = c.createGain();       // langsames An- und Abschwellen
    lfo.frequency.value = 0.06 + Math.random() * 0.04; depth.gain.value = vol * 0.6;
    lfo.connect(depth).connect(g.gain);
    src.connect(f).connect(g).connect(out);
    src.start(); lfo.start();
    nodes.push(src, f, g, lfo, depth);
    for (const [hz, v] of P.drone ?? []) {
      const o = c.createOscillator(), og = c.createGain();
      o.frequency.value = hz; og.gain.value = v;
      o.connect(og).connect(out); o.start();
      nodes.push(o, og);
    }
    this.ambOut = out; this.ambNodes = nodes;
    this.ambTimer = setInterval(() => {
      if (!this.on || c.state !== 'running' || this.ambOut !== out) return;
      for (const [name, p] of P.events) if (Math.random() < p) this.ambEvent(name, out);
    }, 500);
  }

  ambEvent(name, dest) {
    const r = Math.random, o = { dest };
    switch (name) {
      case 'bird': { const f = 2300 + r() * 900; this.tone(f, 0.07, { ...o, vol: 0.018, to: f * 1.3 }); this.tone(f * 1.1, 0.09, { ...o, vol: 0.016, to: f * 1.4, at: 0.12 }); break; }
      case 'owl': this.tone(392, 0.32, { ...o, vol: 0.03, to: 370 }); this.tone(392, 0.5, { ...o, vol: 0.026, to: 350, at: 0.45 }); break;
      case 'cricket': for (let i = 0; i < 5; i++) this.tone(4600, 0.025, { ...o, type: 'triangle', vol: 0.006, at: i * 0.05 }); break;
      case 'frog': { const n = 2 + (r() * 2 | 0); for (let i = 0; i < n; i++) this.tone(120 + r() * 30, 0.12, { ...o, type: 'square', vol: 0.012, to: 85, at: i * 0.16 }); break; }
      case 'bubble': this.tone(200 + r() * 100, 0.1, { ...o, vol: 0.025, to: 700 + r() * 300 }); break;
      case 'drip': { const f = 1300 + r() * 700; this.tone(f, 0.08, { ...o, vol: 0.03, to: f * 0.45 }); this.tone(f, 0.08, { ...o, vol: 0.008, to: f * 0.45, at: 0.22 }); break; }
      case 'hammer': for (let i = 0; i < 3; i++) this.tone(260, 0.05, { ...o, type: 'square', vol: 0.006, to: 180, at: i * 0.55 }); break;
      case 'whisper': this.noise(1.4, { ...o, vol: 0.02, freq: 1500 + r() * 800, to: 700, q: 5 }); break;
      case 'crow': this.noise(0.22, { ...o, vol: 0.035, freq: 950, to: 650, q: 7 }); this.noise(0.22, { ...o, vol: 0.03, freq: 900, to: 600, q: 7, at: 0.3 }); break;
    }
  }
}
