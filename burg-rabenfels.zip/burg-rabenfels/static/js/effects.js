// Kurzlebige Effekte: Hiebe, Ringe, Einschläge, Funken und schwebende Zahlen.
import * as THREE from 'three';

// Marken am Boden: normal gemischt, damit Feuer orange und Frost blau bleibt – auch auf hellem Untergrund
const markMat = (color, opacity = 1) => new THREE.MeshBasicMaterial({ color, transparent: true, opacity, depthWrite: false, side: THREE.DoubleSide });
const glowMat = (color, opacity = 1) => new THREE.MeshBasicMaterial({
  color, transparent: true, opacity, blending: THREE.AdditiveBlending, depthWrite: false, side: THREE.DoubleSide,
});

export class Effects {
  constructor(scene, layer, project) {
    this.scene = scene;
    this.layer = layer;            // DOM-Ebene für Zahlen
    this.project = project;        // (x, y, z) -> { x, y, ok }
    this.items = [];
    this.texts = [];
    this.shake = 0;
    this.ringGeo = new THREE.RingGeometry(0.88, 1, 56);
    this.discGeo = new THREE.CircleGeometry(1, 44);
    this.bitGeo = new THREE.BoxGeometry(0.14, 0.14, 0.14);
    this.tubeGeo = new THREE.CylinderGeometry(0.85, 0.85, 1, 22, 1, true).translate(0, 0.5, 0);
  }

  spawn(obj, life, tick) {
    this.scene.add(obj);
    this.items.push({ obj, life, age: 0, tick });
    return obj;
  }

  flat(geo, mat, x, z, y = 0.07) {
    const m = new THREE.Mesh(geo, mat);
    m.rotation.x = -Math.PI / 2;
    m.position.set(x, y, z);
    return m;
  }

  update(dt) {
    for (let i = this.items.length - 1; i >= 0; i--) {
      const it = this.items[i];
      it.age += dt;
      const k = Math.min(1, it.age / it.life);
      it.tick(k, dt, it.obj);
      if (k >= 1) {
        this.scene.remove(it.obj);
        it.obj.traverse(o => { o.material?.dispose?.(); if (o.geometry?.userData.own) o.geometry.dispose(); });
        this.items.splice(i, 1);
      }
    }
    for (let i = this.texts.length - 1; i >= 0; i--) {
      const t = this.texts[i];
      t.age += dt;
      const k = t.age / t.life;
      if (k >= 1) { t.el.remove(); this.texts.splice(i, 1); continue; }
      const p = this.project(t.x, t.y + k * 1.6, t.z);
      t.el.style.opacity = p.ok ? String(1 - k * k * k) : '0';
      t.el.style.transform = `translate(${p.x.toFixed(1)}px, ${p.y.toFixed(1)}px) translate(-50%, -50%)`;
    }
    this.shake *= Math.exp(-7 * dt);
  }

  text(x, y, z, str, cls = '', life = 0.95, color = null) {
    if (this.texts.length > 60) this.texts.shift().el.remove();
    const el = document.createElement('div');
    el.className = 'ft ' + cls;
    el.textContent = str;
    if (color) el.style.color = color;
    el.style.opacity = '0';
    this.layer.append(el);
    this.texts.push({ el, x: x + (Math.random() - 0.5) * 0.7, y, z: z + (Math.random() - 0.5) * 0.4, age: 0, life });
  }

  // Schwertbogen oder Kegel in Blickrichtung `rot`, `len` = Öffnungswinkel
  slash(x, z, rot, range, color = 0xfff0cf, len = 2.0) {
    const geo = new THREE.RingGeometry(range * 0.4, range, 22, 1, rot - Math.PI / 2 - len / 2, len);
    geo.userData.own = true;
    this.spawn(this.flat(geo, glowMat(color, 0.8), x, z, 1.0), 0.2, (k, dt, o) => {
      o.material.opacity = 0.8 * (1 - k);
      const s = 0.82 + 0.22 * k;
      o.scale.set(s, s, 1);
    });
  }

  ring(x, z, r, color, dur = 0.55, faint = false) {
    const g = new THREE.Group();
    const edge = this.flat(this.ringGeo, markMat(color, 0.95), x, z, 0.12);
    const soft = (faint ? 0.08 : 0.22) * Math.min(1, 3 / r);   // große Ringe füllen nur zart, damit man den Kampf noch sieht
    const fill = this.flat(this.discGeo, markMat(color, soft), x, z, 0.1);
    g.add(edge, fill);
    this.spawn(g, dur, k => {
      const s = r * (0.15 + 0.85 * (1 - (1 - k) ** 3));
      edge.scale.set(s, s, 1); fill.scale.set(s, s, 1);
      edge.material.opacity = 0.95 * (1 - k); fill.material.opacity = soft * (1 - k);
    });
  }

  // Warnkreis am Boden, der sich bis zum Einschlag füllt
  telegraph(x, z, r, dur, color = 0xff3a28) {
    const g = new THREE.Group();
    const edge = this.flat(this.ringGeo, markMat(color, 0.9), x, z, 0.09);
    const fill = this.flat(this.discGeo, markMat(color, 0.3), x, z, 0.08);
    edge.scale.set(r, r, 1);
    g.add(edge, fill);
    this.spawn(g, dur, k => {
      const s = Math.max(0.01, r * k);
      fill.scale.set(s, s, 1);
      edge.material.opacity = 0.6 + 0.3 * Math.sin(k * 30);
    });
  }

  // Brocken, der während der Vorwarnzeit auf den Zielpunkt stürzt
  meteor(x, z, r, delay, color = 0xffb04a) {
    const rock = new THREE.Mesh(new THREE.IcosahedronGeometry(Math.min(1.6, 0.4 + r * 0.14), 0), new THREE.MeshBasicMaterial({ color }));
    rock.geometry.userData.own = true;
    this.spawn(rock, delay, k => {
      const u = 1 - k * k;
      rock.position.set(x + 7 * u, 22 * u + 0.4, z - 5 * u);
      rock.rotation.x += 0.2; rock.rotation.z += 0.13;
    });
  }

  // Einschlag: klein für Geschosse, groß (mit Erschütterung) für Meteore und Bodenschläge
  boom(x, z, r, color, big = false) {
    if (big) {
      this.ring(x, z, r, color, 0.6); this.ring(x, z, r * 0.6, 0xfff4dc, 0.4);
      this.burst(x, 0.5, z, color, Math.min(30, 10 + r * 3 | 0), 4 + r);
      this.shake = Math.min(1.2, this.shake + 0.1 * r);
    } else if (r > 1) { this.ring(x, z, r, color, 0.35); this.burst(x, 0.9, z, color, 8); }
    else this.burst(x, 1.0, z, color, 4, 3);
  }

  // Blitz entlang einer Punktfolge [[x, z], ...] – leicht gezackt
  bolt(pts, color) {
    const g = new THREE.Group(), mat = glowMat(color, 1);
    const seg = (ax, az, bx, bz) => {
      const len = Math.hypot(bx - ax, bz - az);
      const m = new THREE.Mesh(this.bitGeo, mat);
      m.position.set((ax + bx) / 2, 1.2, (az + bz) / 2);
      m.rotation.y = Math.atan2(bx - ax, bz - az);
      m.scale.set(0.9, 0.9, len / 0.14);
      g.add(m);
    };
    for (let i = 1; i < pts.length; i++) {
      let [ax, az] = pts[i - 1];
      const [bx, bz] = pts[i], n = Math.max(2, Math.round(Math.hypot(bx - ax, bz - az) / 1.6));
      for (let k = 1; k <= n; k++) {
        const t = k / n, j = k < n ? 0.5 : 0;
        const nx = pts[i - 1][0] + (bx - pts[i - 1][0]) * t + (Math.random() - 0.5) * j;
        const nz = pts[i - 1][1] + (bz - pts[i - 1][1]) * t + (Math.random() - 0.5) * j;
        seg(ax, az, nx, nz); ax = nx; az = nz;
      }
      this.burst(bx, 1.2, bz, color, 4, 3);
    }
    this.spawn(g, 0.28, k => { mat.opacity = 1 - k * k; });
  }

  // Schweif eines Sprungs oder Ansturms
  trail(x0, z0, x1, z1, color) {
    const len = Math.hypot(x1 - x0, z1 - z0);
    if (len < 0.3) return;
    const m = new THREE.Mesh(this.bitGeo, glowMat(color, 0.7));
    m.position.set((x0 + x1) / 2, 0.9, (z0 + z1) / 2);
    m.rotation.y = Math.atan2(x1 - x0, z1 - z0);
    m.scale.set(4, 6, len / 0.14);
    this.spawn(m, 0.3, k => { m.material.opacity = 0.7 * (1 - k); m.scale.x = 4 * (1 - k * 0.7); });
  }

  // Lichtsäule, die einer Figur folgt (Stufenaufstieg, Segen, Kriegsschrei)
  pillar(target, color, dur = 1.3, height = 6) {
    const m = new THREE.Mesh(this.tubeGeo, glowMat(color, 0.5));
    this.spawn(m, dur, k => {
      m.position.set(target.x, 0.05, target.z);
      m.scale.set(1 + k * 0.5, height * Math.min(1, k * 4), 1 + k * 0.5);
      m.material.opacity = 0.5 * (1 - k);
      m.rotation.y += 0.05;
    });
  }

  burst(x, y, z, color, n = 8, speed = 4.5) {
    const g = new THREE.Group();
    const mat = new THREE.MeshBasicMaterial({ color });
    const bits = [];
    for (let i = 0; i < n; i++) {
      const b = new THREE.Mesh(this.bitGeo, mat);
      b.position.set(x, y, z);
      const a = Math.random() * 6.283, v = speed * (0.4 + Math.random() * 0.6);
      bits.push([b, Math.sin(a) * v, 2 + Math.random() * 4, Math.cos(a) * v]);
      g.add(b);
    }
    this.spawn(g, 0.55, (k, dt) => {
      for (const bit of bits) {
        const b = bit[0];
        bit[2] -= 16 * dt;
        b.position.x += bit[1] * dt; b.position.y = Math.max(0.07, b.position.y + bit[2] * dt); b.position.z += bit[3] * dt;
        b.scale.setScalar(1 - k * 0.9);
        b.rotation.x += 0.3; b.rotation.y += 0.2;
      }
    });
  }
}
