# Burg Rabenfels

Ein Top-Down-Fantasyspiel in 3D für mehrere Spieler. Ihr erkundet eine kleine Burg, nehmt bei
den Bewohnern Quests an, verteilt Attribute, baut euch im Skilltree euren Helden und steigt
in die endlosen Katakomben unter der Kapelle hinab – bis Stufe 100.

- **Server:** Python mit Flask und Flask-SocketIO
- **Darstellung:** Three.js im Browser (liegt dem Projekt bei, es wird nichts aus dem Internet geladen)
- **Speicherstände:** werden automatisch unter `saves/charaktere.json` angelegt

## Starten

**Windows:** `start.bat` doppelklicken. Beim ersten Mal wird eine eigene Python-Umgebung
eingerichtet (braucht einmalig Internet), danach startet das Spiel direkt.

**Von Hand** (Python 3.9 oder neuer):

```
python -m venv .venv
.venv\Scripts\activate          (Linux/macOS: source .venv/bin/activate)
pip install -r requirements.txt
python app.py
```

Dann im Browser **http://localhost:5000** öffnen, Namen eintragen, Klasse wählen, Burg betreten.
## Die Gebiete

| Gebiet | Gegnerstufe | Zugang | Bewohner | Boss |
| --- | --- | --- | --- | --- |
| Burg Rabenfels und Umland | 1–8 | – | Gerold, Marthe, Bruna, Anselm, Adelheid | Knochenfürst Morwen |
| Dunkler Wald | 6–10 | südlich des Goblinlagers | Waldläuferin Irma | Häuptling Grukmar |
| Das Moor | 11–20 | Pfad am Südostrand des Waldes | Kräuterfrau Wilma | Sumpfhexe Mirra |
| Zwergenmine Grauhall | 21–30 | östlich der Trollfurt im Moor | Borin Grauhand | Glutherz, der Eiserne Wächter |
| Steinbruchtal | 31–40 | Westrand des Burggebiets | Steinmetzin Hedda | Feldherr Graufang |
| Ruinen von Altrabenfels | 41–50 | Nordostecke des Steinbruchtals | Ritter Konrad | Der Rabenkönig |
| Katakomben | endlos, ab 8 | Treppe hinter dem Altar der Kapelle | Totenwächter Kaspian | Gruftlord alle 5 Ebenen |

Jeder Bewohner eines Gebiets hat eine Questreihe, die mit dem Boss endet, und dazu eine
wiederholbare Quest, die nach der Heldenstufe zahlt. Das Ende jeder Reihe verweist auf das nächste Gebiet.

Ein anderer Port: vor dem Start `set PORT=8080` (Linux/macOS: `PORT=8080 python app.py`).

## Zusammen spielen

Der Server zeigt beim Start zwei Adressen an. Die zweite (`http://192.168.x.x:5000`) geben
Mitspieler im selben Netzwerk in ihren Browser ein. Fragt die Windows-Firewall beim ersten
Start nach, den Zugriff für private Netzwerke erlauben. Bis zu 12 Spieler passen in die Burg.

Wer nah beieinander kämpft, teilt Erfahrung, Gold und Questfortschritt. Zu mehreren werden
Bosse und Katakomben zäher – dafür zünden Kombos auch auf Zuständen, die ein Gefährte verursacht hat.

## Steuerung

| Taste | Wirkung |
| --- | --- |
| W A S D | laufen |
| Linke Maustaste oder Leertaste | angreifen, wohin die Maus zeigt |
| 1 bis 4 | Fähigkeiten (rechte Maustaste = Taste 1) |
| K | Skilltree: lernen, verbessern, Tasten belegen, Kombo-Übersicht |
| C | Charakterbogen: Attributpunkte verteilen |
| Q | Heiltrank trinken |
| E | mit Burgbewohnern sprechen |
| Mausrad | Kamera näher oder weiter |
| Enter | Chat |
| G / M | Grafikqualität / Ton |
| H | Hilfe |

Läuft das Spiel nicht flüssig, stellt es die Grafik selbst eine Stufe herunter.

## Charakter

Jede Stufe (bis 100) bringt **3 Attributpunkte** und **1 Fähigkeitspunkt**.

| Attribut | Wirkung |
| --- | --- |
| Stärke | Schaden des Kriegers, größerer Ausdauervorrat |
| Geschick | Schaden des Waldläufers, mehr kritische Treffer, höheres Lauftempo |
| Intelligenz | Schaden des Magiers, mehr Mana, kürzere Abklingzeiten |
| Vitalität | Leben, etwas Rüstung, Lebensregeneration |

Fähigkeiten kosten **Mana** (Magier) oder **Ausdauer** (Krieger, Waldläufer); beides erholt sich
von selbst. Burgherrin Adelheid setzt Attribute und Fähigkeiten gegen Gold zurück.

## Skilltree

Jede Klasse hat drei Zweige mit zusammen **20 aktiven und 9 passiven Fähigkeiten**. Vier aktive
legt ihr auf die Tasten 1 bis 4 – im Fähigkeitenfenster (K) frei wählbar. Jede Fähigkeit lässt
sich bis Stufe 5 verbessern (+12 % Wirkung je Stufe). Tiefere Knoten verlangen eine Heldenstufe
und Punkte im selben Zweig.

| Klasse | Zweige |
| --- | --- |
| Krieger | Waffenmeister (Klingen, Blutungen), Bollwerk (Schutz, Wucht), Berserker (Ansturm, Raserei) |
| Magier | Feuer (Brände, Einschläge), Frost (Gefrieren, Schutz), Sturm (Blitze, Arkanes, Blinzeln) |
| Waldläufer | Scharfschütze (Präzision, Markierung), Wildnis (Gift, Fallen, Heilung), Schattenläufer (Ausweichen) |
| Paladin | Richter (Licht, Blenden), Bewahrer (Heilung, Schilde, Auren), Kreuzritter (Hammer, Ansturm) |

## Kombos

Manche Fähigkeiten hinterlassen einen **Zustand** auf dem Gegner (farbiger Punkt unter seinem
Lebensbalken). Trifft ihn danach die passende **Schadensart**, zündet die Kombo und verbraucht
den Zustand – egal, wer von euch welchen Teil beisteuert.

| Kombo | Zustand + Treffer | Wirkung |
| --- | --- | --- |
| Zersplittern | Gefroren + Wucht | doppelter Schaden, Eissplitter treffen alle im Umkreis |
| Thermoschock | Gefroren + Feuer oder Brennend + Frost | +80 % Schaden, Betäubung |
| Flächenbrand | Vergiftet + Feuer oder Brennend + Gift | +60 % Schaden, setzt alle im Umkreis in Brand |
| Ausbrennen | Blutend + Feuer | +70 % Schaden, das Ziel fängt Feuer |
| Ausbluten | Blutend + Stich | +50 % Schaden, restliche Blutung sofort und doppelt |
| Überladung | Geschockt + Stich oder Schnitt | +50 % Schaden, Kettenblitz auf bis zu drei weitere |
| Hinrichten | Wankend + Schnitt | +90 % Schaden, noch mehr gegen fast besiegte Gegner |
| Volltreffer | Markiert + Stich, Schnitt oder Wucht | sicherer kritischer Treffer, +50 % Schaden |
| Richtspruch | Geblendet + Wucht oder Wankend + Licht | +60 % Schaden, Lichtschlag auf alle im Umkreis |
| Läuterung | Geblendet + Feuer oder Brennend + Licht | +70 % Schaden, Betäubung |
| Reinigung | Vergiftet + Licht | +50 % Schaden, restliches Gift sofort und doppelt |

Allein geht das auch: Der Magier friert mit der Frostnova ein und zündet mit dem Feuerball,
der Krieger bringt mit dem Schildstoß ins Wanken und richtet mit dem Schwert hin, der Waldläufer
markiert und schießt, der Paladin blendet mit dem Lichtschlag und trifft mit dem Hammer nach.
Im Fähigkeitenfenster zeigt der Reiter „Kombos“, was ihr schon könnt.

## Bosse und Elite-Gegner

Jeder Boss hat eigene **Sonderangriffe**, die sich vorher als rote Kreise auf dem Boden ankündigen:
Bodenschlag, Kegel vor ihm, Sturmangriff quer durch die Arena, Geschossfächer, Ring um ihn herum
oder Einschläge vom Himmel. Bei halbem Leben ruft er Diener, unter einem Viertel gerät er in
**Raserei**: Er glüht rot, wird schneller und greift öfter an.

Feste Gegner erscheinen manchmal als **Elite** – goldener Name, etwas größer und mit einer Eigenart:
zäh (viel Leben), flink (schnell), wütend (harte Schläge) oder blutdurstig (heilt sich an dir).
Sie bringen dreifache Erfahrung und dreifaches Gold und lassen oft Beute fallen.

## Beute, Elixiere und Schmied

Gegner lassen manchmal **Ringe und Amulette** fallen – Elite-Gegner oft, Bosse immer. Jedes Stück
hat ein bis vier zufällige Werte (Angriffskraft, Leben, kritische Treffer, Tempo und mehr), je
nach Seltenheit: gewöhnlich, magisch, selten, legendär. Im Charakterbogen (C) legt ihr sie an
oder verkauft sie; in der Tasche ist Platz für zehn.

Marthe, Wilma, Borin und Konrad verkaufen **Elixiere** für zehn Minuten: Kraft (+15 % Schaden),
Steinhaut (12 % weniger Schaden) und Weisheit (+25 % Erfahrung). Sie wirken auch nach dem Abmelden
weiter, ein zweites verlängert die Dauer.

Bruna, Borin und Konrad schmieden Waffe (+4 % Schaden je Stufe) und Rüstung (+3 % Leben je Stufe)
bis Stufe 40 – ab Stufe 26 wird jede Stufe deutlich teurer.

## Die Katakomben

Hinter dem Altar der Kapelle führt eine Treppe hinab. In der Vorhalle wartet Totenwächter
Kaspian, dahinter liegt die Halle der Gebeine. Wer sie betritt, weckt die Toten der nächsten
**Ebene** – jede Ebene ist eine Gegnerstufe stärker, es gibt kein Ende.

- Auf jeder fünften Ebene wacht ein **Gruftlord**. Danach könnt ihr bei Kaspian später direkt
  auf der folgenden Ebene wieder einsteigen.
- Verlasst ihr die Halle oder fallt alle, legt sie sich nach sechs Sekunden schlafen und
  beginnt dieselbe Ebene von vorn. Wer fällt, steht in der Vorhalle wieder auf.
- Ebene 1 entspricht Gegnerstufe 8 – ein guter Zeitpunkt ist nach dem Knochenfürsten.

## Die Quests

1. **Rattenplage** – Hauptmann Gerold, vor dem Bergfried
2. **Gestohlene Vorräte** – Köchin Marthe, Küche im Westflügel
3. **Goblins vor dem Tor** – Hauptmann Gerold
4. **Zusammenspiel** – Burgherrin Adelheid: zehn Kombos auslösen
5. **Erz für die Esse** – Schmiedin Bruna (Belohnung: eine Schmiedestufe)
6. **Unruhige Tote** – Bruder Anselm, Kapelle (ab Stufe 3)
7. **Der Knochenfürst** – Bruder Anselm (ab Stufe 5, am besten zu mehreren)
8. **Hinab in die Katakomben** – Bruder Anselm, danach bei Kaspian Ebene 10, 25 und 50
9. **Knochenernte** (Kaspian) und **Wachdienst** (Adelheid) – beliebig oft wiederholbar

Danach geht es bei Irma im dunklen Wald weiter (ab Stufe 6), dann bei Wilma im Moor (ab 11), bei
Borin in der Mine (ab 21), bei Hedda im Steinbruchtal (ab 31) und bei Konrad in den Ruinen (ab 41).

Marthe verkauft Heiltränke und Elixiere, Anselm heilt kostenlos.

## Aufbau des Projekts

```
app.py                 Flask-Server, Socket.IO-Ereignisse, Spielschleife (20 Schritte pro Sekunde)
content/               alles, was es im Spiel gibt – als Daten (siehe „Erweitern“)
  grundlagen.py          Schadensarten, Zustände, Kombos, Questgegenstände, Aussehen-Vorlagen
  gegner.py              Gegnerarten
  klassen/               je Klasse eine Datei: Werte, Aussehen, Skilltree
  karten/                je Karte eine Datei: Plan, Bewohner, Gegnergebiete, Übergänge, Verlies
  quests/                Quests, nach Gebiet gebündelt
game/registry.py       Anmelde-Funktionen für Inhalte und ihre Prüfung
game/world.py          baut aus den Karten die Welt: Kollision, Wegfindung, Übergänge
game/engine.py         Spiellogik: Kampf, Fähigkeiten, Kombos, Gegner-KI, Verliese, Speichern
game/data.py           feste Regeln: Höchststufe, Punkte je Stufe, Preise, Wachstumskurven
tools/neu.py           legt Gerüste für neue Klassen, Karten, Gegner und Quests an
tools/pruefen.py       prüft die Inhalte, zeigt Karten und Skilltrees, spielt alles einmal durch
AGENTS.md              Anleitung für KI-Agenten, die Inhalte hinzufügen
test_spiel.py          prüft die Spiellogik ohne Browser
templates/index.html   Seite mit Anmeldung und Anzeige
static/js/main.js      Ablauf im Browser: Netzwerk, Eingabe, Kamera
static/js/world.js     baut die Karten in 3D aus den Daten des Servers
static/js/entities.js  Figuren, Geschosse, Felder und ihre Animation
static/js/effects.js   Hiebe, Ringe, Blitze, Einschläge, schwebende Zahlen
static/js/ui.js        Balken, Aktionsleiste, Charakterbogen, Skilltree, Dialoge, Minimap
static/js/sfx.js       Klänge (im Browser erzeugt, keine Dateien)
static/vendor/         Three.js und Socket.IO-Client
```

Der Server entscheidet alles, was zählt: Treffer, Schaden, Kombos, Beute, Questfortschritt. Nur
die eigene Bewegung rechnet der Browser voraus, damit sie sich direkt anfühlt – der Server prüft
Tempo und Mauern nach. Jeder Held bekommt nur zu sehen, was auf seiner Karte geschieht.

## Erweitern

Klassen, Karten, Quests und Gegner sind reine Daten unter `content/`. Der Server lädt beim Start
jede Datei dort; Figuren, Symbole, Dialoge und Minimap entstehen im Browser aus diesen Daten.
Für neue Inhalte muss weder die Spiellogik noch JavaScript angefasst werden.

```
python tools/neu.py klasse paladin --name Paladin --stil klinge
python tools/neu.py karte  moor --name "Das Moor" --groesse 34x26
python tools/neu.py karte  mine --name "Alte Mine" --licht dunkel --verlies
python tools/neu.py gegner moorwolf --name Moorwolf --stufe 4 --tier
python tools/neu.py quest  wolfsjagd --npc moor_hueter --ziel moorwolf --anzahl 5
```

Jeder Aufruf legt eine gültige, sofort spielbare Datei an: die Klasse mit 20 aktiven und 9 passiven
Fähigkeiten, die Karte mit Bewohner, Gegnergebiet, Rückweg und einem Eingang im Burghof. Danach
passt man Namen, Texte und Werte an.

```
python tools/pruefen.py                 alle Inhalte prüfen – Fehler mit Datei und Ursache
python tools/pruefen.py --karte moor    Plan mit Zahlenleiste, Bewohnern, Zonen, Übergängen
python tools/pruefen.py --klasse paladin
python tools/pruefen.py --spiel         Probelauf: jede Fähigkeit, jeder Übergang, jede Quest
python test_spiel.py                    vollständiger Test der Spiellogik
```

**Für KI-Agenten** (Claude Code, Codex, Cursor und ähnliche) liegt die vollständige Anleitung in
[`AGENTS.md`](AGENTS.md): Arbeitsablauf, alle Angaben, Zeichen des Kartenplans, Richtwerte für die
Balance und die Stellen im Code für alles, was über Daten hinausgeht. Ein Auftrag wie „Lies
AGENTS.md und füge eine Klasse Nekromant und eine Sumpfkarte mit drei Quests hinzu“ genügt.

Die Schwierigkeit insgesamt regeln `enemy_hp_mult`, `enemy_dmg_mult`, `enemy_xp` und `xp_needed`
in `game/data.py`.

### Entwicklermodus

Mit `set RABENFELS_DEV=1` vor dem Start (Linux/macOS: `RABENFELS_DEV=1 python app.py`) gibt es
Befehle im Chat: `/tp x z` (zu einer Kachel der aktuellen Karte springen), `/tp karte x z` (auf
eine andere Karte, z. B. `/tp katakomben 15 5`), `/lvl n`, `/gold n`, `/tiefe n` (tiefste
geschaffte Ebene im Verlies setzen), `/beute n` (n Ringe und Amulette deiner Stufe) und `/elite`
(der nächste feste Gegner kehrt sofort als Elite zurück).

`RABENFELS_CONTENT=ordner` lädt einen weiteren Inhaltsordner zusätzlich zu `content/` – praktisch,
um neue Inhalte auszuprobieren, bevor sie ins Spiel wandern.

## Gut zu wissen

- Charaktere hängen nur am Namen, ein Passwort gibt es nicht. Für Runden mit Freunden im
  Heimnetz reicht das; für einen öffentlichen Server im Internet ist das Spiel so nicht gedacht.
- Speicherstände aus der ersten Fassung laden weiter: Stufe, Gold und Quests bleiben, die
  Attribut- und Fähigkeitspunkte stehen zum Verteilen bereit.
- Die Stärke der Gegner und das Tempo des Aufstiegs sind per Simulation eingestellt, nicht in
  langen Runden erspielt. Fühlt sich etwas zu leicht oder zu zäh an: Die Stellschrauben stehen
  oben unter „Erweitern“.
- Die Gerüste aus `tools/neu.py` sind spielbar, aber bewusst schlicht: gleichmäßig verteilte
  Felsen oder Säulen, Fähigkeiten mit Allerweltsnamen. Ihren Charakter bekommen sie erst durch
  die Anpassung.
- Gespielt wird mit Maus und Tastatur. Eine Steuerung für Handys gibt es nicht.
- Gebraucht wird ein aktueller Browser mit WebGL (Chrome, Edge, Firefox).

## Lizenzen der beigelegten Bibliotheken

Three.js und der Socket.IO-Client stehen unter der MIT-Lizenz, die Lizenztexte liegen in
`static/vendor/`.
