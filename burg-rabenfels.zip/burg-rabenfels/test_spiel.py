"""Prüft die Spiellogik ohne Netzwerk und Browser.  Aufruf:  python test_spiel.py

Helden spielen im Zeitraffer: Quests, Attribute, Skilltree, Tastenbelegung, jede Fähigkeit,
jede Kombo, Übergänge zwischen Karten, Verlies, Bosse, Speichern und Laden. Am Ende meldet der
Test zusätzlich eine neue Klasse, eine neue Karte und eine neue Quest nur über Inhaltsdateien an
(tools/neu.py) und spielt sie durch. Nützlich nach jeder Änderung unter content/ oder game/.
"""
import json
import math
import os
import random
import subprocess
import sys
import tempfile

ROOT = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, ROOT)
sys.stdout.reconfigure(encoding='utf-8', errors='replace')
import game
from game import registry as R, world as W
import game.engine as E
from game.engine import Game, TICK
from game.data import (ATTR_POINTS, BAR_SLOTS, MAX_LEVEL, MAX_RANK, PLAYER_SPEED, gear_price, potion_price,
                       respec_price, xp_needed)
from game.registry import CLASSES, COMBOS, ENEMIES, QUESTS, SKILLS, STATUS

game.load()
random.seed(3)
clock = [5000.0]
E.time.time = lambda: clock[0]
log = []
tmp = os.path.join(tempfile.mkdtemp(), 'saves', 'c.json')
g = Game(lambda ev, data, to=None: log.append((ev, data, to)), tmp, dev=True)


def step(n=1):
    for _ in range(n):
        clock[0] += TICK
        g.tick(clock[0], TICK)


def wait(seconds):
    step(int(seconds / TICK))


def tp(p, tx, tz, karte='burg'):
    """Setzt einen Helden auf eine Kachel der genannten Karte."""
    p.x, p.z = W.to_world(karte, tx, tz)
    p.budget = 4


def fx(kind, sid='a'):
    """Effekte, die der Held `sid` zu sehen bekam (jeder Held erhält die Momentaufnahme seiner Karte)."""
    return [f for ev, d, to in log if ev == 'state' and to == sid for f in d['fx'] if f['t'] == kind]


def near(p, npc, dz=0.6):
    n = W.NPCS[npc]
    p.x, p.z = n['x'] * W.TILE, (n['z'] + dz) * W.TILE
    p.budget = 4


def foes(kind):
    return [e for e in g.enemies.values() if not e.dead and e.kind == kind]


# ---------------------------------------------------------------- Daten
for cls in CLASSES:
    act = [s for s in SKILLS.values() if s['cls'] == cls and s['type'] == 'active']
    pas = [s for s in SKILLS.values() if s['cls'] == cls and s['type'] == 'passive']
    assert len(act) >= 20 and len(pas) >= 9, (cls, len(act), len(pas))
    assert SKILLS[CLASSES[cls]['start']]['lvl'] == 1 and SKILLS[CLASSES[cls]['start']]['need'] == 0
for q in QUESTS.values():
    assert q['npc'] in W.NPCS and (q['req'] is None or q['req'] in QUESTS)
assert not R.NOTES, 'Offene Hinweise aus tools/pruefen.py:\n  - ' + '\n  - '.join(R.NOTES)
for combo in COMBOS:                       # jede Kombo ist erreichbar: jemand verursacht den Zustand, jemand trifft mit der Art
    for status, tag in combo['pairs']:
        assert any(s.get('apply') == status for s in SKILLS.values()), status
        assert any(s.get('tag') == tag and s.get('mult') for s in SKILLS.values()) or any(c['atk']['tag'] == tag for c in CLASSES.values())
print('Daten: %d Klassen mit je mindestens 20 aktiven und 9 passiven Fähigkeiten, %d Kombos, %d Quests' % (len(CLASSES), len(COMBOS), len(QUESTS)))

# ------------------------------------------------------------ Anmeldung
assert 'error' in g.join('a', 'x', 'krieger') and 'error' in g.join('a', 'Tyra', 'nix') and 'error' in g.join('a', '<b>Tyra</b>', 'krieger')
r = g.join('a', 'Tyra', 'krieger')
assert r['ok'] and r['you']['bar'] == ['wirbel', None, None, None] and r['you']['ap'] == 0 and r['you']['sp'] == 0
assert 'error' in g.join('b', 'tyra', 'magier') and g.join('b', 'Borin', 'magier')['ok'] and g.join('c', 'Lia', 'waldlaeufer')['ok']
A, B, C = g.players['a'], g.players['b'], g.players['c']
tp(C, 3, 40)                               # Lia wartet abseits

# ----------------------------------------- Quests: Reichweite, Voraussetzungen, geteilter Fortschritt
tp(A, 30, 40); g.on_quest('a', {'id': 'ratten', 'do': 'accept'}); assert 'ratten' not in A.quests
near(A, 'gerold'); near(B, 'gerold', 0.9)
g.on_quest('a', {'id': 'goblins', 'do': 'accept'}); assert 'goblins' not in A.quests
g.on_quest('a', {'id': 'ratten', 'do': 'turnin'}); assert 'ratten' not in A.quests
g.on_quest('a', {'id': 'ratten', 'do': 'accept'}); g.on_quest('b', {'id': 'ratten', 'do': 'accept'})
tp(A, 12.5, 9); tp(B, 13.5, 10); t0 = clock[0]
while A.quests['ratten']['s'] != 'ready' and clock[0] - t0 < 180:
    step()
    for sid, P in (('a', A), ('b', B)):
        rats = foes('rat')
        if rats and not P.dead:
            e = min(rats, key=lambda e: math.hypot(e.x - P.x, e.z - P.z))
            g.on_attack(sid, {'x': e.x, 'z': e.z})
assert A.quests['ratten']['s'] == 'ready' and B.quests['ratten']['s'] == 'ready', (A.quests, B.quests)
print('Rattenquest zu zweit in %.0f s, Stufe %d und %d' % (clock[0] - t0, A.level, B.level))
near(A, 'gerold'); gold = A.gold
g.on_quest('a', {'id': 'ratten', 'do': 'turnin'}); assert A.quests['ratten']['s'] == 'done' and A.gold == gold + 15
g.on_quest('a', {'id': 'ratten', 'do': 'turnin'}); assert A.gold == gold + 15           # nicht doppelt
g.on_quest('a', {'id': 'ratten', 'do': 'accept'}); assert A.quests['ratten']['s'] == 'done'   # nicht wiederholbar
g.on_quest('a', {'id': 'goblins', 'do': 'accept'}); assert A.quests['goblins']['s'] == 'active'
g.on_quest('a', {'id': 'tote', 'do': 'accept'}); assert 'tote' not in A.quests          # Voraussetzung fehlt
assert A.level >= 2 and A.ap() == (A.level - 1) * ATTR_POINTS and A.sp() == A.level - 1

# ------------------------------------------------------------ Attribute
hp0, pow0, ap0 = A.max_hp, A.stats['power'], A.ap()
g.on_attr('a', {'k': 'vit', 'n': 1}); assert A.attrs['vit'] == 6 and A.max_hp == hp0 + 8 and A.ap() == ap0 - 1
g.on_attr('a', {'k': 'str', 'n': 999}); assert A.ap() == 0 and A.stats['power'] > pow0  # nie mehr als vorhanden
before = dict(A.attrs)
g.on_attr('a', {'k': 'str', 'n': 1}); g.on_attr('a', {'k': 'nix', 'n': 1}); g.on_attr('a', {'k': 'vit', 'n': -5})
assert A.attrs == before

# ------------------------------------------------- Skilltree und Tastenbelegung
A.level = 6; A.recalc()                    # Stufe 6: fünf Punkte frei
assert A.sp() == 5
g.on_learn('a', {'id': 'ausfall'}); assert 'ausfall' not in A.skills                   # erst ab Stufe 8
g.on_learn('a', {'id': 'p_klinge'}); assert 'p_klinge' not in A.skills                 # braucht 2 Punkte im Zweig
g.on_learn('a', {'id': 'feuerlanze'}); assert 'feuerlanze' not in A.skills             # fremde Klasse
g.on_learn('a', {'id': 'aderschnitt'}); assert A.skills['aderschnitt'] == 1 and A.bar == ['wirbel', 'aderschnitt', None, None]
pw = A.stats['power'] * (1 + A.tag_bonus['schnitt'])
g.on_learn('a', {'id': 'p_klinge'}); assert A.skills['p_klinge'] == 1 and abs(A.tag_bonus['schnitt'] - 0.04) < 1e-9 and 'p_klinge' not in A.bar
g.on_learn('a', {'id': 'schildstoss'}); g.on_learn('a', {'id': 'sturm'}); assert A.bar == ['wirbel', 'aderschnitt', 'schildstoss', 'sturm']
g.on_learn('a', {'id': 'wirbel'}); assert A.skills['wirbel'] == 2 and A.sp() == 0
g.on_learn('a', {'id': 'wirbel'}); assert A.skills['wirbel'] == 2                      # kein Punkt mehr frei
g.on_bind('a', {'slot': 1, 'id': 'sturm'}); assert A.bar == ['sturm', 'aderschnitt', 'schildstoss', 'wirbel']   # tauscht die Plätze
g.on_bind('a', {'slot': 4, 'id': None}); assert A.bar[3] is None
g.on_bind('a', {'slot': 4, 'id': 'p_klinge'}); g.on_bind('a', {'slot': 4, 'id': 'henker'}); g.on_bind('a', {'slot': 9, 'id': 'wirbel'})
assert A.bar[3] is None                                                                # passiv, nicht gelernt, Taste gibt es nicht
g.on_bind('a', {'slot': 4, 'id': 'wirbel'})
A.level = 100; A.recalc(); A.skills['wirbel'] = MAX_RANK
g.on_learn('a', {'id': 'wirbel'}); assert A.skills['wirbel'] == MAX_RANK               # höchste Stufe
A.level = 6; A.skills['wirbel'] = 2; A.recalc()

# ------------------------------------------- Fähigkeiten wirken: Kosten, Abklingzeit, Antwort
tp(A, 24, 24); A.res = A.stats['res']; res0 = A.res
r = g.on_skill('a', {'n': 4, 'x': A.x + 1, 'z': A.z}); assert r['ok'] and abs(r['cd'] - 6 * (1 - A.stats['cdr'])) < 0.02 and A.res == res0 - 20
r = g.on_skill('a', {'n': 4, 'x': A.x + 1, 'z': A.z}); assert not r['ok'] and r['cd'] > 5                      # läuft noch ab
A.res = 5; r = g.on_skill('a', {'n': 2, 'x': A.x + 1, 'z': A.z}); assert r == {'ok': False, 'why': 'res'}       # zu wenig Ausdauer
g.on_bind('a', {'slot': 3, 'id': None}); assert g.on_skill('a', {'n': 3}) == {'ok': False} and g.on_skill('a', {'n': 7}) == {'ok': False}
wait(3); assert 5 < A.res < A.stats['res']                                                                     # erholt sich
x0 = A.x; A.res = 100
assert g.on_skill('a', {'n': 1, 'x': A.x + 20, 'z': A.z})['ok'] and 7.5 < A.x - x0 <= 8.01                     # Sturmangriff: 8 weit
assert [l for l in log if l[0] == 'correct' and l[1].get('dash')]

# -------------------------------------------------------------- Kombos
tp(A, 24, 42); tp(B, 24.5, 42.5); tp(C, 23.5, 42.5)


def dummy():
    """Ein frischer Goblin mit viel Leben direkt vor den Helden."""
    e = foes('goblin')[0]
    e.reset(); e.x, e.z = A.x + 1.5, A.z
    e.max_hp = e.hp = 10 ** 7
    e.stun_until = clock[0] + 99                       # hält still
    return e


def combo_fx():
    return [f['k'] for f in fx('combo')]


# Weitere Klassen (z. B. der Paladin) spielen für die Kombos mit: ihre Zustände und Schadensarten
# kann keiner der ersten drei Helden beisteuern.
extra = []
for i, cid in enumerate(c for c in CLASSES if c not in (A.cls, B.cls, C.cls)):
    sid = 'gast%d' % i
    assert g.join(sid, ('Gunda', 'Odo', 'Ria', 'Wenzel', 'Ilka', 'Bert')[i % 6] + 'x' * (i // 6), cid)['ok']
    extra.append(g.players[sid]); tp(extra[-1], 24, 43)
heroes = (A, B, C, *extra)

for combo in COMBOS:
    for status, tag in combo['pairs']:
        e = dummy(); log.clear()
        giver = next(P for P in heroes if any(s['cls'] == P.cls and s.get('apply') == status for s in SKILLS.values()))
        hitter = next(P for P in heroes if CLASSES[P.cls]['atk']['tag'] == tag
                      or any(s['cls'] == P.cls and s.get('tag') == tag and s.get('mult') for s in SKILLS.values()))
        g.now = clock[0]
        g._apply(e, status, giver)
        e.stun_until = e.stun_free_until = 0
        hp = e.hp
        g._strike(hitter, e, 1.0, {'tag': tag})
        plain = hitter.stats['power'] * (1 + hitter.tag_bonus[tag]) * hitter.stats['critdmg'] * 1.1
        step()
        assert combo_fx() == [combo['id']], (combo['id'], status, tag, combo_fx())
        min_damage = round(round(hitter.stats['power'] * 0.9) * (1 + combo['bonus']))
        assert status not in e.status and hp - e.hp >= min_damage
        if combo.get('stun'):
            assert e.stun_until > clock[0]
        if combo.get('apply'):
            assert combo['apply'] in e.status
        if combo.get('crit'):
            assert fx('dmg')[0].get('c') == 1
        if combo.get('burst'):
            assert hp - e.hp > plain * (1 + combo['bonus'])                # Rest der Blutung kommt obendrauf
        if combo.get('chain'):
            assert fx('bolt')
        # gleich danach zündet auf demselben Gegner keine zweite Kombo
        g._apply(e, status, giver); g._strike(hitter, e, 1.0, {'tag': tag}); step()
        assert len(combo_fx()) == 1 and status in e.status
for X in extra:
    g.leave(X.sid)
print('Kombos: alle %d Paarungen zünden (Zustand von einem Helden, Treffer von einem anderen)' % sum(len(c['pairs']) for c in COMBOS))

# Im echten Ablauf: Borin friert mit der Frostnova ein, Tyra zersplittert mit dem Sturmangriff (Wucht)
e = dummy(); e.stun_until = 0; log.clear()
tp(B, 24.6, 42.3); B.res = 100; assert g.on_skill('b', {'n': 1, 'x': e.x, 'z': e.z})['ok']
step(); assert 'gefroren' in e.status
tp(A, 21, 42); A.res = 100; A.cds.clear(); e.x, e.z = A.x + 6, A.z
assert g.on_skill('a', {'n': 1, 'x': e.x, 'z': e.z})['ok']
step(); assert 'zersplittern' in combo_fx(), combo_fx()
# Borin allein: Frostnova, dann der Feuerball (Grundangriff) = Thermoschock
e = dummy(); e.stun_until = 0; log.clear(); B.cds.clear(); B.res = 100; tp(B, A.x / 2 + 1.2, A.z / 2 + 0.3); e.x, e.z = B.x + 2, B.z
g.on_skill('b', {'n': 1, 'x': e.x, 'z': e.z}); step(); g.on_attack('b', {'x': e.x, 'z': e.z}); step(6)
assert 'thermoschock' in combo_fx(), combo_fx()

# Zustände: Brand zieht jede Sekunde Leben ab, Frost bremst, Marke macht verwundbar
e = dummy(); e.stun_until = 0; g.now = clock[0]; g._apply(e, 'brennend', B); hp = e.hp; log.clear()
wait(STATUS['brennend']['dur'] + 0.5)
ticks = [f for f in fx('dmg') if f.get('s') == 'brennend']
assert len(ticks) == 5 and hp - e.hp >= 5 * round(B.stats['power'] * 0.22) and 'brennend' not in e.status, (len(ticks), hp - e.hp)
quest_n = lambda P, q: P.quests.get(q, {}).get('n', 0)

# Kombo-Quest zählt mit
near(A, 'adelheid'); A.level = max(A.level, 2); g.on_quest('a', {'id': 'kombo', 'do': 'accept'}); assert A.quests['kombo']['s'] == 'active'
tp(A, 24, 42); e = dummy(); g.now = clock[0]; g._apply(e, 'wankend', A); g._strike(A, e, 1.0, {'tag': 'schnitt'})
assert quest_n(A, 'kombo') == 1

# ------------------------------------- jede aktive Fähigkeit einmal wirken (mitten im Goblinlager)
for sid, P in (('a', A), ('b', B), ('c', C)):
    saved = (P.level, dict(P.skills), list(P.bar))
    P.level = 100
    P.skills = {k: 3 for k, s in SKILLS.items() if s['cls'] == P.cls}
    P.recalc()
    for key, sk in SKILLS.items():
        if sk['cls'] != P.cls or sk['type'] != 'active':
            continue
        tp(P, 24, 42); P.hp, P.res, P.dead = P.max_hp, P.stats['res'], False
        P.cds.clear(); P.bar[0] = key
        for o in g.enemies.values():
            if o.kind == 'goblin' and o.dead:
                o.reset()
        t = min(foes('goblin'), key=lambda o: math.hypot(o.x - P.x, o.z - P.z))
        r = g.on_skill(sid, {'n': 1, 'x': t.x, 'z': t.z})
        assert r['ok'], (key, r)
        wait(1.6)
    P.level, P.skills, P.bar = saved
    P.buffs.clear(); P.recalc(); P.hp = P.max_hp
print('Fähigkeiten: alle %d aktiven von Krieger, Magier und Waldläufer gewirkt' % sum(1 for s in SKILLS.values() if s['type'] == 'active' and s['cls'] in (A.cls, B.cls, C.cls)))

# ---------------------------------------- Wegfindung: Ratte folgt durch die Kellertür in die Küche
for o in g.enemies.values():
    if o.dead and not o.temp:
        o.reset()
tp(B, 24, 24); tp(C, 24, 25); tp(A, 12.5, 11.5); A.hp = A.max_hp
wait(3)
assert any(e.target == 'a' for e in g.enemies.values()), 'keine Ratte greift an'
tp(A, 12.5, 15.5); chased = False
for _ in range(160):
    step(); A.hp = A.max_hp
    if any(e.kind == 'rat' and not e.dead and e.z > 14.2 * W.TILE for e in g.enemies.values()):
        chased = True
        break
assert chased, 'Ratte findet den Weg durch die Tür nicht'
tp(A, 24, 24); wait(10)                     # außerhalb der Zone lassen die Gegner ab und erholen sich
assert all(e.hp == e.max_hp and e.target is None for e in foes('rat'))

# ------------------------------------------------ Sammelquest und Händler
near(A, 'marthe', 0.8); g.on_quest('a', {'id': 'vorraete', 'do': 'accept'})
for k in g.pickups:
    if k['kind'] == 'supply' and A.quests['vorraete']['s'] == 'active':
        A.x, A.z = k['x'], k['z']; A.hp = A.max_hp; step(2)
assert A.quests['vorraete']['s'] == 'ready' and sum(1 for k in g.pickups if not k['active']) == 5
near(A, 'marthe', 0.8); price = potion_price(A.level); A.gold = price + 6; A.potions = pots = 2
g.on_shop('a', {'npc': 'marthe', 'item': 'potion'}); assert A.potions == pots + 1 and A.gold == 6
g.on_shop('a', {'npc': 'marthe', 'item': 'weapon'}); assert A.weapon == 0                                         # führt Marthe nicht
g.on_shop('a', {'npc': 'bruna', 'item': 'weapon'}); assert A.weapon == 0                                          # zu weit weg
near(A, 'bruna', 0.7); A.gold = 100; pw, hp = A.stats['power'], A.max_hp
g.on_shop('a', {'npc': 'bruna', 'item': 'weapon'}); assert A.weapon == 1 and A.gold == 100 - gear_price(0) and A.stats['power'] > pw
g.on_shop('a', {'npc': 'bruna', 'item': 'armor'}); assert A.armor == 1 and A.gold == 100 - 2 * gear_price(0) and A.max_hp > hp
g.on_shop('a', {'npc': 'bruna', 'item': 'weapon'}); assert A.weapon == 1                                          # zu wenig Gold
A.hp = 10; g.on_potion('a'); assert A.hp > 10
near(A, 'anselm', 0.7); A.hp = 5; g.on_shop('a', {'npc': 'anselm', 'item': 'heal'}); assert A.hp == A.max_hp
# Neu verteilen bei der Burgherrin
near(A, 'adelheid'); A.gold = respec_price(A.level) - 1; skills = dict(A.skills)
g.on_shop('a', {'npc': 'adelheid', 'item': 'respec'}); assert A.skills == skills
A.gold = respec_price(A.level) + 3; g.on_shop('a', {'npc': 'adelheid', 'item': 'respec'})
assert A.gold == 3 and A.skills == {'wirbel': 1} and A.bar == ['wirbel', None, None, None] and A.ap() == (A.level - 1) * ATTR_POINTS

# ---------------------------- Bewegung: normales Laufen wird akzeptiert, Teleport und Mauern nicht
tp(A, 24, 24); log.clear(); x = A.x
for i in range(24):
    clock[0] += 1 / 15; x += A.speed(clock[0]) / 15; g.on_move('a', {'x': x, 'z': A.z, 'r': 0})
assert not [l for l in log if l[0] == 'correct'], 'ehrliche Bewegung wurde zurückgesetzt'
far = A.x + 30; g.on_move('a', {'x': far, 'z': A.z, 'r': 0}); assert A.x != far and [l for l in log if l[0] == 'correct']
tp(A, 24, 28.6); g.on_move('a', {'x': A.x, 'z': 29.2 * W.TILE, 'r': 0}); assert A.z == 29.2 * W.TILE   # Tor ist offen ...
tp(A, 20, 28.6); g.on_move('a', {'x': A.x, 'z': 29.2 * W.TILE, 'r': 0}); assert A.z == 28.6 * W.TILE   # ... die Mauer nicht
g.on_move('a', {'x': float('nan'), 'z': 'abc', 'r': None}); assert A.x == A.x
A.attrs['ges'] = 105; A.recalc(); assert abs(A.stats['speed'] - PLAYER_SPEED * 1.0525) < 1e-6          # Geschick macht schneller
A.attrs['ges'] = 5; A.recalc()

# ------------- Knochenfürst: von außen unangreifbar, wächst mit der Gruppe, beschwört Diener
boss = foes('boss')[0]
for P in (A, B):
    P.level = 12; P.recalc(); P.hp = P.max_hp
tp(A, 35.5, 20.5); tp(B, 24, 24); g.on_attack('a', {'x': boss.x, 'z': boss.z}); wait(1.5)
assert boss.hp == boss.max_hp == ENEMIES['boss']['hp']
tp(A, 34.5, 23.5); tp(B, 33.5, 26.5); t0 = clock[0]; summoned = False; peak = 0
while not boss.dead and clock[0] - t0 < 300:
    step(); peak = max(peak, boss.max_hp)
    for sid, P in (('a', A), ('b', B)):
        if P.dead:
            continue
        P.hp = max(P.hp, 80); P.res = 100
        g.on_attack(sid, {'x': boss.x, 'z': boss.z}); g.on_skill(sid, {'n': 1, 'x': boss.x, 'z': boss.z})
    summoned = summoned or boss.summoned
assert boss.dead and summoned and peak == round(ENEMIES['boss']['hp'] * 1.7), (boss.dead, summoned, peak)
step(3); assert not any(e.temp for e in g.enemies.values())
assert any('bezwungen' in l[1].get('text', '') for l in log if l[0] == 'chat')
print('Knochenfürst zu zweit in %.0f s besiegt (Leben %d)' % (clock[0] - t0, peak))

# ------------------------------------------------------------ Katakomben
K = 'katakomben'
dg = g.dungeons[K]
BASE = W.MAPS[K]['dungeon']['base_level']
cata = lambda: [e for e in g.enemies.values() if e.zone['dungeon'] and not e.dead]
tp(B, 24, 24); tp(A, 38.5, 8.0); step(2)                       # Treppe hinter dem Altar
assert W.map_at(A.x, A.z) == K and W.floor_at(A.x, A.z) == 'k', (A.x / 2, A.z / 2)
wait(2); assert dg['phase'] == 'idle' and not cata()       # in der Vorhalle ist es ruhig
snap_a = [d for ev, d, to in log if ev == 'state' and to == 'a'][-1]
snap_b = [d for ev, d, to in log if ev == 'state' and to == 'b'][-1]
assert [r[0] for r in snap_a['p']] == [A.id] and snap_a['e'] == [] and snap_a['c'] == [0, 0, 'idle', 1]     # jeder sieht nur seine Karte
assert A.id not in [r[0] for r in snap_b['p']] and len(snap_b['e']) > 20 and snap_b['c'] is None
assert sorted(r[3] for r in snap_a['r']) == ['burg', 'burg', 'katakomben'] and len(snap_b['r']) == 3
near(A, 'kaspian'); g.on_quest('a', {'id': 'ernte', 'do': 'accept'}); assert A.quests['ernte']['s'] == 'active'
A.level = 30; A.attrs['str'] = 90; A.weapon = 8; A.recalc(); A.hp = A.max_hp
tp(A, 15, 14, K); step()
assert dg['phase'] == 'fight' and dg['depth'] == 1 and len(cata()) == 4
assert all(e.level == BASE + 1 and e.temp for e in cata())


def clear_floor(limit=120):
    t0 = clock[0]; depth = dg['depth']
    while dg['depth'] == depth and dg['phase'] != 'idle' and clock[0] - t0 < limit:
        step()
        for sid, P in (('a', A),):
            P.hp = max(P.hp, P.max_hp * 0.5); P.res = 100
            live = cata()
            if live and not P.dead:
                e = min(live, key=lambda e: math.hypot(e.x - P.x, e.z - P.z))
                dist = math.hypot(e.x - P.x, e.z - P.z)
                if dist > 2.2:                                   # hinlaufen, um Säulen herum (Knochenmagier bleiben auf Abstand)
                    hop, base = P.speed(clock[0]) * TICK, math.atan2(e.x - P.x, e.z - P.z)
                    for ang in (0, 0.8, -0.8, 1.5, -1.5):
                        nx, nz = P.x + math.sin(base + ang) * hop, P.z + math.cos(base + ang) * hop
                        if not W.blocked(nx, nz, 0.4):
                            P.x, P.z = nx, nz
                            break
                g.on_attack(sid, {'x': e.x, 'z': e.z}); g.on_skill(sid, {'n': 1, 'x': e.x, 'z': e.z})
    return clock[0] - t0


lvl, gold = A.level, A.gold
clear_floor()
assert dg['depth'] == 2 and A.deepest[K] == 1 and A.gold > gold and quest_n(A, 'ernte') == 4
for d in (2, 3, 4):
    clear_floor(); assert A.deepest[K] == d, (d, A.deepest)
assert dg['depth'] == 5 and [e.kind for e in cata()].count('gruftlord') == 1          # jede fünfte Ebene: Gruftlord
lord = next(e for e in cata() if e.kind == 'gruftlord')
assert lord.boss and lord.level == BASE + 5 + 1
clear_floor(240); assert A.deepest[K] == 5 and dg['depth'] == 6
assert any('Ebene 5' in l[1].get('text', '') for l in log if l[0] == 'chat')
# Rückzug: nach sechs Sekunden ohne Helden legt sich die Halle wieder schlafen und merkt sich die Ebene
tp(A, 15, 5, K); wait(7); assert dg['phase'] == 'idle' and not cata() and dg['start'] == 6
near(A, 'kaspian'); assert g._you(A)['dungeons'][K] == {'deep': 5, 'steps': [1, 6]}
g.on_shop('a', {'npc': 'kaspian', 'item': 'dungeon', 'depth': 11}); assert dg['start'] == 6     # so tief war sie noch nicht
g.on_shop('a', {'npc': 'kaspian', 'item': 'dungeon', 'depth': 1}); assert dg['start'] == 1
g.on_shop('a', {'npc': 'kaspian', 'item': 'dungeon', 'depth': 6}); assert dg['start'] == 6
# Mehr Helden, mehr Gegner – und wer fällt, steht in der Vorhalle wieder auf
B.level = 30; B.attrs['int'] = 90; B.recalc(); B.hp = B.max_hp
tp(A, 15, 14, K); tp(B, 16, 14, K); step()
assert dg['depth'] == 6 and len(cata()) == 7 and dg['reserve'] == 1      # zu zweit: 8 Gegner, 7 davon sofort
g._hurt(B, 10 ** 6); assert B.dead; wait(5.5)
assert not B.dead and W.map_at(B.x, B.z) == K and W.floor_at(B.x, B.z) == 'k' and B.z < 9 * W.TILE       # in der Vorhalle
# Tiefen-Quest zählt die tiefste geschaffte Ebene
A.quests['fuerst'] = {'s': 'done', 'n': 1}; A.deepest[K] = 2
near(A, 'anselm'); g.on_quest('a', {'id': 'abstieg', 'do': 'accept'}); assert A.quests['abstieg'] == {'s': 'active', 'n': 2}
tp(A, 15, 4, K); wait(7)
tp(B, 15, 4, K); tp(A, 15, 2.5, K); step(2); assert W.map_at(A.x, A.z) == 'burg' and W.floor_at(A.x, A.z) == '_'   # Treppe hinauf: Kapelle
print('Katakomben: Ebenen 1 bis 5 samt Gruftlord, Rückzug, Wiedereinstieg auf Ebene 6')

# -------------------------------------------------------------- Stufe 100
g._gain_xp(C, 10 ** 9)
assert C.level == MAX_LEVEL == 100 and C.xp == 0 and C.ap() == 99 * ATTR_POINTS and C.sp() == 99
assert sum(xp_needed(l) for l in range(1, 100)) < 10 ** 7


# ----------------------------------------- Elite-Gegner, Boss-Kampfmuster, Elixiere und Beute
from game.data import BAG_MAX, ELITE_AFFIXES, ELIXIR_TIME, RARITIES, elixir_price
from game.registry import BOSS_MOVES
g.elite_chance = 0.0
gob = foes('goblin')[0]; gob.reset(); g._roll_elite(gob, 'zaeh')
assert gob.elite == 'zaeh' and gob.hp == gob.max_hp == round(gob.base_hp * ELITE_AFFIXES['zaeh']['hp'])
row = next(r for r in g._snapshot('burg', [A])['e'] if r[0] == gob.id)
assert row[10] == 'zaeh'
fast = foes('goblin')[1]; fast.reset(); g._roll_elite(fast, 'flink'); assert fast.speed_f > 1 > fast.cd_f
g.elite_chance = 1.0; boss_ = foes('boss')[0] if foes('boss') else None
rat = foes('rat')[0]; rat.reset(); g._roll_elite(rat); assert rat.elite in ELITE_AFFIXES          # Zufall wählt eine Eigenart
g._roll_elite(next(e for e in g.enemies.values() if e.boss)); assert not any(e.elite for e in g.enemies.values() if e.boss)
g.elite_chance = 0.0
A.bag.clear(); gold0 = A.gold; tp(A, 24, 42); gob.x, gob.z = A.x + 1, A.z
g._kill(gob, A)
assert 3 * ENEMIES['goblin']['gold'][0] <= A.gold - gold0 <= 3 * ENEMIES['goblin']['gold'][1]            # dreifaches Gold

# Jeder Sonderangriff trifft einen Helden, der dort steht, wo der Boss hinzielt
chief = foes('ork_haeuptling')[0]
assert set(ENEMIES['ork_haeuptling']['moves']) <= BOSS_MOVES and ENEMIES['skeleton'].get('moves') is None
for move in sorted(BOSS_MOVES):
    chief.reset(); chief.stun_until = clock[0] + 99
    A.x, A.z = chief.x + 4.0, chief.z; A.budget = 4; A.buffs.clear(); A.shield = 0; A.dead = False; A.hp = A.max_hp
    g.now = clock[0]; log.clear()
    getattr(g, '_move_' + move)(chief, A)
    wait(2.2)
    assert A.hp < A.max_hp or A.dead, move
A.dead = False; A.hp = A.max_hp
# Raserei unter einem Viertel Leben
chief.reset(); chief.target = 'a'; chief.state = 'chase'; chief.hp = chief.max_hp * 0.2; chief.summoned = True
A.x, A.z = chief.x + 4.0, chief.z; g.now = clock[0]; log.clear()
g._boss_ai(chief, A); step()
assert chief.enraged and chief.speed_f > 1 and fx('enrage')
g._boss_reset(chief); assert not chief.enraged and chief.speed_f == 1.0
chief.reset()
print('Bosse: alle %d Sonderangriffe treffen, Raserei unter 25 %% Leben; Elite-Gegner mit dreifachem Gold' % len(BOSS_MOVES))

# Elixiere: kosten Gold, wirken zehn Minuten, stapeln die Dauer
A.gold = 10 ** 6; near(A, 'marthe'); g.now = clock[0]
g.on_shop('a', {'npc': 'marthe', 'item': 'elixir', 'kind': 'weisheit'})
assert A.gold == 10 ** 6 - elixir_price(A.level) and abs(A.elixirs['weisheit'] - clock[0] - ELIXIR_TIME) < 1
A.xp = 0; g._gain_xp(A, 100); assert A.xp == 125                                                    # 25 % mehr Erfahrung
g.on_shop('a', {'npc': 'marthe', 'item': 'elixir', 'kind': 'kraft'})
assert abs(A.buffv('dmg', clock[0]) - 0.15) < 1e-9 and A.combat_buff('dmg', clock[0]) == 0
g.on_shop('a', {'npc': 'marthe', 'item': 'elixir', 'kind': 'kraft'})
assert abs(A.elixirs['kraft'] - clock[0] - 2 * ELIXIR_TIME) < 1
g.on_shop('a', {'npc': 'gerold', 'item': 'elixir', 'kind': 'kraft'})                                 # Gerold verkauft keine
assert abs(A.elixirs['kraft'] - clock[0] - 2 * ELIXIR_TIME) < 1

# Beute: anlegen ändert die Werte, verkaufen bringt Gold, eine volle Tasche verkauft selbst
A.bag.clear(); A.items = {'ring': None, 'amulett': None}; A.recalc()
pw = A.stats['power']
ring = {'slot': 'ring', 'name': 'Ring der Stärke', 'lvl': 40, 'rar': 0, 'mods': {'power': 0.06}}
g._give_item(A, ring); assert A.bag == [ring]
g.on_item('a', {'act': 'equip', 'i': 0}); assert A.items['ring'] is ring and not A.bag and abs(A.stats['power'] - pw * 1.06) < 1e-6
g.on_item('a', {'act': 'unequip', 'slot': 'ring'}); assert A.bag == [ring] and abs(A.stats['power'] - pw) < 1e-6
gold0 = A.gold; g.on_item('a', {'act': 'sell', 'i': 0}); assert not A.bag and A.gold == gold0 + 40 * RARITIES[0][5]
for _ in range(BAG_MAX):
    g._give_item(A, g._make_item(20))
gold0 = A.gold; g._give_item(A, g._make_item(20)); assert len(A.bag) == BAG_MAX and A.gold > gold0
for _ in range(200):
    it = g._make_item(30, floor=2)
    assert it['rar'] >= 2 and len(it['mods']) == RARITIES[it['rar']][2] and it['slot'] in ('ring', 'amulett')
A.bag = A.bag[:3]; n = len(A.bag)
tp(A, 33.5, 25.5); bossfoe = next(e for e in g.enemies.values() if e.kind == 'boss')
bossfoe.reset(); bossfoe.x, bossfoe.z = A.x + 1, A.z; lvl0 = A.level; A.level = 12
g._kill(bossfoe, A); A.level = lvl0; assert len(A.bag) == n + 1 and A.bag[-1]['rar'] >= 1                           # Bosse lassen immer etwas fallen
g.on_item('a', {'act': 'equip', 'i': 0})
print('Elixiere und Beute: kaufen, wirken, anlegen, verkaufen, Bosse lassen immer etwas fallen')

# ------------------------------------------------- Chat und Speicherstand
log.clear(); g.on_chat('a', {'text': '  Hallo   <b>Welt</b> ' + 'x' * 400}); msg = [l for l in log if l[0] == 'chat'][0][1]
assert msg['text'].startswith('Hallo <b>Welt</b>') and len(msg['text']) == 200          # wird im Browser als reiner Text gezeigt
g.on_learn('a', {'id': 'schildstoss'}); g.on_attr('a', {'k': 'vit', 'n': 7})
state = (A.level, A.gold, A.weapon, A.armor, A.deepest, dict(A.attrs), dict(A.skills), list(A.bar), dict(A.items), list(A.bag))
for sid in 'abc':
    g.leave(sid)
g2 = Game(lambda *a, **k: None, tmp)
r = g2.join('z', 'TYRA', 'magier'); Z = g2.players['z']
assert r['ok'] and r['returning'] and Z.cls == 'krieger'
assert (Z.level, Z.gold, Z.weapon, Z.armor, Z.deepest, Z.attrs, Z.skills, Z.bar, Z.items, Z.bag) == state
assert set(Z.elixirs) == {'weisheit', 'kraft'}                                     # Elixiere wirken nach dem Abmelden weiter
assert Z.quests['ratten']['s'] == 'done'
# Ein Speicherstand aus der ersten Fassung (ohne Attribute und Skilltree) bekommt seine Punkte gutgeschrieben
old = os.path.join(os.path.dirname(tmp), 'alt.json')
with open(old, 'w', encoding='utf-8') as f:
    json.dump({'alrik': {'name': 'Alrik', 'cls': 'magier', 'level': 9, 'xp': 5, 'gold': 77, 'potions': 3, 'weapon': 2,
                         'quests': {'ratten': {'s': 'done', 'n': 6}}}}, f)
g3 = Game(lambda *a, **k: None, old)
assert g3.join('y', 'Alrik', 'krieger')['ok']
Y = g3.players['y']
assert Y.cls == 'magier' and Y.level == 9 and Y.skills == {'nova': 1} and Y.ap() == 24 and Y.sp() == 8 and Y.weapon == 2
print('Speicherstände: neuer und alter Stand geladen')

# ============================================ Framework: neue Inhalte ohne Code
# 1) Fehlerhafte Inhalte: alle Fehler werden gesammelt und mit Datei und Ursache gemeldet
bad = tempfile.mkdtemp()
with open(os.path.join(bad, 'kaputt.py'), 'w', encoding='utf-8') as f:
    f.write("""from game.registry import active, enemy, game_map, quest
active('feuerkuss', 'drache', 0, 1, 'Feuerkuss', 'strahl', 'feuer', 10, 5, 'Klasse und Form gibt es nicht.')
active('eisfaust', 'magier', 1, 2, 'Eisfaust', 'nova', 'eis', 10, 5, 'Falsche Schadensart, falsche Angabe.', r=3.0, mult=1.0, radius=2)
enemy('troll', 'Troll', look={'cloth': 'gruen', 'hat': 'zylinder'}, hp=100, dmg=5, speed=3, radius=0.8, aggro=8, range=2,
      cd=1.5, xp=40, gold=(9, 3))
quest('trolljagd', title='Trolljagd', npc='niemand', type='kill', target='troll', count=3, goal='Trolle', where='Moor',
      text='...', done='...')
game_map('insel', name='Insel', start=(1, 1), portals={'1': {'to': 'atlantis'}}, plan='''
    ~~~~~~~~
    ~,,,,,,~
    ~,,T,,~
    ~~~~~~~~
    ~~~~~~~~
    ~~~~~~~~
''')
""")
with open(os.path.join(bad, 'absturz.py'), 'w', encoding='utf-8') as f:
    f.write('x = 1\ny = x / 0\n')
try:
    game.load(extra=[bad])
    raise AssertionError('fehlerhafte Inhalte wurden nicht bemerkt')
except R.ContentError as err:
    report = str(err)
for part in ("Fähigkeit 'feuerkuss': Klasse 'drache' gibt es nicht", "Fähigkeit 'feuerkuss': form 'strahl' gibt es nicht",
             "Fähigkeit 'eisfaust' (form 'nova'): unbekannte Angabe radius", "Fähigkeit 'eisfaust': Schadensart 'eis' gibt es nicht",
             "Gegner 'troll': hat 'zylinder' gibt es nicht", "Gegner 'troll': 'cloth' im Aussehen ist keine Farbe",
             "Gegner 'troll': braucht lvl", "Gegner 'troll': gold ist (min, max)",
             "Quest 'trolljagd': Bewohner 'niemand' gibt es nicht", "Quest 'trolljagd': Gegnerart 'troll' taucht auf keiner Karte auf",
             "Quest 'trolljagd': braucht eine Belohnung", "Karte 'insel', Übergang '1': Zielkarte 'atlantis' gibt es nicht",
             "Karte 'insel': Zeile 3 des Plans ist 7 Zeichen lang", 'absturz.py, Zeile 2: ZeroDivisionError'):
    assert part in report, (part, report)
errors = int(report.split()[0])
with open(os.path.join(bad, 'kaputt.py'), 'w', encoding='utf-8') as f:            # Geometrie: abgeschnitten, kein Rückweg
    f.write("""from game.registry import game_map, portal
game_map('insel', name='Insel', start=(1, 1), zones={'strand': (5, 1, 6, 4)}, plan='''
    ~~~~~~~~
    ~,,,~,,~
    ~,,,~,,~
    ~,,,~,,~
    ~,,,~,,~
    ~~~~~~~~
''', npcs={'robinson': {'name': 'Robinson', 'role': 'Gestrandeter', 'look': {'cloth': '#886644'}, 'at': (6, 2), 'greet': 'Ahoi.'}})
portal('burg', at=(8, 4), to='insel')
portal('burg', at=(24, 20), to='insel')
""")
os.remove(os.path.join(bad, 'absturz.py'))
try:
    game.load(extra=[bad])
    raise AssertionError('unerreichbare Orte wurden nicht bemerkt')
except R.ContentError as err:
    report = str(err)
for part in ("Übergang auf Karte 'burg' bei (8, 4): die Kachel ist nicht begehbar",
             "Zone 'strand': im Rechteck (5, 1, 6, 4) liegt keine erreichbare Kachel",
             "Bewohner 'robinson': der Platz (6, 2) ist nicht erreichbar",
             "Karte 'insel': von hier führt kein Übergang zurück zur Hauptkarte"):
    assert part in report, (part, report)
print('Framework: fehlerhafte Inhalte werden gesammelt gemeldet (%d Fehler auf einmal, dazu Geometrie)' % errors)

# 2) Gerüste aus tools/neu.py: neue Klassen, Gegnerarten, Karte, Verlies und Quests – nur Inhaltsdateien
neu = tempfile.mkdtemp()


def tool(script, *args):
    run = subprocess.run([sys.executable, os.path.join(ROOT, 'tools', script), *args], capture_output=True, text=True, encoding='utf-8')
    assert run.returncode == 0, run.stdout + run.stderr
    return run.stdout


for args in (('klasse', 'probe_paladin', '--name', 'Paladin', '--stil', 'klinge'),
             ('klasse', 'probe_hexer', '--name', 'Hexer', '--stil', 'magie'),
             ('klasse', 'probe_jaeger', '--name', 'Jäger', '--stil', 'bogen'),
             ('gegner', 'probe_wolf', '--name', 'Moorwolf', '--stufe', '3', '--tier'),
             ('gegner', 'probe_licht', '--name', 'Irrlicht', '--verlies', '--fern'),
             ('karte', 'probe_moor', '--name', 'Das Moor', '--groesse', '34x26', '--gegner', 'probe_wolf'),
             ('karte', 'probe_mine', '--name', 'Alte Mine', '--licht', 'dunkel', '--verlies', '--stufe', '2'),
             ('quest', 'probe_jagd', '--npc', 'probe_moor_hueter', '--ziel', 'probe_wolf', '--anzahl', '3'),
             ('quest', 'probe_tiefe', '--npc', 'probe_mine_hueter', '--art', 'depth', '--anzahl', '2', '--datei', 'quests/probe_jagd.py')):
    tool('neu.py', *args, '--ordner', neu)
assert 'Probelauf in Ordnung' in tool('pruefen.py', '--spiel', '--extra', neu)
game.load(extra=[neu])
assert {'probe_mine', 'probe_moor'} < set(W.MAPS) and 'probe_licht' in [k for k, _, _ in W.MAPS['probe_mine']['dungeon']['mix']]
assert R.NOTES and all('TODO' in n for n in R.NOTES), R.NOTES                      # Platzhalter der Gerüste, sonst nichts
data = json.loads(json.dumps(R.client_data()))                                     # so bekommt es der Browser
assert {'probe_hexer', 'probe_jaeger', 'probe_paladin'} < set(data['classes']) and data['maps']['probe_mine']['dungeon']

log.clear()
g = Game(lambda ev, data, to=None: log.append((ev, data, to)), os.path.join(tempfile.mkdtemp(), 'saves', 'n.json'), dev=True)
r = g.join('p', 'Pia', 'probe_paladin'); P = g.players['p']
assert r['ok'] and r['you']['bar'][0] == 'probe_paladin_angriff' and [m['id'] for m in r['world']['maps']] == list(W.MAPS)
assert g.join('h', 'Hugo', 'probe_hexer')['ok'] and g.join('j', 'Jo', 'probe_jaeger')['ok']
# Durch den neuen Übergang im Burghof ins Moor
gate = next(t for t, d in W.PORTAL_AT.items() if d['to'] == 'probe_moor')
P.x, P.z = (gate[0] + 0.5) * W.TILE, (gate[1] + 0.5) * W.TILE; P.budget = 4; step(2)
assert W.map_at(P.x, P.z) == 'probe_moor' and (P.x, P.z) == W.MAPS['probe_moor']['start']
snap = [d for ev, d, to in log if ev == 'state' and to == 'p'][-1]
assert {e[1] for e in snap['e']} == {'probe_wolf'} and len(snap['p']) == 1 and len(snap['r']) == 3      # nur das Moor, aber alle in der Liste
# Quest des neuen Bewohners: annehmen, Moorwölfe mit Grundangriff und Startfähigkeit erlegen, abgeben
near(P, 'probe_moor_hueter'); g.on_quest('p', {'id': 'probe_jagd', 'do': 'accept'}); assert P.quests['probe_jagd'] == {'s': 'active', 'n': 0}
tp(P, 16.5, 14, 'probe_moor'); t0 = clock[0]
while P.quests['probe_jagd']['s'] != 'ready' and clock[0] - t0 < 120:
    step()
    P.hp = max(P.hp, P.max_hp * 0.5)
    wolves = foes('probe_wolf')
    if wolves:
        e = min(wolves, key=lambda e: math.hypot(e.x - P.x, e.z - P.z))
        if math.hypot(e.x - P.x, e.z - P.z) > 2.2 and not W.blocked(e.x + 1.2, e.z, 0.4):
            P.x, P.z, P.budget = e.x + 1.2, e.z, 4
        g.on_attack('p', {'x': e.x, 'z': e.z}); g.on_skill('p', {'n': 1, 'x': e.x, 'z': e.z})
assert P.quests['probe_jagd']['s'] == 'ready' and any(f.get('sk') for f in fx('slash', 'p')), P.quests
near(P, 'probe_moor_hueter'); before = (P.level, P.xp)
g.on_quest('p', {'id': 'probe_jagd', 'do': 'turnin'}); assert P.quests['probe_jagd']['s'] == 'done' and (P.level, P.xp) > before
# Zurück in die Burg, weiter in das neue Verlies: zwei Ebenen, dann die Tiefen-Quest
back = next(t for t, d in W.PORTAL_AT.items() if d['to'] == 'burg' and W.map_at(t[0] * W.TILE, t[1] * W.TILE) == 'probe_moor')
wait(1.6); P.x, P.z = (back[0] + 0.5) * W.TILE, (back[1] + 0.5) * W.TILE; P.budget = 4; step(2)
assert W.map_at(P.x, P.z) == 'burg' and not W.blocked(P.x, P.z, 0.4)
gate = next(t for t, d in W.PORTAL_AT.items() if d['to'] == 'probe_mine')
wait(1.6); P.x, P.z = (gate[0] + 0.5) * W.TILE, (gate[1] + 0.5) * W.TILE; P.budget = 4; step(2)
mine, hall = g.dungeons['probe_mine'], W.MAPS['probe_mine']['zones']['halle']
assert W.map_at(P.x, P.z) == 'probe_mine' and mine['phase'] == 'idle'
P.level = 20; P.recalc(); tp(P, 15.5, 14, 'probe_mine'); step(2)
assert mine['phase'] == 'fight' and mine['depth'] == 1 and all(e.level == 2 + 1 for e in g._dungeon_enemies(hall))
t0 = clock[0]
while P.deepest.get('probe_mine', 0) < 2 and clock[0] - t0 < 240:
    step()
    P.hp, P.res = P.max_hp, P.stats['res']
    live = g._dungeon_enemies(hall)
    if live:
        e = min(live, key=lambda e: math.hypot(e.x - P.x, e.z - P.z))
        if math.hypot(e.x - P.x, e.z - P.z) > 2.2 and not W.blocked(e.x + 1.2, e.z, 0.4):
            P.x, P.z, P.budget = e.x + 1.2, e.z, 4
        g.on_attack('p', {'x': e.x, 'z': e.z}); g.on_skill('p', {'n': 1, 'x': e.x, 'z': e.z})
assert P.deepest == {'probe_mine': 2}, (P.deepest, mine)
tp(P, 15, 3.5, 'probe_mine'); wait(7); assert mine['phase'] == 'idle' and mine['start'] == 3
near(P, 'probe_mine_hueter'); g.on_quest('p', {'id': 'probe_tiefe', 'do': 'accept'}); assert P.quests['probe_tiefe'] == {'s': 'ready', 'n': 2}
g.on_quest('p', {'id': 'probe_tiefe', 'do': 'turnin'}); assert P.quests['probe_tiefe']['s'] == 'done'
g.on_shop('p', {'npc': 'probe_mine_hueter', 'item': 'dungeon', 'depth': 1}); assert mine['start'] == 1
# Die anderen neuen Klassen: Fernkampf-Grundangriff und Startfähigkeit fliegen als Geschosse
for sid in 'hj':
    H = g.players[sid]; tp(H, 30, 40); step()
    goblin = min(foes('goblin'), key=lambda e: math.hypot(e.x - H.x, e.z - H.z)); hp = goblin.hp
    g.on_attack(sid, {'x': goblin.x, 'z': goblin.z}); assert g.on_skill(sid, {'n': 1, 'x': goblin.x, 'z': goblin.z})['ok']
    assert len([pr for pr in g.projs if pr['owner'] == sid]) == 2; wait(1.5); assert goblin.hp < hp or goblin.dead
for sid in 'phj':
    g.leave(sid)
print('Framework: Paladin, Hexer und Jäger, Moor mit Quest und Alte Mine mit Verlies – nur aus Inhaltsdateien')
print('ALLE PRÜFUNGEN BESTANDEN')
