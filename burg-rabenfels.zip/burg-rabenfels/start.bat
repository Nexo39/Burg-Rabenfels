@echo off
rem Burg Rabenfels starten (Windows). Legt beim ersten Mal eine eigene Python-Umgebung an.
cd /d "%~dp0"
if not exist ".venv\Scripts\python.exe" (
    echo Richte die Python-Umgebung ein ...
    py -3 -m venv .venv 2>nul || python -m venv .venv
    if errorlevel 1 (
        echo.
        echo Python wurde nicht gefunden. Bitte Python 3.9 oder neuer von https://www.python.org installieren
        echo und beim Einrichten "Add python.exe to PATH" ankreuzen.
        pause
        exit /b 1
    )
    ".venv\Scripts\python.exe" -m pip install --quiet --upgrade pip
    ".venv\Scripts\python.exe" -m pip install --quiet -r requirements.txt
    if errorlevel 1 (
        echo Die Pakete konnten nicht installiert werden. Besteht eine Internetverbindung?
        pause
        exit /b 1
    )
)
".venv\Scripts\python.exe" app.py
pause
