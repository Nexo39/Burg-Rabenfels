"""Bewohner der Zwergenmine Grauhall (Stufe 21–30) und ihr Eisernes Herz."""
from game.registry import enemy

enemy('kobold', 'Kobold', lvl=21, hp=1032, dmg=43, speed=5.2, radius=0.45, aggro=9.0, range=1.4, cd=1.1,
      xp=587, gold=(21, 43), respawn=15,
      look={'skin': '#b36a3a', 'arms': '#b36a3a', 'ears': '#b36a3a', 'cloth': '#5a4030', 'legs': '#3a2c22',
            'weapon': 'club', 'eyeGlow': '#ffe14a', 'scale': 0.8},
      dust='#b38a5a')
enemy('kobold_werfer', 'Koboldsprengmeister', lvl=23, hp=972, dmg=47, speed=4.4, radius=0.45, aggro=12.0, range=11.0,
      cd=2.4, xp=695, gold=(23, 47), respawn=16, shot=10.0,
      look={'skin': '#c27a44', 'arms': '#c27a44', 'ears': '#c27a44', 'cloth': '#6a3a2a', 'legs': '#3a2c22',
            'hat': 'hood', 'hatColor': '#4a2a1a', 'weapon': 'staff', 'orb': '#ff8a3a', 'eyeGlow': '#ff8a3a',
            'scale': 0.85},
      dust='#ff8a3a')
enemy('grubenkriecher', 'Grubenkriecher', lvl=24, hp=1312, dmg=49, speed=5.6, radius=0.6, aggro=8.0, range=1.5,
      cd=1.1, xp=752, gold=(24, 49), respawn=15,
      look={'body': 'beast', 'fur': '#3a3530', 'dark': '#25211d', 'ear': '#5a4a40', 'tail': '#3a3530',
            'eyeGlow': '#ff3a3a', 'scale': 1.15},
      dust='#5a524a')
enemy('zwergengeist', 'Ahnengeist', lvl=26, hp=1518, dmg=53, speed=4.4, radius=0.5, aggro=10.0, range=1.6, cd=1.3,
      xp=874, gold=(26, 53), respawn=16,
      look={'skin': '#cfe0ff', 'cloth': '#9fb4d8', 'legs': '#8fa4c8', 'arms': '#b7c8e6', 'hat': 'helmet',
            'hatColor': '#8fa4c8', 'hair': '#e0e8ff', 'weapon': 'hammer', 'eyeGlow': '#ffffff', 'opacity': 0.5,
            'scale': 0.95})
enemy('steingolem', 'Steingolem', lvl=28, hp=2262, dmg=57, speed=3.2, radius=0.85, aggro=8.0, range=2.2, cd=1.9,
      xp=1006, gold=(28, 57), respawn=18,
      look={'skin': '#6e6a64', 'arms': '#6e6a64', 'cloth': '#5a5650', 'legs': '#4a4640', 'pads': '#7a7670',
            'eyeGlow': '#ff8a3a', 'scale': 1.75},
      dust='#7a7670')
# Das Eiserne Herz ruft bei halbem Leben Kobolde zu Hilfe.
enemy('glutherz', 'Glutherz, der Eiserne Wächter', lvl=30, hp=29600, dmg=92, speed=3.4, radius=1.2, aggro=12.0,
      range=2.6, cd=1.8, xp=5730, gold=(220, 320), respawn=90, boss=True, summon='kobold', moves=['slam', 'cone', 'nova'],
      look={'skin': '#3a3634', 'arms': '#4a4440', 'cloth': '#4a3a30', 'legs': '#2a2624', 'pads': '#c86a2a',
            'hat': 'helmet', 'hatColor': '#2a2624', 'plume': '#ff8a3a', 'weapon': 'hammer', 'eyeGlow': '#ff8a3a',
            'scale': 2.2},
      dust='#ff8a3a')
