"""Licht: die Schadensart des Paladins, der Zustand „Geblendet“ und drei Kombos,
die Licht mit den anderen Klassen verbinden."""
from game.registry import combo, status, tag

tag('licht', 'Licht', '#ffe9a8')

status('geblendet', 'Geblendet', '#fff2b8', dur=4.0, weak=0.25, desc='Teilt 25 % weniger Schaden aus.')

# Geblendet + Wucht: der Paladin allein (Lichtschlag, dann Hammer). Wankend + Licht: mit dem Krieger.
combo('richtspruch', 'Richtspruch', [('geblendet', 'wucht'), ('wankend', 'licht')], bonus=0.6,
      aoe={'r': 3.5, 'mult': 0.5, 'tag': 'licht'},
      desc='60 % mehr Schaden. Ein Lichtschlag trifft alle Gegner im Umkreis.')
# Mit dem Magier: Feuer auf Geblendete oder Licht auf Brennende.
combo('laeuterung', 'Läuterung', [('geblendet', 'feuer'), ('brennend', 'licht')], bonus=0.7, stun=1.0,
      desc='70 % mehr Schaden und eine Sekunde Betäubung.')
# Mit dem Waldläufer: Licht brennt das Gift auf einen Schlag aus.
combo('reinigung', 'Reinigung', [('vergiftet', 'licht')], bonus=0.5, burst=2.0,
      desc='50 % mehr Schaden, dazu der restliche Giftschaden sofort und doppelt.')
