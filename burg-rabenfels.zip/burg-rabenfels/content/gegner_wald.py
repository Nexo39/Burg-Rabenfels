"""Die Orks im dunklen Wald südlich der Burg."""
from game.registry import enemy

enemy('ork_krieger', 'Orkkrieger', lvl=6, hp=142, dmg=13, speed=4.4, radius=0.5, aggro=8.0, range=1.6, cd=1.3,
      xp=68, gold=(6, 13), respawn=15,
      look={'skin': '#65824b', 'arms': '#65824b', 'ears': '#65824b', 'cloth': '#594332', 'legs': '#40372d',
            'weapon': 'sword', 'shield': '#5c5040', 'scale': 1.1})

enemy('ork_jaeger', 'Orkjäger', lvl=7, hp=123, dmg=15, speed=4.8, radius=0.5, aggro=12.0, range=11.0, cd=2.4,
      xp=87, gold=(7, 15), respawn=15, shot=10.0,
      look={'skin': '#72834a', 'arms': '#72834a', 'ears': '#72834a', 'cloth': '#465139', 'legs': '#373e2d',
            'hat': 'hood', 'hatColor': '#343f2b', 'bow': True, 'scale': 1.0})

enemy('ork_schamane', 'Orkschamane', lvl=8, hp=148, dmg=17, speed=3.8, radius=0.5, aggro=12.0, range=11.0, cd=2.4,
      xp=108, gold=(8, 17), respawn=15, shot=10.0,
      look={'skin': '#70895c', 'arms': '#70895c', 'ears': '#70895c', 'cloth': '#473b35', 'robe': '#382d2a',
            'hat': 'hood', 'hatColor': '#382d2a', 'weapon': 'staff', 'orb': '#a5dc68',
            'eyeGlow': '#a5dc68', 'scale': 1.05})

enemy('ork_berserker', 'Orkberserker', lvl=9, hp=252, dmg=19, speed=5.0, radius=0.65, aggro=9.0, range=1.8, cd=1.3,
      xp=131, gold=(9, 19), respawn=15,
      look={'skin': '#4f7042', 'arms': '#4f7042', 'ears': '#4f7042', 'cloth': '#713c30', 'legs': '#3e3029',
            'pads': '#70503b', 'weapon': 'greatsword', 'scale': 1.35})

# Der Häuptling sitzt auf der Lichtung im Süden und ruft bei halbem Leben seine Krieger.
enemy('ork_haeuptling', 'Häuptling Grukmar', lvl=10, hp=4400, dmg=31, speed=3.8, radius=1.1, aggro=12.0, range=2.4,
      cd=1.6, xp=780, gold=(80, 120), respawn=90, boss=True, summon='ork_krieger', moves=['charge', 'slam'],
      look={'skin': '#55753f', 'arms': '#55753f', 'ears': '#55753f', 'cloth': '#5e2f24', 'legs': '#3a2c22',
            'pads': '#8a6a40', 'hat': 'crown', 'hatColor': '#8a6a40', 'cape': '#4a2018', 'weapon': 'greatsword',
            'bladeColor': '#9a8a7a', 'eyeGlow': '#ff6a3a', 'scale': 2.0},
      dust='#7fae45')
