"""Ein verlassener Steinbruch westlich der Burg, besetzt von Gnolls."""
from game.registry import game_map, portal

game_map(
    'steinbruchtal', name='Steinbruchtal', light='tag', floor=':', start=(45.5, 19.5),
    ambient='wind',
    plan="""
    MMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMM
    M::::::::R::S::::::::::::::::::S::::::::M::::::::M
    M:R::::::::::::::::::::::::S::::::::::::M::::::::M
    MR::::::::::::::::::::::::::::::::::::::M::::::::M
    M::::::::S:R:R::::::::::::::::::::::::::M::::::::M
    M::::R:::::::::::::::::::::::::::::^::::M::::::::M
    M::::^:::^::::::::::::::::::::::::::::::M::::::::M
    M::::::::::::::::::::::::::R:::::::::::RM::::::::M
    M::::R::::::S::::::::RR::::::::::::::X::M::::::::M
    M:::::B:::R::A::::::::::::::::::::::::::M::::::::M
    M:::::::::::::::::::::::::::::::::::::::M::::::::M
    M:::::::::::::::::::::::::::::::::::::::M::::::::M
    M::::::::::::::R:MMMMMMM::MMMMMM::::::::M::::::::M
    M::::::::::::SR::M:::::::::::::M::::::::M::::::::M
    M::R:::::::R:::::M:::::::::::::M::::::::M::::::::M
    M::::::::::::::::M:::S::::::S::M::::::::M::::::::M
    M::::::::::R:::::M:::::::::::::M::::::::M::::::::M
    M::::::::::::::::M:::::::::::::M::::::::M::::::::M
    M:::::RS:::::::::M:::::::::::::M::::::::M::::::::M
    M:::::::::::::::::::::::::::::::::::::::::::::::1M
    M:::::::::::::::::::::::::::::::::::::::::::::::1M
    MR:::::::::R:::::M:::::::::::::M:::::S::M::::::::M
    M::::::::::::::::M:::::::::::::M:::::R::M::::::::M
    M::::::::::::::::M:::::::::::::M::::::::M::::::::M
    M::::::::::::::::M:::::::::::::M::::::::M::::::::M
    M::::::::::::::::M:::S::::::S::MS:::::::M::::::::M
    M:S::::::::::::::M:::::::::::::M::::::::M::::::::M
    M::::::::::::::::M:::::::::::::MR:::::::M::::::::M
    M::::::::S:::::::MMMMMMM::MMMMMM::::::::M::::::::M
    M:::::::::::::::::R:::::::R:::::::::::::M::::::::M
    M:::::::::::::::::::::::::::::::::::B:::M::::::::M
    M::::::^::S:A::::::::::::::::::::::R::::M::::::::M
    M::::::::::::::R::::::::::::R:::::::::::M::::::::M
    M::::::::::X:::::::::::::::::::::::^::::M::::::::M
    M:::::::::::::::::::::::::::::::::::::::M::::::::M
    M:::::::::::::::::::::::::::::::::::::::M::::::::M
    M:::::::::::::::::::::::::::::RR::::::::M::::::::M
    M::::::::::::::::::::::::::::::R:::::::RM::::::::M
    M::::::S::::::::::::::::::::::::::::::::M::::::::M
    MMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMM
    """,
    regions=[
        ('Östlicher Zugang', (41, 1, 48, 38)),
        ('Grube des Feldherrn', (17, 12, 31, 28)),
        ('Nördlicher Steinbruch', (1, 1, 39, 11)),
        ('Südlicher Steinbruch', (1, 29, 39, 38)),
        ('Steinbruchtal', (0, 0, 49, 39)),
    ],
    zones={
        'nordwest': {'rect': (2, 3, 15, 11), 'margin': 2},
        'nordost': {'rect': (18, 3, 38, 10), 'margin': 2},
        'west': {'rect': (2, 14, 15, 26), 'margin': 2},
        'ost': {'rect': (33, 13, 38, 26), 'margin': 2},
        'suedwest': {'rect': (2, 29, 16, 36), 'margin': 2},
        'suedost': {'rect': (18, 30, 38, 37), 'margin': 2},
        'feldherr': {'rect': (18, 13, 30, 27), 'margin': 0},
    },
    spawns=[
        ('gnoll_spaeher', 'nordwest', 3),
        ('gnoll_krieger', 'nordwest', 2),
        ('gnoll_jaeger', 'nordost', 3),
        ('gnoll_krieger', 'nordost', 2),
        ('gnoll_schlaeger', 'west', 3),
        ('gnoll_spaeher', 'west', 2),
        ('gnoll_wache', 'ost', 2),
        ('gnoll_jaeger', 'ost', 2),
        ('gnoll_schamane', 'suedwest', 3),
        ('gnoll_schlaeger', 'suedwest', 2),
        ('gnoll_wache', 'suedost', 3),
        ('gnoll_schamane', 'suedost', 2),
        ('gnoll_feldherr', 'feldherr', 1, (24.5, 19.5)),
    ],
    pickups=[
        ('meissel', 5, 2), ('meissel', 30, 5), ('meissel', 8, 15), ('meissel', 35, 20), ('meissel', 4, 33),
        ('meissel', 25, 35), ('meissel', 14, 9), ('meissel', 37, 30), ('meissel', 12, 25), ('meissel', 20, 32),
    ],
    npcs={
        'steinbruchtal_hueter': {
            'name': 'Steinmetzin Hedda', 'role': 'Wächterin des Zugangs', 'at': (44.5, 17.5),
            'look': {'cloth': '#73644f', 'legs': '#51483b', 'apron': '#81725b',
                     'weapon': 'hammer', 'scale': 1.0},
            'greet': 'Die Gnolls haben den Steinbruch besetzt. Ihr Feldherr wartet in der Grube. '
                     'Das hier ist kein Ort für Anfänger – wer nicht schon die Mine von Grauhall gesehen hat, '
                     'kehrt besser um.',
            'services': ['potion', 'heal'],
        },
    },
    portals={'1': {'to': 'burg', 'target': (2.5, 34.5)}},
    deco=[
        ('torch', 42.5, 18.5), ('torch', 42.5, 21.5),
        ('fire', 7.5, 8.5), ('fire', 34.5, 7.5),
        ('fire', 9.5, 32.5), ('fire', 34.5, 32.5),
        ('banner', 19.5, 17.5), ('banner', 29.5, 17.5),
    ],
)

portal('burg', at=(1, 34), to='steinbruchtal')
