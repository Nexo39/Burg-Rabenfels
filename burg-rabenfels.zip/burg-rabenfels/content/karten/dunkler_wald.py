"""Ein dunkler Wald und die Lager der Orks südlich der Burg."""
from game.registry import game_map, portal

game_map(
    'dunkler_wald', name='Dunkler Wald', light='dunkel', floor=',', start=(20.5, 3.5),
    ambient='wald',
    plan="""
    TTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTT
    T,,,,,,,,,,,,,,,,,,11,,,,,,,,,,,,,,,,,,T
    T,,,,,,,,,,,,,,,,,,::,,,,,,,,,,,,,,,,,,T
    T,,,,,,,,,,,,,,,,,,::,,,,,,,,,,,,,,,,,,T
    T,,,,,,,,,,,,,,,,,,::,,,,,,,,,,,,,,,,,,T
    T,,,,,,,,,,,,,,,,,,::,,,,,,,,,,,,,,,,,,T
    TTTTTTTTTTTTTTTTTTT::TTTTTTTTTTTTTTTTTTT
    T,,,,,,TT,,,,,,,,,,::,,,,T,,,,,,,T,,,,,T
    T,,,,,,,,,,,,,,T,,,::,,,,,,,,,,,,,,,T,,T
    T,,,T,,,,,,,T,,,,,,::,,,T,,,,TTT,,,,,,TT
    T,,,,,,,,,,,,,,,,T,::,,,,,,,,,,,T,,,,,TT
    T,,T,,,^,,,^,,,,T,,::,,T,,,,,,,,,,,,,,,T
    T,R,,,,,,,,,,,,,,,,::,,,,,,,^,,,^,,,,,,T
    T,T,,,,,,::::::::::::,,,TT,,,,,,,,,,,,,T
    T,,,,,,,,,,,,,TT,,,::::::::::::,,,,,,T,T
    T,,T,,,,,,,,B,T,,,,::,,,,,,,,,,,,,,,,RRT
    T,,,T,,,,,,,,,R,T,,::,,,,T,,,,,,,B,,,,,T
    T,,,,,,,T,,,T,,,,,,::,,,,,,,,,,,,,,TT,,T
    T,,,,,,,,,TT,,,TR,,::,,T,,,,,,,R,,,R,,TT
    T,T,,,TT,,T,,,,,,,,::,,,T,R,,R,,,,,,,T,T
    T,,,,R,,,,,,,,,,,,,::,,,,,,,,,,T,,R,,,,T
    T,,,,,,,,,,,,,,,,,,::,,,,,,,,,,,,,,,,,,T
    T,,,,,,,,,,,,,,,,,,::,,,,,,,,,,,,,,,,,,T
    T,,,,R,,^,,,^,,,,,,::,,,,,,,,,,,,,,,R,,T
    TT,,,,,,,,,,,,,,,T,::,,,,,,^,,,^,,,,,T,T
    T,,,,,,,,,:::::::::::,,,,,,,,,,,,,,,,,,T
    T,,,,,,,,,,,,,,,,T,:::::::::::,,,,,,,,,T
    T,,,,,,,,,,,,B,,,,,::,,,,,,,,,,,,,,,,,,T
    T,,,T,,,,,,,,,,,,,,::,,,,,,,,,,,B,,,,,,T
    T,,,,,,,,,,,,,,TR,,::,,,,,,,,,,,,,,,,,,T
    T,TT,,,,T,,T,,,T,,,::,,,,,,,,,,,,T,,,,,T
    T,,,,,,,,,T,,,,,T,,::,,,,,,,,,,,,,,R,,,T
    T,,,,,,,T,,,,,T,TT,::,,,,,,,,,,,,,,,,,,T
    TTTTTTTTTTTTTTTTTTT::TTTTTTTTTTTTTTTTTTT
    T,,,,,,,,,,,,,,,,,,::,,,,,,,,,,,,,,,,,,T
    TTTTTTTTTTTTTTTT,,,::,,,,,T,,,,,,,,,,,,T
    T,,,,,,,,,,,,,,T,,,::,,,,,,,,,,,,,,,,,,T
    T,,R,,,,,,,,R,,T,T,::,,,,,,,,,,,,R,,,,,T
    T,,,,,,,,,,,,,,T,,,::,,,,,T,,,,,,,,,,,,T
    T,,,,,,,,,,,,,,::::::,,,,,,,,,,,,,,,,,,T
    T,,,,,,,,,,,,,,::::::,,,,,,,,,T,,,,,,,,T
    T,,,,,,,,,,,,,,T,,,:::::::::::::::::::2T
    T,,R,,,,,,,,R,,T,,,,,:::::::::::::::::2T
    T,,,,,,,,,,,,,,T,,,,,,,,,,,,,,,,,,,,,,,T
    TTTTTTTTTTTTTTTT,,,,,,T,,,,,,,,T,,,,,,,T
    TTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTT
    """,
    regions=[
        ('Waldrand', (1, 1, 38, 6)),
        ('Lager der Krieger', (5, 10, 13, 16)),
        ('Lager der Jäger', (26, 11, 34, 17)),
        ('Lager der Schamanen', (6, 22, 14, 28)),
        ('Lager der Berserker', (25, 23, 33, 29)),
        ('Lichtung des Häuptlings', (1, 35, 15, 44)),
        ('Pfad ins Moor', (21, 40, 38, 43)),
        ('Dunkler Wald', (0, 0, 39, 45)),
    ],
    zones={
        'kriegerlager': {'rect': (5, 10, 14, 16), 'margin': 2},
        'jaegerlager': {'rect': (25, 11, 35, 17), 'margin': 2},
        'schamanenlager': {'rect': (6, 22, 15, 28), 'margin': 2},
        'berserkerlager': {'rect': (24, 23, 34, 29), 'margin': 2},
        'haeuptling': {'rect': (2, 36, 13, 43), 'margin': 0},
    },
    spawns=[
        ('ork_krieger', 'kriegerlager', 4),
        ('ork_jaeger', 'jaegerlager', 3),
        ('ork_krieger', 'jaegerlager', 2),
        ('ork_schamane', 'schamanenlager', 3),
        ('ork_krieger', 'schamanenlager', 2),
        ('ork_berserker', 'berserkerlager', 3),
        ('ork_jaeger', 'berserkerlager', 2),
        ('ork_haeuptling', 'haeuptling', 1, (8.5, 39.5)),
    ],
    pickups=[
        ('trommel', 6, 12), ('trommel', 10, 14), ('trommel', 8, 15),
        ('trommel', 30, 12), ('trommel', 27, 16), ('trommel', 34, 13),
        ('trommel', 7, 22), ('trommel', 13, 26), ('trommel', 9, 28),
        ('trommel', 26, 23), ('trommel', 30, 27), ('trommel', 25, 29),
    ],
    npcs={
        'dunkler_wald_hueter': {
            'name': 'Waldläuferin Irma', 'role': 'Wächterin des Waldrands', 'at': (23.5, 3.5),
            'look': {'cloth': '#5a6a4a', 'legs': '#4a3a28', 'hat': 'hood', 'weapon': 'staff', 'scale': 1.1},
            'greet': 'Hinter den Bäumen haben Orks ihre Lager aufgeschlagen, und auf der Lichtung im Süden sitzt ihr Häuptling. '
                     'Wer an ihm vorbeikommt, findet am Ende des Pfads den Weg ins Moor.',
            'services': ['potion'],
        },
    },
    portals={'1': {'to': 'burg', 'target': (23.5, 47.5)}, '2': {'to': 'moor'}},
    deco=[
        ('torch', 17.5, 2.5), ('torch', 22.5, 2.5),
        ('torch', 18.5, 7.5), ('torch', 21.5, 7.5),
        ('ghost', 19.5, 12.5), ('ghost', 20.5, 18.5), ('ghost', 19.5, 24.5),
        ('ghost', 20.5, 30.5),
        ('fire', 9.5, 13.5), ('fire', 30.5, 14.5),
        ('fire', 10.5, 25.5), ('fire', 29.5, 26.5),
        ('ghost', 4.5, 8.5), ('ghost', 35.5, 8.5),
        ('ghost', 4.5, 19.5), ('ghost', 35.5, 20.5),
        ('ghost', 5.5, 30.5), ('ghost', 34.5, 31.5),
        ('torch', 16.5, 38.5), ('torch', 16.5, 41.5),
        ('fire', 8.5, 37.5), ('banner', 3.5, 36.5), ('banner', 13.5, 36.5),
        ('ghost', 4.5, 42.5), ('ghost', 12.5, 42.5),
        ('ghost', 19.5, 36.5), ('ghost', 27.5, 42.5), ('torch', 36.5, 40.5), ('torch', 36.5, 43.5),
    ],
)

portal('burg', at=(23, 48), to='dunkler_wald')
