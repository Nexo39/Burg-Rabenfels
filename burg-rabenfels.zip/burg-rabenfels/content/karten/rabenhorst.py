"""Die Ruinen von Altrabenfels hinter dem Steinbruchtal: die erste Burg der Rabenfelser,
heute Sitz des Rabenkönigs und seiner Dunkelritter. Gegnerstufe 41 bis 50."""
from game.registry import game_map, portal

game_map(
    'rabenhorst', name='Ruinen von Altrabenfels', light='tag', floor='.', start=(24.5, 38.5),
    ambient='ruine',
    plan="""
    TTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTT
    TMMMMMMMMMMMMMH____________________HMMMMMMMMMMMMMT
    TMMMMMMMMMMMMMH____________________HMMMMMMMMMMMMMT
    TMMMMMMMMMMMMMH__P______________P__HMMMMMMMMMMMMMT
    TMMMMMMMMMMMMMH____________________HMMMMMMMMMMMMMT
    TMMMMMMMMMMMMMH____________________HMMMMMMMMMMMMMT
    TMMMMMMMMMMMMMH__P______________P__HMMMMMMMMMMMMMT
    TMMMMMMMMMMMMMH____________________HMMMMMMMMMMMMMT
    TO############O#########dd#########O############OT
    T,..............#................#..............,T
    T,..............#................#..............,T
    T,....P.....P...#................#...P.....P....,T
    T,..............#...S........S...#..............,T
    T,..............#................#..............,T
    T,......................WW......................,T
    T,..............................................,T
    T,..............#................#..............,T
    T,..............#...S........S...#..............,T
    T,....P.....P...#................#...P.....P....,T
    T,..............#................#..............,T
    T,..............#................#..............,T
    TO######.########O######..######O########.######OT
    T................#..............#................T
    T................#..............#................T
    T.......P........#..............#.......P........T
    T................#..............#................T
    T..........+.........................+...........T
    T................#..............#................T
    T..R....R....R...#R.............#R....R....R.....T
    T................#..............#................T
    T................#..+.........+.#................T
    T.....P....................................P.....T
    T.............P....................P.............T
    T................................................T
    T................................................T
    TO######################..######################OT
    T,,,,,,,,,,,,,,,,,,,,,,,::,,,,,,,,,,,,,,,,,,,,,,,T
    T,,,,,,,,,,,,,,,,,,,,,,,::,,,,,,,,,,,,,,,,,,,,,,,T
    T,,,,,,,,,,,,,,,,,,^,,,,::,,,,,^,,,,,,,,,,,,,,,,,T
    T,,,,,,,,,,,,,,,,,,,,,,,::,,,B,,,,,,,,,,,,,,,,,,,T
    T,,,,,,,,,,,,,,,,,X,,,,,::,,,,,,X,,,,,,,,,,,,,,,,T
    T,,,,,,,,,,,,,,,,,,,,,,,::,,,,,,,,,,,,,,,,,,,,,,,T
    T,,,,,,,,,,,,,,,,,,,,,,,11,,,,,,,,,,,,,,,,,,,,,,,T
    TTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTT
    """,
    regions=[
        ('Thronsaal des Rabenkönigs', (14, 1, 35, 7)),
        ('Lager der Rabenwacht', (1, 36, 48, 42)),
        ('Westlicher Vorhof', (1, 22, 16, 34)),
        ('Torhof', (17, 22, 32, 34)),
        ('Östlicher Vorhof', (33, 22, 48, 34)),
        ('Innerer Hof', (1, 9, 48, 20)),
        ('Ruinen von Altrabenfels', (0, 0, 49, 43)),
    ],
    zones={
        'westhof': {'rect': (2, 22, 16, 34), 'margin': 1},
        'torhof': {'rect': (18, 22, 31, 33), 'margin': 1},
        'osthof': {'rect': (33, 22, 47, 34), 'margin': 1},
        'innen_west': {'rect': (2, 9, 15, 20), 'margin': 1},
        'innen_mitte': {'rect': (17, 9, 32, 20), 'margin': 1},
        'innen_ost': {'rect': (34, 9, 47, 20), 'margin': 1},
        'thron': {'rect': (15, 1, 34, 7), 'margin': 0},
    },
    spawns=[
        ('dunkelritter', 'westhof', 4),
        ('hoellenhund', 'westhof', 3),
        ('schattenschuetze', 'torhof', 3),
        ('dunkelritter', 'torhof', 2),
        ('hoellenhund', 'osthof', 3),
        ('schattenschuetze', 'osthof', 3),
        ('todesmagier', 'innen_west', 3),
        ('steinwaechter', 'innen_west', 2),
        ('steinwaechter', 'innen_mitte', 3),
        ('todesmagier', 'innen_mitte', 2),
        ('todesmagier', 'innen_ost', 3),
        ('dunkelritter', 'innen_ost', 3),
        ('rabenkoenig', 'thron', 1, (24.5, 4.5)),
    ],
    pickups=[
        ('siegel', 4, 24), ('siegel', 13, 33), ('siegel', 9, 29), ('siegel', 20, 23), ('siegel', 29, 33),
        ('siegel', 36, 23), ('siegel', 45, 33), ('siegel', 41, 29), ('siegel', 4, 10), ('siegel', 45, 19),
        ('siegel', 22, 10), ('siegel', 27, 19),
    ],
    npcs={
        'konrad': {
            'name': 'Ritter Konrad', 'role': 'Hauptmann der Rabenwacht', 'look': 'captain', 'at': (28.5, 37.5),
            'greet': 'Dort oben stand einst die erste Burg der Rabenfelser. Heute sitzt der Rabenkönig auf ihrem Thron, '
                     'und seine Dunkelritter kennen weder Schlaf noch Gnade.',
            'services': ['potion', 'heal', 'elixir', 'weapon', 'armor'],
        },
    },
    portals={'1': {'to': 'steinbruchtal', 'target': (46.5, 3.5)}},
    deco=[
        ('fire', 21.5, 39.5), ('banner', 22.5, 36.5), ('banner', 27.5, 36.5), ('torch', 23.5, 34.5), ('torch', 26.5, 34.5),
        ('banner', 22.5, 2.5), ('banner', 27.5, 2.5), ('torch', 15.5, 5.5), ('torch', 34.5, 5.5),
        ('torch', 23.5, 9.5), ('torch', 26.5, 9.5), ('fire', 24.5, 27.5), ('ghost', 9.5, 14.5), ('ghost', 40.5, 14.5),
    ],
)

portal('steinbruchtal', at=(48, 2), to='rabenhorst')
