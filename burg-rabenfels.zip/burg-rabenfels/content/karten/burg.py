"""Die Burg Rabenfels mit Umland: Burghof, Bergfried, Westflügel, Kapelle, Friedhof, Gruft,
davor Zugbrücke, Goblinlager und Wald. Hier beginnen neue Helden.

Koordinaten sind Kacheln (x, z) ab der linken oberen Ecke des Plans.
`python tools/pruefen.py --karte burg` zeigt den Plan mit Zahlenleiste.
"""
from game.registry import game_map

game_map(
    'burg', name='Burg Rabenfels', main=True, light='tag', start=(24, 24),
    ambient='wind',
    plan="""
    TTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTT
    T,,,,~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~R,,,T
    T,,,,~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~,,R,T
    TT,,,~~,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,~~,,,,T
    TT,,,~~,O##############################O,~~,,,,T
    T,,,T~~,#BBXccccBH..H__SS__H..H________#,~~,,,,T
    T,,,,~~,#cccccccBH..H______H..H________#,~~,,,,T
    TR,,,~~,#ccccccccH..H______H..H______S1#,~~,,,,T
    T,,T,~~,#XcccBBccH..H______H..d______S1#,~~,,,,T
    TT,,,~~,#ccccccccH..H______H..H________#,~~,,,,T
    T,,,,~~,#cccccccXH..H______H..H________#,~~,,,TT
    T,,,,~~,#BcccccccH..H______H..HHHHHHHHH#,~~,,,,T
    T,,RR~~,#BcccccBBH..HHHddHHH..HgggggggT#,~~,,,,T
    T,,,T~~,#HHHdHHHHH............Hg+g+gg+g#,~~T,,,T
    T,,,T~~,#FB______HX...........Hgggggggg#,~~,,,TT
    T,,,,~~,#________HB...........Hg+g+gg+g#,~~,,,TT
    T,,,,~~,#________H............dgggggggg#,~~,,,,T
    T,,,,~~,#___XX___d............Hgggggggg#,~~,,,,T
    T,,,,~~,#________H............Hg+g+gg+g#,~~,T,,T
    TR,,,~~,#________H.........W..Hgggggggg#,~~,,,,T
    T,,T,~~,#B______XH............Hg+g+gg+g#,~~,,,,T
    T,,,,~~,#HHHHHHHHH............HHHHHdHHH#,~~,,,,T
    T,,,,~~,#::::::::.............Hkkkkkkkk#,~~,,,,T
    T,,,,~~,#F:::::::.............HkPkkkkPk#,~~,,,,T
    T,,,,~~,#::A:::::.............Hkkkkkkkk#,~~,,,,T
    TT,,,~~,#B:::::::.............Hkkkkkkkk#,~~,,,,T
    T,,,,~~,#::::::::.............Hkkkkkkkk#,~~,,,,T
    T,,,,~~,#XX::::::...........XBHkPkkkkPk#,~~,,,,T
    T,,,,~~,#::::::::.B...........HkkkSSkkk#,~~,,,,T
    T,R,,~~,O#############ODDO#############O,~~,,R,T
    T,,,T~~,,,,,,,,,,,,,,,,::,,,,,,,,,,,,,,,,~~,,,,T
    T,,,,~~~~~~~~~~~~~~~~~~==~~~~~~~~~~~~~~~~~~,,,,T
    T,,,,~~~~~~~~~~~~~~~~~~==~~~~~~~~~~~~~~~~~~,,,,T
    T,R,,,,,T,,,,,,,,,,,,,,::,,,,,,,T,,,,,,,,,,,,,,T
    T,,,,,,,,,,,,,,,,,T,,,,::,,,,,,,T,,,,,,,,,T,,,,T
    T,,,,,,,,,,,T,,,,T,,,,,::,,,,,,,,,,,,,,,,,,,,,,T
    T,,,,,,,,R,,,,,,,,T,,,,::,,,,,,,,T,,,,,T,R,,,,,T
    T,,,,,,,,,,,,,TT,,,,,,,::,,,,,,,,,,,,,,,,,,T,,,T
    T,,,,,,,,,,,,,,,,,,,,,,::,,,,,,,,,,,,,,,,,,,,,,T
    T,,,,,,,,,,,,,T,,,,,,,,::,,^,,,,,,,,,,,,,,,,,,,T
    T,,,,,,,,,,,,,,,,,,,,,,::,,,,,,,,,,,,R,,,,,,,T,T
    T,,,,,,,,,,,R,T,,,,,,::::::,,,,,T,,,,,,,,T,,,,,T
    T,,,,,,,,,,,,,,,,,,^,::::::,,,,,,,R,,,,,,,T,,,,T
    TTT,R,,,,,,,T,,,,,,,,::::::,^,,,,,,,,,,,,,,,T,,T
    T,,,,,,,T,,,,,,,,,,,,,,,,,,,,,,,,,,,,,T,,,T,,,,T
    T,,,,,,,T,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,T
    T,,,,,,T,,,,,,,,,,,,,,^,,,,,,,,,T,,,,,,,,,T,,,,T
    T,,,,,,,T,,,,,,,,,,,,,,,,,,,,,,,,,,T,,,,,,T,,,,T
    T,,TT,T,T,,,,T,,,,,,,,,,,,,,,,,,,,,,,T,,,,,,TT,T
    TTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTT
    """,
    # Ortsnamen für die Anzeige – der erste Treffer gewinnt
    regions=[
        ('Vorratskeller', (9, 5, 16, 12)),
        ('Burgküche', (9, 14, 16, 20)),
        ('Thronsaal', (21, 5, 26, 11)),
        ('Kapelle', (31, 5, 38, 10)),
        ('Friedhof', (31, 12, 38, 20)),
        ('Gruft des Knochenfürsten', (31, 22, 38, 28)),
        ('Schmiede', (9, 22, 16, 28)),
        ('Burghof', (8, 4, 39, 29)),
        ('Zugbrücke', (23, 30, 24, 32)),
        ('Goblinlager', (14, 37, 33, 47)),
        ('Westwald', (1, 1, 4, 48)),
        ('Ostwald', (43, 1, 46, 48)),
        ('Vor den Mauern', (0, 0, 47, 49)),
    ],
    # Gegnergebiete. margin: so viele Kacheln weit verfolgen die Gegner einen Helden über ihr Gebiet
    # hinaus, bevor sie umkehren und sich erholen.
    zones={
        'keller':   {'rect': (9, 5, 16, 12), 'margin': 5},
        'lager':    {'rect': (14, 37, 33, 47), 'margin': 4},
        'wald_w':   {'rect': (1, 3, 4, 30), 'margin': 3},
        'wald_o':   {'rect': (43, 3, 46, 30), 'margin': 3},
        'friedhof': {'rect': (31, 12, 38, 20), 'margin': 3},
        'gruft':    {'rect': (31, 22, 38, 28), 'margin': 0},
    },
    spawns=[
        ('rat', 'keller', 7),
        ('goblin', 'lager', 9),
        ('wolf', 'wald_w', 3),
        ('wolf', 'wald_o', 3),
        ('skeleton', 'friedhof', 6),
        ('boss', 'gruft', 1, (35, 25.5)),          # fester Platz
    ],
    pickups=[
        ('supply', 20, 41), ('supply', 27, 41), ('supply', 23, 44),
        ('supply', 18, 45), ('supply', 29, 45), ('supply', 26, 38),
        ('ore', 2, 6), ('ore', 3, 14), ('ore', 2, 22),
        ('ore', 45, 7), ('ore', 44, 15), ('ore', 45, 23),
    ],
    npcs={
        'gerold': {
            'name': 'Hauptmann Gerold', 'role': 'Hauptmann der Wache', 'look': 'captain', 'at': (21.4, 14.6),
            'greet': 'Willkommen auf Rabenfels. Hier gibt es mehr Arbeit als Schwerter – gut, dass du da bist.',
        },
        'marthe': {
            'name': 'Köchin Marthe', 'role': 'Herrin über Küche und Keller', 'look': 'cook', 'at': (14.5, 16.0),
            'greet': 'Füße abtreten! Wer kämpft, muss essen – und wer isst, kann mir auch zur Hand gehen.',
            'services': ['potion', 'elixir'],
        },
        'bruna': {
            'name': 'Schmiedin Bruna', 'role': 'Waffenschmiedin', 'look': 'smith', 'at': (12.5, 23.6),
            'greet': 'Eine stumpfe Klinge ist ein teurer Löffel. Zeig her, was du trägst.',
            'services': ['weapon', 'armor'],
        },
        'anselm': {
            'name': 'Bruder Anselm', 'role': 'Hüter der Kapelle', 'look': 'priest', 'at': (35.5, 8.0),
            'greet': 'Friede sei mit dir. Wer verwundet ist, findet hier Heilung.',
            'services': ['heal'],
        },
        'adelheid': {
            'name': 'Burgherrin Adelheid', 'role': 'Herrin von Rabenfels', 'look': 'lady', 'at': (24.0, 7.0),
            'greet': 'Rabenfels ist klein, aber es ist unser. Dien der Burg, und sie wird es dir lohnen.',
            'services': ['respec'],
        },
    },
    # Die Ziffer 1 im Plan (hinter dem Altar der Kapelle) ist die Treppe in die Katakomben.
    portals={'1': {'to': 'katakomben', 'target': (15, 4.5)}},
    deco=[
        ('torch', 22.5, 28.5), ('torch', 25.5, 28.5), ('torch', 22.6, 30.5), ('torch', 25.4, 30.5),      # Tor
        ('torch', 22.6, 13.4), ('torch', 25.4, 13.4), ('torch', 21.4, 6.4), ('torch', 26.6, 6.4),        # Bergfried
        ('torch', 18.4, 16.2), ('torch', 10.4, 9.5), ('torch', 17.6, 24.5),                              # Westflügel
        ('torch', 29.5, 7.2), ('torch', 29.5, 17.4), ('torch', 32.4, 5.5), ('torch', 29.4, 24.5),        # Ostflügel
        ('ghost', 31.5, 22.5), ('ghost', 38.5, 22.5), ('ghost', 35.5, 16.5), ('ghost', 31.5, 28.5), ('ghost', 38.5, 28.5),
        ('fire', 24.0, 42.2),                                                                            # Lagerfeuer der Goblins
        ('banner', 22.2, 13.1), ('banner', 25.8, 13.1),
    ],
)
