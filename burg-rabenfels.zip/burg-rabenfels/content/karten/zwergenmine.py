"""Die verlassene Zwergenmine Grauhall östlich des Moors. Kobolde haben die Stollen besetzt,
in der Schmiede erwachen die Golems, und in der Glutkammer schlägt das Eiserne Herz.
Gegnerstufe 21 bis 30."""
from game.registry import game_map

game_map(
    'zwergenmine', name='Zwergenmine Grauhall', light='dunkel', floor='c', start=(5.5, 6.5),
    ambient='hoehle',
    plan="""
    MMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMM
    MMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMM
    MMcBBcccccccXcMMMMMMMcRcccccccccccccccccccccccMM
    MMccccccccccccMMMMMMMcccccccccccccccXcccccccccMM
    M1ccccccccccccMMMMMMMcccXcccccccccccccccccccccMM
    M1cccccccccccccccccccccccccccSccccccccccccccXcMM
    MMcccccccccccccccccccccccccccccccBccccccccccccMM
    MMccccccccccccccccccccccccccccccccccccccccccccMM
    MMcccccccccBBcMMMMMMMccccccccccccccccScccXccccMM
    MMccccccccccccMMMMMMMcccccccccXcccccccccccccccMM
    MMMMMMcccMMMMMMMMMMMMcccccccccccccccccccccccccMM
    MMMMMMcccMMMMMMMMMMMMccccccXcccccccccccBccccccMM
    MMMMMMcccMMMMMMMMMMMMccccccccccccccccccccccccRMM
    MMMMMMcccMMMMMMMMMMMMMMMcccMMMMMMMMMMMMcccMMMMMM
    MMMMMMcccMMMMMMMMMMMMMMMcccMMMMMMMMMMMMcccMMMMMM
    MMMMMMcccMMMMMMMMMcccccccccccccMMMMMMMMcccMMMMMM
    MMcccccccccccccMMMccccccccccc+cMMMccccccccccccMM
    MMcccccccccccccMMMccPcccPcccPccMMMccccccccccccMM
    MMccRccccccccccMMMcccccccccccccMMMccFccccccFccMM
    MMcccccccccccccMMMcccccccccccccMMMccccccccccccMM
    MMcccccccccRcccMMMccccccccccccccccccccccccccccMM
    MMccccccccccccccccccPcccPcccPcccccccccccccccccMM
    MMcccccSccccccccccccccccccccccccccccccccccccccMM
    MMcccccccccccRcccccccccccccccccMMMccccAcccccccMM
    MMcccccccccccccMMMcccccccccccccMMMcccccccccccSMM
    MMcRcccccccccccMMMccPcccPcccPccMMMccccccccccccMM
    MMcccccccccccccMMMcccccccccccccMMMcccccccAccccMM
    MMcccccccRcccccMMMc+cccccccccccMMMccccccccccccMM
    MMcccccccccccccMMMcccccccccccccMMMccccccccccccMM
    MMcccccccccccccMMMMMMMMcccMMMMMMMMccFccccccFccMM
    MMMMMMMMMMMMMMMMMMMMMMMcccMMMMMMMMccccccccccccMM
    MMMMMMMMMMMMMMMMMMMMMMMcccMMMMMMMMccccccccccccMM
    MMMMMMMMMMMMMMcccccccccccccccccccccMMMMMMMMMMMMM
    MMMMMMMMMMMMMMcccccccccccccccccccccMMMMMMMMMMMMM
    MMMMMMMMMMMMMMccPcccccccccccccccPccMMMMMMMMMMMMM
    MMMMMMMMMMMMMMcccccccccccccccccccccMMMMMMMMMMMMM
    MMMMMMMMMMMMMMcccccccccccccccccccccMMMMMMMMMMMMM
    MMMMMMMMMMMMMMcccccccccccccccccccccMMMMMMMMMMMMM
    MMMMMMMMMMMMMMccPcccccccccccccccPccMMMMMMMMMMMMM
    MMMMMMMMMMMMMMcccccccccccccccccccccMMMMMMMMMMMMM
    MMMMMMMMMMMMMMccccccccccFccccccccccMMMMMMMMMMMMM
    MMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMM
    """,
    regions=[
        ('Eingangshalle', (2, 2, 13, 9)),
        ('Koboldstollen', (14, 2, 45, 12)),
        ('Grubengänge', (2, 10, 14, 29)),
        ('Halle der Ahnen', (15, 13, 33, 28)),
        ('Golemschmiede', (34, 13, 45, 31)),
        ('Glutkammer', (14, 29, 34, 40)),
        ('Zwergenmine Grauhall', (0, 0, 47, 41)),
    ],
    zones={
        'kobolde': {'rect': (22, 2, 45, 12), 'margin': 2},
        'gruben': {'rect': (2, 16, 14, 29), 'margin': 2},
        'ahnen': {'rect': (18, 15, 30, 28), 'margin': 2},
        'schmiede': {'rect': (34, 16, 45, 31), 'margin': 2},
        'glutkammer': {'rect': (14, 32, 34, 40), 'margin': 0},
    },
    spawns=[
        ('kobold', 'kobolde', 6),
        ('kobold_werfer', 'kobolde', 3),
        ('grubenkriecher', 'gruben', 6),
        ('kobold', 'gruben', 2),
        ('zwergengeist', 'ahnen', 6),
        ('steingolem', 'schmiede', 4),
        ('kobold_werfer', 'schmiede', 2),
        ('glutherz', 'glutkammer', 1, (24.5, 36.5)),
    ],
    pickups=[
        ('glutkristall', 25, 3), ('glutkristall', 32, 10), ('glutkristall', 43, 3), ('glutkristall', 38, 6),
        ('glutkristall', 23, 9), ('glutkristall', 44, 10), ('glutkristall', 35, 19), ('glutkristall', 44, 21),
        ('glutkristall', 37, 27), ('glutkristall', 42, 30), ('glutkristall', 40, 15), ('glutkristall', 34, 24),
    ],
    npcs={
        'borin': {
            'name': 'Borin Grauhand', 'role': 'letzter Zwerg von Grauhall', 'at': (9.5, 4.5),
            'look': {'cloth': '#6a4a32', 'legs': '#3d3229', 'arms': '#e2b48c', 'hat': 'helmet', 'hatColor': '#7a6a50',
                     'hair': '#c8c0b0', 'pads': '#7a6a50', 'apron': '#3a2c20', 'weapon': 'hammer', 'scale': 0.85},
            'greet': 'Grauhall war einst die reichste Mine im ganzen Land. Jetzt hausen Kobolde in den Stollen, '
                     'und aus der Glutkammer dringt ein Herzschlag aus Eisen.',
            'services': ['potion', 'elixir', 'weapon', 'armor'],
        },
    },
    portals={'1': {'to': 'moor', 'target': (42.5, 32.5)}},
    deco=[
        ('torch', 3.5, 3.5),
        ('torch', 9.5, 3.5),
        ('torch', 13.5, 3.5),
        ('torch', 21.5, 3.5),
        ('torch', 27.5, 3.5),
        ('torch', 33.5, 3.5),
        ('torch', 39.5, 3.5),
        ('torch', 45.5, 3.5),
        ('torch', 3.5, 9.5),
        ('torch', 9.5, 9.5),
        ('torch', 15.5, 7.5),
        ('torch', 21.5, 9.5),
        ('torch', 27.5, 9.5),
        ('torch', 33.5, 9.5),
        ('torch', 39.5, 9.5),
        ('torch', 45.5, 9.5),
        ('torch', 3.5, 16.5),
        ('torch', 8.5, 15.5),
        ('torch', 14.5, 16.5),
        ('ghost', 21.5, 15.5),
        ('ghost', 27.5, 15.5),
        ('fire', 34.5, 16.5),
        ('torch', 39.5, 15.5),
        ('fire', 45.5, 16.5),
        ('torch', 3.5, 21.5),
        ('torch', 9.5, 21.5),
        ('torch', 15.5, 21.5),
        ('ghost', 21.5, 21.5),
        ('ghost', 27.5, 21.5),
        ('torch', 33.5, 21.5),
        ('fire', 39.5, 21.5),
        ('fire', 45.5, 21.5),
        ('torch', 3.5, 27.5),
        ('torch', 9.5, 26.5),
        ('torch', 14.5, 27.5),
        ('ghost', 21.5, 27.5),
        ('ghost', 27.5, 27.5),
        ('fire', 34.5, 27.5),
        ('fire', 39.5, 27.5),
        ('fire', 45.5, 27.5),
        ('fire', 15.5, 33.5),
        ('fire', 21.5, 33.5),
        ('fire', 27.5, 33.5),
        ('fire', 33.5, 33.5),
        ('fire', 39.5, 31.5),
        ('fire', 45.5, 31.5),
        ('fire', 15.5, 39.5),
        ('fire', 21.5, 39.5),
        ('fire', 27.5, 39.5),
        ('fire', 33.5, 39.5),
    ],
)
