"""Das Moor südlich des dunklen Waldes: Echsenvolk, Irrlichter, Sumpftrolle und die Hexe im Hain.
Gegnerstufe 11 bis 20. Im Osten, hinter der Trollfurt, liegt der Eingang zur Zwergenmine."""
from game.registry import game_map

game_map(
    'moor', name='Das Moor', light='tag', floor=',', start=(5.5, 3.5),
    ambient='sumpf',
    plan="""
    TTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTT
    T,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,T
    T1,,,,,,,,,,BBX,,,,,,,~~~~~~~~~,,,,,,,,,,,,,,T
    T1,,,,,,,,,,,,,,,,,,~~~~~~~~~~~~~,,,,,,,,,,,,T
    T,::::::::::::::::::=============:::::::::,,,T
    T,,,,,::,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,::,,,T
    T,,,,,::,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,::,,,T
    TTTTTT::TTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTT::TTTT
    T,,,,,::,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,::,,,T
    T,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,T
    T,,T,,,,,,,,,,,,T,,,,,,,,,,,,R,,T,,,,,,,,,,,,T
    T,,,,,,,,,,,T,,,T,,,,,,,,,,,,,,,,,,,^,,,,^,,,T
    T,,,,,,,,R,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,T
    T,,,,~~~,,,,,,,,,,,,,,~~~~~,,,,,,,,,,,,X,,,,,T
    T,,,~~~~~,,,,,,,,,,,~~~~~~~~~,,,,T,,,,,,,,,,,T
    T,,,~~~~~,,,,,,,,,,~~~~~~~~~~~,,,,,,,,^,,,,,,T
    T,,,~~~~~,,,,,,,,===============,,,,,,,,,,,,,T
    T,,,,~~~,,,,,,,,,===============,,,X,,,,,,,,,T
    T,,,,,,,,,,,,T,,,,,~~~~~~~~~~~,,,,,,,,,,,,,,,T
    T,,,,,,,,,,,,,,,T,,,~~~~~~~~~,,,,,,,,,,,,,^,,T
    T,,,R,,,,,,,,,,,T,,,,,~~~~~,,,,,,,,,^,,,,,,,,T
    T,,,,,,,,,T,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,T
    T,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,T,,,,,,,,,,B,T
    T,,T,,,,,,,,,,,,,,,R,,,,,,,,,,,,,,,,,,,,,,,,,T
    T,,,,,,,,,,,,,,,,,,,,,,,::,,,,,,,,,,,,,,,,,,,T
    T,,,,,,,,,,,,,,,,,,,,,,,::,,,,,,,,,,,,,,,,,,,T
    TTTTTT,,TTTTTTTTTTTTTTTT::TTTTTTTTTTTT,,TTTTTT
    T,,,,,,,,,,,,,,,,,,,,,,,::,,,,,~~,,,,,,T,,,,,T
    TTTTTTTTTTTTTTTTTT,,,,,,::,,,,,~~,,,,,,T,,,,,T
    TT,,,,,,,,,,,,,,,T,,,R,,,,,,T,,~~,,R,,,T,,,,,T
    TT,,,,,,,^,,,,,,,T,,,,,,,,,,,,,~~,,,,,,T,,,,,T
    TT,,+,,,,,,,,,+,,T,,,,,,,,,,,,,~~,,,,,,T,,,,,T
    TT,,,,,,,,,,,,,,,::::::::::::::==:::::::::::2T
    TT,,,,,,,,,,,,,,,:::::::,,,,,,,==:::::::::::2T
    TT,,,,,,,,,,,,,,,T,,,,,,,,,,,,,~~,,,,,,T,,,,,T
    TT,,,,,,,,,,,,,,,T,,,,,,,,,,,,,~~,T,,,,T,,,,,T
    TT,,+,,,,,,,,,+,,T,,,,,,,,,R,,,~~,,,,,,T,,,,,T
    TT,,,,,,,,,,,,,,,T,,,,R,,,,,,,,~~,,,R,,T,,,,,T
    TTTTTTTTTTTTTTTTTT,,,,,,,,,,,,,~~,,,,,,T,,,,,T
    TTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTT
    """,
    regions=[
        ('Wilmas Steg', (1, 1, 44, 6)),
        ('Hexenhain', (1, 28, 17, 38)),
        ('Vor der Zwergenmine', (40, 27, 44, 38)),
        ('Trollfurt', (18, 27, 39, 38)),
        ('Echsenufer', (1, 8, 15, 25)),
        ('Irrlichtsee', (16, 8, 32, 25)),
        ('Echsendorf', (33, 8, 44, 25)),
        ('Das Moor', (0, 0, 45, 39)),
    ],
    zones={
        'echsenufer': {'rect': (2, 9, 14, 24), 'margin': 2},
        'irrlichtsee': {'rect': (17, 9, 31, 24), 'margin': 2},
        'echsendorf': {'rect': (34, 9, 44, 24), 'margin': 2},
        'trollfurt': {'rect': (19, 28, 37, 38), 'margin': 1},
        'hexenhain': {'rect': (2, 29, 16, 37), 'margin': 0},
    },
    spawns=[
        ('sumpfechse', 'echsenufer', 6),
        ('echsenkrieger', 'echsenufer', 2),
        ('irrlicht', 'irrlichtsee', 5),
        ('sumpfechse', 'irrlichtsee', 2),
        ('echsenkrieger', 'echsendorf', 4),
        ('echsenschamane', 'echsendorf', 3),
        ('sumpftroll', 'trollfurt', 4),
        ('echsenschamane', 'trollfurt', 2),
        ('sumpfhexe', 'hexenhain', 1, (9.5, 33.5)),
    ],
    pickups=[
        ('moorkraut', 5, 10), ('moorkraut', 11, 13), ('moorkraut', 2, 19), ('moorkraut', 8, 22),
        ('moorkraut', 13, 24), ('moorkraut', 18, 12), ('moorkraut', 29, 13), ('moorkraut', 18, 21),
        ('moorkraut', 30, 20), ('moorkraut', 27, 23), ('moorkraut', 36, 13), ('moorkraut', 42, 23),
    ],
    npcs={
        'wilma': {
            'name': 'Kräuterfrau Wilma', 'role': 'Hüterin des Moors', 'at': (10.5, 3.5),
            'look': {'cloth': '#5f6b45', 'robe': '#4a5236', 'hat': 'hood', 'hatColor': '#3d4430', 'apron': '#8a7a55',
                     'weapon': 'staff', 'orb': '#a5ff68', 'scale': 1.0},
            'greet': 'Bleib auf den Bohlen, wenn du kannst. Das Moor nimmt, was ihm zu nahe kommt – '
                     'und seit die Hexe im Hain wohnt, gibt es nichts mehr zurück.',
            'services': ['potion', 'heal', 'elixir'],
        },
    },
    portals={'1': {'to': 'dunkler_wald', 'target': (36.5, 41.5)}, '2': {'to': 'zwergenmine'}},
    deco=[
        ('fire', 8.5, 2.5), ('torch', 15.5, 2.5),
        ('ghost', 21.5, 15.5), ('ghost', 27.5, 18.5), ('ghost', 24.5, 13.5),
        ('banner', 37.5, 13.5), ('fire', 39.5, 17.5),
        ('torch', 18.5, 31.5), ('torch', 18.5, 34.5), ('ghost', 9.5, 30.5), ('ghost', 5.5, 34.5), ('ghost', 13.5, 34.5),
        ('torch', 40.5, 31.5), ('torch', 40.5, 34.5),
    ],
)

