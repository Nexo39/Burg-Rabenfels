"""Die Katakomben unter der Kapelle: eine sichere Vorhalle und die Halle der Gebeine,
ein endloses Verlies. Wer die Halle betritt, weckt die Toten der nächsten Ebene.
"""
from game.registry import game_map

game_map(
    'katakomben', name='Katakomben', light='dunkel', floor='k', start=(13, 5.5),
    ambient='gruft',
    plan="""
    MMMMMMMMMMMMMMMMMMMMMMMMMMMMMM
    MMMMMMMMMMMMMMMMMMMMMMMMMMMMMM
    MMMMMMMMMMkkkk11kkkkMMMMMMMMMM
    MMMMMMMMMMkkkkkkkkkkMMMMMMMMMM
    MMMMMMMMMMkkkkkkkkkkMMMMMMMMMM
    MMMMMMMMMMkkkkkkkkkkMMMMMMMMMM
    MMMMMMMMMMkkkkkkkkkkMMMMMMMMMM
    MMMMMMMMMMkkkkkkkkkkMMMMMMMMMM
    MMMMMMMMMMkkkkkkkkkkMMMMMMMMMM
    MMMMMMMMMMMMMMkkMMMMMMMMMMMMMM
    MMMMMMMMMMMMMMkkMMMMMMMMMMMMMM
    MMMMMMMMMMMMMMkkMMMMMMMMMMMMMM
    MMkkSkkkSkkkkkkkkkkkkSkkkSkkMM
    MMkkkkkkkkkkkkkkkkkkkkkkkkkkMM
    MMkkkkkkkkkkkkkkkkkkkkkkkkkkMM
    MMkkkkkkkkkkkkkkkkkkkkkkkkkkMM
    MMkkkkPkkkkPkkkkkkPkkkkPkkkkMM
    MMkkkkkkkkkkkkkkkkkkkkkkkkkkMM
    MMRkkkkkkkkkkkkkkkkkkkkkkkkkMM
    MMkkkkkkkkkkkkkkkkkkkkkkkkkkMM
    MMkkkkkkkkkkkkkkkkkkkkkkkkkkMM
    MMkkkkPkkkkPkkkkkkPkkkkPkkkkMM
    MMkkkkkkkkkkkkkkkkkkkkkkkkkkMM
    MMkkkkkkkkkkkkkkkkkkkkkkkkkkMM
    MMkkkkkkkkkkkkkkkkkkkkkkkkkRMM
    MMkkkkkkkkkkkkkkkkkkkkkkkkkkMM
    MMkkkkPkkkkPkkkkkkPkkkkPkkkkMM
    MMkkkkkkkkkkkkkkkkkkkkkkkkkkMM
    MMkkkkkkkkkkkkkkkkkkkkkkkkkkMM
    MMkkkkkkkkkkkkkkkkkkkkkkkkkkMM
    MMkRkkkkkkkkkkkkkkkkkkkkkkRkMM
    MMMMMMMMMMMMMMMMMMMMMMMMMMMMMM
    MMMMMMMMMMMMMMMMMMMMMMMMMMMMMM
    """,
    regions=[
        ('Vorhalle der Katakomben', (10, 2, 19, 8)),
        ('Halle der Gebeine', (2, 9, 27, 30)),
    ],
    # margin 3 schließt den Gang ein: Wer ihn betritt, weckt die Halle.
    zones={'halle': {'rect': (2, 12, 27, 30), 'margin': 3}},
    npcs={
        'kaspian': {
            'name': 'Totenwächter Kaspian', 'role': 'Hüter der Katakomben', 'look': 'guardian', 'at': (18, 5),
            'greet': 'Hinter dem Gang liegt die Halle der Gebeine. Wer sie betritt, weckt die Toten der nächsten '
                     'Ebene – und mit jeder Ebene werden sie stärker. Hier in der Vorhalle bist du sicher.',
            'services': ['dungeon'],
        },
    },
    # Die Ziffer 1 im Plan ist die Treppe hinauf in die Kapelle.
    portals={'1': {'to': 'burg', 'target': (36, 9.5)}},
    deco=[
        ('ghost', 10.5, 3.5), ('ghost', 19.5, 3.5), ('ghost', 10.5, 8.5), ('ghost', 19.5, 8.5),          # Vorhalle
        ('ghost', 12.5, 12.5), ('ghost', 17.5, 12.5), ('ghost', 2.5, 12.5), ('ghost', 27.5, 12.5),       # Halle
        ('ghost', 2.5, 21.5), ('ghost', 27.5, 21.5), ('ghost', 2.5, 30.5), ('ghost', 27.5, 30.5),
        ('ghost', 8.5, 30.5), ('ghost', 21.5, 30.5), ('ghost', 10, 18.5), ('ghost', 20, 18.5),
        ('ghost', 10, 24.5), ('ghost', 20, 24.5),
    ],
    # Endloses Verlies in der Zone 'halle': Gegnerstufe = base_level + Ebene.
    # mix: (Gegnerart, ab welcher Ebene, Gewicht bei der Auswahl). Jede fünfte Ebene gehört dem Boss.
    dungeon={
        'zone': 'halle', 'base_level': 7,
        'mix': [('knochen', 1, 5), ('aasratte', 1, 4), ('knochenmagier', 3, 3), ('geist', 6, 3), ('waechter', 9, 2)],
        'boss': 'gruftlord', 'boss_every': 5,
    },
)
