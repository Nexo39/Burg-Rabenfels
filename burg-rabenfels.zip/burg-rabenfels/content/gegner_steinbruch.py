"""Gnolls des Steinbruchtals und ihr Feldherr."""
from game.registry import enemy

enemy('gnoll_spaeher', 'Gnollspäher', lvl=31, hp=2100, dmg=63, speed=5.6, radius=0.5,
      aggro=10.0, range=1.6, cd=1.2, xp=1220, gold=(31, 63), respawn=18,
      look={'skin': '#a58a61', 'ears': '#a58a61', 'arms': '#a58a61', 'cloth': '#706044',
            'legs': '#514839', 'weapon': 'club', 'scale': 1.05})
enemy('gnoll_krieger', 'Gnollkrieger', lvl=32, hp=2228, dmg=65, speed=4.5, radius=0.55,
      aggro=9.0, range=1.7, cd=1.3, xp=1296, gold=(32, 65), respawn=18,
      look={'skin': '#8c7355', 'ears': '#8c7355', 'arms': '#8c7355', 'cloth': '#67503d',
            'legs': '#493a30', 'weapon': 'sword', 'shield': '#77604a', 'scale': 1.1})
enemy('gnoll_jaeger', 'Gnolljäger', lvl=33, hp=1651, dmg=67, speed=4.8, radius=0.5,
      aggro=12.0, range=11.0, cd=2.4, xp=1374, gold=(33, 67), respawn=18, shot=10.0,
      look={'skin': '#b29a6c', 'ears': '#b29a6c', 'arms': '#b29a6c', 'cloth': '#615d40',
            'legs': '#454731', 'bow': True, 'scale': 1.05})
enemy('gnoll_schlaeger', 'Gnollschläger', lvl=35, hp=2634, dmg=71, speed=4.1, radius=0.65,
      aggro=9.0, range=1.8, cd=1.5, xp=1537, gold=(35, 71), respawn=20,
      look={'skin': '#826b50', 'ears': '#826b50', 'arms': '#826b50', 'cloth': '#544637',
            'legs': '#3d332b', 'pads': '#6e6051', 'weapon': 'hammer', 'scale': 1.35})
enemy('gnoll_schamane', 'Gnollschamane', lvl=37, hp=2046, dmg=75, speed=3.8, radius=0.5,
      aggro=12.0, range=11.0, cd=2.4, xp=1710, gold=(37, 75), respawn=20, shot=10.0,
      look={'skin': '#9a8265', 'ears': '#9a8265', 'arms': '#9a8265', 'cloth': '#514539',
            'robe': '#40372e', 'weapon': 'staff', 'orb': '#e5a84e', 'eyeGlow': '#e5a84e', 'scale': 1.1})
enemy('gnoll_wache', 'Gnollwache', lvl=39, hp=3228, dmg=79, speed=4.0, radius=0.65,
      aggro=9.0, range=1.9, cd=1.5, xp=1892, gold=(39, 79), respawn=22,
      look={'skin': '#766551', 'ears': '#766551', 'arms': '#766551', 'cloth': '#51443c',
            'legs': '#3c332c', 'hat': 'helmet', 'hatColor': '#5e5b55', 'pads': '#6f6b62',
            'weapon': 'sword', 'shield': '#68645c', 'scale': 1.3})
enemy('gnoll_feldherr', 'Feldherr Graufang', lvl=40, hp=50790, dmg=122, speed=3.6, radius=1.1,
      aggro=12.0, range=2.4, cd=1.7, xp=9930, gold=(300, 450), respawn=90,
      boss=True, summon='gnoll_krieger', moves=['charge', 'cone', 'slam'],
      look={'skin': '#706a5c', 'ears': '#706a5c', 'arms': '#706a5c', 'cloth': '#573b32',
            'legs': '#39302a', 'hat': 'helmet', 'hatColor': '#60594e', 'plume': '#a55436',
            'cape': '#6d342d', 'pads': '#777064', 'weapon': 'greatsword', 'eyeGlow': '#ffd15a',
            'scale': 2.1},
      dust='#b59875')
