"""Bewohner des Moors (Stufe 11–20) und die Sumpfhexe im Hain."""
from game.registry import enemy

enemy('sumpfechse', 'Sumpfechse', lvl=11, hp=344, dmg=23, speed=5.4, radius=0.6, aggro=8.0, range=1.5, cd=1.1,
      xp=184, gold=(11, 23), respawn=15,
      look={'body': 'beast', 'fur': '#4f6a3a', 'dark': '#34472a', 'tail': '#4f6a3a', 'ear': '#4f6a3a',
            'eyeGlow': '#ffd23a', 'scale': 1.25},
      dust='#5f7a45')
enemy('irrlicht', 'Irrlicht', lvl=13, hp=360, dmg=27, speed=5.0, radius=0.45, aggro=12.0, range=11.0, cd=2.2,
      xp=246, gold=(13, 27), respawn=15, shot=10.0,
      look={'skin': '#c8ffd8', 'cloth': '#9affc0', 'robe': '#7ae0a0', 'arms': '#b0f0c8', 'thin': True,
            'eyeGlow': '#ffffff', 'opacity': 0.45, 'scale': 0.8},
      dust='#9affc0')
enemy('echsenkrieger', 'Echsenkrieger', lvl=14, hp=510, dmg=29, speed=4.6, radius=0.55, aggro=9.0, range=1.7, cd=1.3,
      xp=280, gold=(14, 29), respawn=16,
      look={'skin': '#5f7f45', 'arms': '#5f7f45', 'cloth': '#5a4a30', 'legs': '#3f3a28', 'weapon': 'sword',
            'bladeColor': '#a8b0a0', 'shield': '#6a5a3a', 'eyeGlow': '#ffd23a', 'scale': 1.12})
enemy('echsenschamane', 'Echsenschamane', lvl=16, hp=510, dmg=33, speed=3.8, radius=0.5, aggro=12.0, range=11.0, cd=2.4,
      xp=356, gold=(16, 33), respawn=16, shot=10.0,
      look={'skin': '#6a8f55', 'arms': '#6a8f55', 'cloth': '#4a5a32', 'robe': '#3a4a2a', 'hat': 'hood',
            'hatColor': '#2f3a22', 'weapon': 'staff', 'orb': '#a5ff68', 'eyeGlow': '#a5ff68', 'scale': 1.05},
      dust='#a5ff68')
enemy('sumpftroll', 'Sumpftroll', lvl=18, hp=980, dmg=37, speed=3.6, radius=0.8, aggro=9.0, range=2.1, cd=1.7,
      xp=442, gold=(18, 37), respawn=18,
      look={'skin': '#5a6a50', 'arms': '#5a6a50', 'ears': '#5a6a50', 'cloth': '#4a3f30', 'legs': '#3a3228',
            'weapon': 'club', 'eyeGlow': '#c8ff5a', 'scale': 1.75},
      dust='#6a7a5a')
# Die Hexe ruft bei halbem Leben Irrlichter.
enemy('sumpfhexe', 'Sumpfhexe Mirra', lvl=20, hp=14200, dmg=62, speed=3.8, radius=1.0, aggro=12.0, range=2.4, cd=1.6,
      xp=2680, gold=(150, 220), respawn=90, boss=True, summon='irrlicht', moves=['volley', 'rain', 'nova'],
      look={'skin': '#9ab08a', 'arms': '#9ab08a', 'cloth': '#3a2a3a', 'robe': '#2a1f2a', 'hat': 'wizard',
            'hatColor': '#2a1f2a', 'cape': '#1f2a1f', 'weapon': 'staff', 'orb': '#a5ff68', 'eyeGlow': '#a5ff68',
            'hair': '#c8c8b0', 'scale': 1.9},
      dust='#a5ff68')
