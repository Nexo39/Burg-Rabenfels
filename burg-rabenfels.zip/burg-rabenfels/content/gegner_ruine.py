"""Die Dunkelritter der Ruinen von Altrabenfels (Stufe 41–50) und der Rabenkönig."""
from game.registry import enemy

enemy('dunkelritter', 'Dunkelritter', lvl=41, hp=3548, dmg=83, speed=4.4, radius=0.55, aggro=9.0, range=1.8, cd=1.3,
      xp=2083, gold=(41, 83), respawn=18,
      look={'skin': '#9aa1a8', 'cloth': '#2a2a33', 'legs': '#1d1d24', 'arms': '#3a3a44', 'hat': 'helmet',
            'hatColor': '#1d1d24', 'plume': '#5a1a2a', 'pads': '#3a3a44', 'weapon': 'sword', 'bladeColor': '#6a7080',
            'shield': '#2a2a33', 'eyeGlow': '#ff3a3a', 'scale': 1.15})
enemy('schattenschuetze', 'Schattenschütze', lvl=43, hp=3106, dmg=87, speed=4.8, radius=0.5, aggro=12.0, range=11.0,
      cd=2.3, xp=2283, gold=(43, 87), respawn=18, shot=10.0,
      look={'skin': '#8a8a96', 'cloth': '#2e2a3a', 'legs': '#1f1c28', 'arms': '#2e2a3a', 'hat': 'hood',
            'hatColor': '#1f1c28', 'cape': '#1a1822', 'bow': True, 'eyeGlow': '#b38cff', 'scale': 1.05})
enemy('hoellenhund', 'Höllenhund', lvl=44, hp=4056, dmg=89, speed=6.0, radius=0.65, aggro=9.0, range=1.6, cd=1.1,
      xp=2386, gold=(44, 89), respawn=18,
      look={'body': 'beast', 'fur': '#2a1a1a', 'dark': '#120a0a', 'ear': '#3a1a1a', 'tail': '#2a1a1a',
            'eyeGlow': '#ff5a2a', 'scale': 1.5},
      dust='#ff6a3a')
enemy('todesmagier', 'Todesmagier', lvl=45, hp=3387, dmg=91, speed=3.8, radius=0.5, aggro=12.0, range=11.0, cd=2.4,
      xp=2492, gold=(45, 91), respawn=20, shot=10.0,
      look={'skin': '#d8d0c0', 'arms': '#c8c0b0', 'cloth': '#24242e', 'robe': '#1a1a24', 'thin': True,
            'hat': 'wizard', 'hatColor': '#1a1a24', 'weapon': 'staff', 'orb': '#59ffc0', 'eyeGlow': '#59ffc0',
            'scale': 1.1},
      dust='#59ffc0')
enemy('steinwaechter', 'Steinerner Wächter', lvl=47, hp=5979, dmg=95, speed=3.4, radius=0.85, aggro=8.0, range=2.2,
      cd=1.8, xp=2711, gold=(47, 95), respawn=22,
      look={'skin': '#7a7a80', 'arms': '#7a7a80', 'cloth': '#5a5a62', 'legs': '#4a4a52', 'pads': '#8a8a92',
            'hat': 'helmet', 'hatColor': '#5a5a62', 'weapon': 'hammer', 'shield': '#5a5a62', 'eyeGlow': '#8fd8ff',
            'scale': 1.7},
      dust='#8a8a92')
# Der Rabenkönig ruft bei halbem Leben seine Dunkelritter.
enemy('rabenkoenig', 'Der Rabenkönig', lvl=50, hp=77600, dmg=152, speed=3.8, radius=1.2, aggro=12.0, range=2.6, cd=1.7,
      xp=15280, gold=(500, 700), respawn=90, boss=True, summon='dunkelritter',
      moves=['cone', 'charge', 'volley', 'rain'],
      look={'skin': '#c9c2b0', 'arms': '#2a2a33', 'cloth': '#141418', 'legs': '#0e0e12', 'thin': True,
            'hat': 'crown', 'hatColor': '#c8a45a', 'cape': '#0a0a0e', 'pads': '#2a2a33', 'weapon': 'greatsword',
            'bladeColor': '#8fd8ff', 'hilt': '#c8a45a', 'eyeGlow': '#8fd8ff', 'scale': 2.2},
      dust='#8fd8ff')
