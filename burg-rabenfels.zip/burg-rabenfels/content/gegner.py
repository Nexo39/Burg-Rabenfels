"""Gegnerarten.

Feste Gegner (lvl=...) stehen in den Zonen einer Karte. Gegner mit scale=True wachsen mit der
Ebene und gehören in ein Verlies: Ihre Werte gelten für Stufe 1.
"""
from game.registry import enemy

# ------------------------------------------------------- Burg und Umland
enemy('rat', 'Kellerratte', lvl=1, hp=34, dmg=3, speed=4.2, radius=0.45, aggro=5.5, range=1.3, cd=1.2,
      xp=10, gold=(1, 3), respawn=14,
      look={'body': 'beast', 'fur': '#75675b', 'dark': '#5c5048', 'ear': '#d39a9a', 'tail': '#d39a9a', 'scale': 0.85},
      dust='#8a7a6a')
enemy('goblin', 'Goblin', lvl=3, hp=62, dmg=7, speed=4.6, radius=0.5, aggro=9.0, range=1.5, cd=1.3,
      xp=26, gold=(3, 7), respawn=13,
      look={'skin': '#6f9a3c', 'cloth': '#6a4e30', 'legs': '#4a3a28', 'arms': '#6f9a3c', 'ears': '#6f9a3c',
            'weapon': 'club', 'eyeGlow': '#ffe14a', 'scale': 0.88},
      dust='#7fae45')
enemy('wolf', 'Schattenwolf', lvl=4, hp=84, dmg=9, speed=6.0, radius=0.6, aggro=8.0, range=1.5, cd=1.1,
      xp=38, gold=(2, 6), respawn=16,
      look={'body': 'beast', 'fur': '#3b4250', 'dark': '#2c323d', 'eyeGlow': '#ffd23a', 'bushy': True, 'scale': 1.35},
      dust='#4a5262')
enemy('skeleton', 'Skelettkrieger', lvl=5, hp=112, dmg=11, speed=3.8, radius=0.5, aggro=7.5, range=1.6, cd=1.4,
      xp=52, gold=(5, 11), respawn=15, look='skeleton')
# Der Knochenfürst ruft bei halbem Leben Gruftdiener, die nicht von selbst wiederkommen.
enemy('boss', 'Knochenfürst Morwen', lvl=8, hp=3400, dmg=24, speed=3.5, radius=1.1, aggro=12.0, range=2.4, cd=1.7,
      xp=500, gold=(60, 90), respawn=90, boss=True, summon='minion', moves=['slam', 'cone'],
      look={'skin': '#e9e2cf', 'cloth': '#3a2a52', 'legs': '#cfc6ae', 'arms': '#cfc6ae', 'thin': True, 'hat': 'crown',
            'cape': '#2a1a40', 'weapon': 'greatsword', 'eyeGlow': '#6ff0ff', 'pads': '#5a4a7a', 'hilt': '#5a4a7a',
            'scale': 2.0},
      dust='#b38cff')
enemy('minion', 'Gruftdiener', lvl=5, hp=60, dmg=8, speed=4.0, radius=0.5, aggro=12.0, range=1.6, cd=1.4,
      xp=12, gold=(1, 3), respawn=0,
      look={'skin': '#b9c4b0', 'cloth': '#8f9a88', 'legs': '#a3ae9c', 'arms': '#a3ae9c', 'thin': True,
            'weapon': 'club', 'eyeGlow': '#6ff0ff', 'scale': 0.92})

# ------------------------------------------- Katakomben (wachsen mit der Ebene)
enemy('knochen', 'Knochenkrieger', scale=True, hp=70, dmg=9, speed=4.2, radius=0.5, aggro=60.0, range=1.6, cd=1.4,
      xp=2.0, gold=(2, 4), look='skeleton')
enemy('aasratte', 'Aasratte', scale=True, hp=32, dmg=5, speed=5.6, radius=0.45, aggro=60.0, range=1.3, cd=1.0,
      xp=1.2, gold=(1, 2),
      look={'body': 'beast', 'fur': '#4f5a48', 'dark': '#3a4336', 'ear': '#8a6a6a', 'tail': '#8a6a6a',
            'eyeGlow': '#c8ff5a', 'scale': 1.0},
      dust='#6a7a5a')
# shot: verschießt Geschosse, bleibt also auf Abstand
enemy('knochenmagier', 'Knochenmagier', scale=True, hp=48, dmg=10, speed=3.6, radius=0.5, aggro=60.0, range=11.0,
      cd=2.4, xp=2.4, gold=(2, 5), shot=10.0,
      look={'skin': '#e4dcc6', 'cloth': '#3a2a52', 'robe': '#2f2244', 'arms': '#d8d0ba', 'thin': True, 'hat': 'wizard',
            'hatColor': '#2f2244', 'weapon': 'staff', 'orb': '#b38cff', 'eyeGlow': '#b38cff', 'scale': 1.05},
      dust='#b38cff')
enemy('geist', 'Klagegeist', scale=True, hp=52, dmg=8, speed=5.3, radius=0.5, aggro=60.0, range=1.5, cd=1.2,
      xp=2.2, gold=(2, 4),
      look={'skin': '#cfe6f2', 'cloth': '#9fc4d8', 'robe': '#8fb6cc', 'arms': '#b7d6e6', 'thin': True,
            'eyeGlow': '#ffffff', 'opacity': 0.55, 'scale': 1.1})
enemy('waechter', 'Gruftwächter', scale=True, hp=170, dmg=15, speed=3.2, radius=0.8, aggro=60.0, range=2.0, cd=1.9,
      xp=4.0, gold=(4, 8),
      look={'skin': '#8d8f96', 'cloth': '#3f434c', 'legs': '#30333a', 'arms': '#555a64', 'hat': 'helmet',
            'hatColor': '#30333a', 'pads': '#555a64', 'weapon': 'hammer', 'shield': '#30333a', 'eyeGlow': '#ff5a3a',
            'scale': 1.5})
enemy('gruftlord', 'Gruftlord', scale=True, hp=620, dmg=14, speed=3.6, radius=1.1, aggro=60.0, range=2.4, cd=1.7,
      xp=27.0, gold=(25, 40), boss=True, summon='aasratte', moves=['slam', 'rain', 'nova'],
      look={'skin': '#e9e2cf', 'cloth': '#5a1f24', 'legs': '#cfc6ae', 'arms': '#cfc6ae', 'thin': True, 'hat': 'crown',
            'cape': '#3a1216', 'weapon': 'greatsword', 'eyeGlow': '#ff6a4a', 'pads': '#7a2a30', 'hilt': '#7a2a30',
            'bladeColor': '#c9a6a6', 'scale': 2.1},
      dust='#ff6a4a')
