"""Quests im Steinbruchtal bei Steinmetzin Hedda (Stufe 31–40)."""
from game.registry import pickup, quest

pickup('meissel', 'Heddas Werkzeug', form='kiste', color='#c8b48a')

quest('spaeher', title='Augen im Steinbruch', npc='steinbruchtal_hueter', type='kill', target='gnoll_spaeher', count=10,
      goal='Gnollspäher besiegen', where='Nördlicher Steinbruch und Westseite',
      xp=15000, gold=3000, minlvl=31,
      text='Die Späher der Gnolls melden jeden Schritt, den wir tun. Schalte zehn aus, '
           'dann sind die übrigen blind.',
      done='Gut. Jetzt sehen sie uns nicht mehr kommen.')

quest('werkzeug', title='Gestohlenes Werkzeug', npc='steinbruchtal_hueter', type='collect', target='meissel', count=6,
      goal='Heddas Werkzeug zurückholen', where='Überall im Steinbruchtal',
      xp=16000, gold=3200, potions=3, minlvl=32,
      text='Diese Gnolls haben meine Werkzeugkisten geplündert – Meißel, Keile, Hämmer. '
           'Sie liegen über das ganze Tal verstreut. Bring mir sechs Kisten.',
      done='Mein alter Meißel! Den hat schon meine Großmutter geführt. Ich danke dir.')

quest('gnollschamanen', title='Heulende Schamanen', npc='steinbruchtal_hueter', type='kill', target='gnoll_schamane',
      count=8, goal='Gnollschamanen besiegen', where='Südlicher Steinbruch',
      xp=17500, gold=3500, req='spaeher', minlvl=34,
      text='Die Schamanen heulen jede Nacht den Mond an, und am Morgen sind die Gnolls doppelt so wild. '
           'Acht von ihnen, bevor der nächste Vollmond kommt.',
      done='Das Heulen ist leiser. Graufang wird unruhig werden.')

quest('wachen', title='Die Leibwache', npc='steinbruchtal_hueter', type='kill', target='gnoll_wache', count=8,
      goal='Gnollwachen besiegen', where='Östliche Seite und südlicher Steinbruch',
      xp=19500, gold=3900, req='gnollschamanen', minlvl=37,
      text='Graufangs Leibwache steht zwischen dir und der Grube. Acht Wachen – dann ist er allein.',
      done='Er ist allein. Und das weiß er.')

quest('graufang', title='Feldherr Graufang', npc='steinbruchtal_hueter', type='kill', target='gnoll_feldherr', count=1,
      goal='Feldherr Graufang besiegen', where='Grube des Feldherrn in der Mitte des Tals',
      xp=26000, gold=5200, potions=3, weapon=1, req='wachen', minlvl=38,
      text='Graufang wartet in der Grube. Er ist alt, gerissen und stärker als alles, was du bisher gesehen hast. '
           'Geh nicht allein.',
      done='Das Tal gehört wieder den Steinmetzen! Im Nordosten führt ein alter Weg zu den Ruinen von Altrabenfels. '
           'Ritter Konrad hält dort Wache – er wird dich brauchen.')

quest('talwacht', title='Talwacht', npc='steinbruchtal_hueter', type='kill', target='map:steinbruchtal', count=20,
      goal='Gnolls im Tal besiegen', where='Steinbruchtal',
      xp_pct=0.22, gold_lvl=18, req='spaeher', minlvl=31, repeat=True,
      text='Die Gnolls kommen immer wieder. Zwanzig, und ich bezahle nach deinem Können.',
      done='Das Tal ist ruhig – bis morgen.')
