"""Quests im dunklen Wald bei Waldläuferin Irma – von den Orklagern bis zu ihrem Häuptling."""
from game.registry import pickup, quest

pickup('trommel', 'Kriegstrommel', form='kiste', color='#b5523a')

quest('kriegspfad', title='Auf dem Kriegspfad', npc='dunkler_wald_hueter', type='kill', target='ork_krieger', count=10,
      goal='Orkkrieger besiegen', where='Lager der Krieger im Nordwesten des Waldes',
      xp=1700, gold=300, req='goblins', minlvl=6,
      text='Die Orks sammeln sich. Jede Nacht höre ich mehr Stimmen zwischen den Bäumen. '
           'Fang bei ihren Kriegern an – zehn weniger, und sie überlegen es sich zweimal.',
      done='Gut gekämpft. Aber Orks zählen nicht, sie brüllen nur lauter.')

quest('trommeln', title='Schweigende Trommeln', npc='dunkler_wald_hueter', type='collect', target='trommel', count=5,
      goal='Kriegstrommeln erbeuten', where='In allen vier Orklagern',
      xp=1900, gold=320, potions=2, req='kriegspfad', minlvl=7,
      text='Mit ihren Trommeln rufen die Orks einander zusammen. In jedem Lager steht mindestens eine. '
           'Bring mir fünf – ohne Trommeln kein Angriff.',
      done='Hörst du das? Nichts. Zum ersten Mal seit Wochen. Nimm die Tränke, du wirst sie brauchen.')

quest('schamanen', title='Grüner Rauch', npc='dunkler_wald_hueter', type='kill', target='ork_schamane', count=6,
      goal='Orkschamanen besiegen', where='Lager der Schamanen im Südwesten',
      xp=2100, gold=360, req='trommeln', minlvl=8,
      text='Die Schamanen brauen einen Rauch, der ihre Krieger rasend macht. Er zieht schon bis zur Burg. '
           'Bring sechs von ihnen zum Schweigen, bevor der ganze Wald nach Galle riecht.',
      done='Der Rauch lichtet sich. Jetzt bleibt nur noch einer, der sie zusammenhält.')

quest('berserker', title='Rasende Klingen', npc='dunkler_wald_hueter', type='kill', target='ork_berserker', count=6,
      goal='Orkberserker besiegen', where='Lager der Berserker im Südosten',
      xp=2300, gold=400, req='schamanen', minlvl=9,
      text='Die Berserker bewachen den Pfad zur Lichtung ihres Häuptlings. Sechs von ihnen musst du fällen, '
           'sonst fallen sie dir in den Rücken, wenn du ihn angreifst.',
      done='Der Weg zur Lichtung ist frei. Ruh dich aus – du wirst alle Kraft brauchen.')

quest('grukmar', title='Häuptling Grukmar', npc='dunkler_wald_hueter', type='kill', target='ork_haeuptling', count=1,
      goal='Häuptling Grukmar besiegen', where='Lichtung im Südwesten des Waldes',
      xp=3500, gold=700, potions=3, weapon=1, req='berserker', minlvl=10,
      text='Grukmar sitzt auf seiner Lichtung und wartet. Wenn er fällt, zerstreuen sich die Lager. '
           'Allein ist das kaum zu schaffen – nimm Gefährten mit. Hinter der Lichtung führt ein Pfad ins Moor.',
      done='Grukmar ist gefallen! Die Orks werden sich so bald nicht wieder sammeln. '
           'Der Pfad ins Moor steht dir offen – frag dort nach Kräuterfrau Wilma.')

quest('waldwacht', title='Waldwacht', npc='dunkler_wald_hueter', type='kill', target='map:dunkler_wald', count=15,
      goal='Orks im Wald besiegen', where='Dunkler Wald',
      xp_pct=0.2, gold_lvl=10, req='kriegspfad', minlvl=6, repeat=True,
      text='Die Orks kommen immer wieder. Fünfzehn von ihnen, und ich bezahle dich nach deinem Können. '
           'So oft du willst.',
      done='Der Wald dankt dir – und ich auch.')
