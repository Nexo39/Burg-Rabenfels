"""Quests der Burg, in der Reihenfolge, in der Helden sie erleben.

Die Reihenfolge der Anmeldung bestimmt auch, welche offene Quest die Anzeige als Nächstes empfiehlt.
"""
from game.registry import quest

quest('ratten', title='Rattenplage', npc='gerold', type='kill', target='rat', count=6,
      goal='Kellerratten erschlagen', where='Vorratskeller, durch die Küche im Westflügel',
      xp=80, gold=15,
      text='Im Vorratskeller wimmelt es von Ratten – groß wie Katzen und frech wie Goblins. '
           'Geh durch die Küche im Westflügel hinunter und erschlage sechs davon.',
      done='Sauber erledigt. Die Köchin wird wieder ruhig schlafen.')

quest('vorraete', title='Gestohlene Vorräte', npc='marthe', type='collect', target='supply', count=5,
      goal='Vorratskisten zurückholen', where='Goblinlager südlich der Zugbrücke',
      xp=140, gold=25, potions=2, req='ratten',
      text='Die Goblins vor dem Tor haben unsere Vorratskisten geklaut! Ihr Lager liegt südlich '
           'der Zugbrücke. Bring mir fünf Kisten zurück, sonst gibt es im Winter nur Rübensuppe.',
      done='Alles noch drin! Dafür bekommst du zwei Fläschchen von meinem Kräftigungstrank.')

quest('goblins', title='Goblins vor dem Tor', npc='gerold', type='kill', target='goblin', count=8,
      goal='Goblins besiegen', where='Goblinlager südlich der Zugbrücke',
      xp=200, gold=40, req='ratten',
      text='Die Goblins werden dreister. Zieh über die Brücke nach Süden und dünne ihr Lager aus – '
           'acht sollten reichen, um ihnen Respekt beizubringen.',
      done='Das wird sie eine Weile fernhalten. Rabenfels steht in deiner Schuld. Wenn du mehr Arbeit suchst: '
           'Waldläuferin Irma hält südlich des Lagers im dunklen Wald Wache – sie könnte jede Klinge brauchen.')

quest('kombo', title='Zusammenspiel', npc='adelheid', type='combo', target='any', count=10,
      goal='Kombos auslösen', where='Überall – die Übersicht steht im Fähigkeitenfenster (K)',
      xp=300, gold=60, req='ratten', minlvl=2,
      text='Manche Angriffe hinterlassen Spuren: Brand, Frost, Blut, ein Mal. Trifft danach der '
           'richtige zweite Schlag, entlädt sich beides in einer Kombo – am besten im Zusammenspiel '
           'mit Gefährten. Zeig mir zehn davon.',
      done='So kämpft man auf Rabenfels: nicht jeder für sich, sondern miteinander.')

quest('erz', title='Erz für die Esse', npc='bruna', type='collect', target='ore', count=4,
      goal='Rabeneisen sammeln', where='Wälder westlich und östlich des Burggrabens',
      xp=260, gold=50, weapon=1, req='goblins',
      text='Meine Esse glüht, aber das Erz ist alle. In den Wäldern westlich und östlich des '
           'Burggrabens liegen Brocken von Rabeneisen. Bring mir vier – und hüte dich vor den Schattenwölfen.',
      done='Gutes Eisen. Gib mir deine Waffe – die erste Schmiedestufe geht aufs Haus.')

quest('tote', title='Unruhige Tote', npc='anselm', type='kill', target='skeleton', count=8,
      goal='Skelettkrieger erlösen', where='Friedhof hinter der Kapelle',
      xp=380, gold=70, req='goblins', minlvl=3,
      text='Auf dem Friedhof hinter der Kapelle finden die Toten keine Ruhe. Erlöse acht '
           'Skelettkrieger, damit ich die Gräber neu weihen kann.',
      done='Mögen sie nun schlafen. Doch ich fürchte, das war erst der Anfang.')

quest('fuerst', title='Der Knochenfürst', npc='anselm', type='kill', target='boss', count=1,
      goal='Knochenfürst Morwen besiegen', where='Gruft am Südende des Friedhofs',
      xp=1000, gold=200, potions=3, req='tote', minlvl=5,
      text='Die Unruhe hat eine Quelle: In der Gruft am Südende des Friedhofs ist Knochenfürst '
           'Morwen erwacht. Allein wirst du ihn kaum bezwingen – sammle Gefährten und beende seinen Fluch.',
      done='Der Fluch ist gebrochen! Doch unter der Kapelle rührt sich noch Älteres.')

# Wiederholbar: Die Schatzkammer zahlt jedes Mal.
quest('wache', title='Wachdienst', npc='adelheid', type='kill', target='any', count=12,
      goal='Feinde der Burg besiegen', where='Überall rund um Rabenfels',
      xp=150, gold=30, req='ratten', repeat=True,
      text='Rabenfels braucht wachsame Klingen. Erschlage zwölf Feinde der Burg – gleich welcher '
           'Art – und die Schatzkammer zeigt sich erkenntlich. Diesen Dienst kannst du immer wieder antreten.',
      done='Die Burg dankt dir. Der Dienst steht dir jederzeit wieder offen.')
