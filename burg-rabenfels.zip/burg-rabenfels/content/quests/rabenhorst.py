"""Quests in den Ruinen von Altrabenfels bei Ritter Konrad (Stufe 41–50)."""
from game.registry import pickup, quest

pickup('siegel', 'Rabensiegel', form='brocken', color='#c8a45a')

quest('dunkelritter', title='Ritter ohne Herz', npc='konrad', type='kill', target='dunkelritter', count=12,
      goal='Dunkelritter besiegen', where='Vorhöfe der Ruinen',
      xp=24000, gold=4800, minlvl=41,
      text='Die Dunkelritter waren einmal Rabenfelser wie wir. Der König hat ihnen Herz und Namen genommen. '
           'Gib zwölf von ihnen ihren Frieden.',
      done='Zwölf. Ich habe einige von ihnen gekannt.')

quest('siegel', title='Die Rabensiegel', npc='konrad', type='collect', target='siegel', count=6,
      goal='Rabensiegel bergen', where='Überall in den Ruinen',
      xp=25000, gold=5000, potions=3, minlvl=42,
      text='Die Siegel der alten Familien liegen verstreut in den Trümmern. Mit ihnen können wir beweisen, '
           'dass Altrabenfels nie dem König gehört hat. Bring mir sechs.',
      done='Das Siegel der Rabenfelser selbst ist dabei! Adelheid wird Tränen in den Augen haben.')

quest('hunde', title='Die Meute', npc='konrad', type='kill', target='hoellenhund', count=10,
      goal='Höllenhunde erlegen', where='Westlicher und östlicher Vorhof',
      xp=26500, gold=5300, req='dunkelritter', minlvl=44,
      text='Seine Hunde riechen uns schon, bevor wir das Lager verlassen. Erlege zehn, '
           'dann können wir uns wieder bewegen.',
      done='Endlich Ruhe in der Nacht.')

quest('todesmagier', title='Stimmen der Toten', npc='konrad', type='kill', target='todesmagier', count=8,
      goal='Todesmagier besiegen', where='Innerer Hof',
      xp=28000, gold=5600, req='hunde', minlvl=45,
      text='Im inneren Hof halten Todesmagier die Ritter am Leben – wenn man das Leben nennt. '
           'Acht von ihnen müssen fallen.',
      done='Die Ritter wanken. Ihr König spürt es.')

quest('waechter', title='Steinerne Wache', npc='konrad', type='kill', target='steinwaechter', count=6,
      goal='Steinerne Wächter zerschlagen', where='Innerer Hof',
      xp=29500, gold=5900, req='todesmagier', minlvl=47,
      text='Vor dem Thronsaal stehen die Steinernen Wächter. Sie bewegen sich nur, wenn jemand vorbei will. '
           'Zerschlag sechs.',
      done='Der Weg zum Thronsaal ist offen.')

quest('rabenkoenig', title='Der Rabenkönig', npc='konrad', type='kill', target='rabenkoenig', count=1,
      goal='Den Rabenkönig besiegen', where='Thronsaal im Norden der Ruinen',
      xp=40000, gold=8000, potions=5, weapon=2, req='waechter', minlvl=48,
      text='Er sitzt auf dem Thron der ersten Rabenfelser und wartet. Sammle die stärksten Gefährten, '
           'die du finden kannst. Das ist der Kampf, für den diese Wacht gegründet wurde.',
      done='Der Thron ist leer. Altrabenfels ist frei. Dein Name wird in beiden Burgen gesungen werden – '
           'und doch: Kaspian sagt, unter den Katakomben rührt sich noch etwas.')

quest('ruinenwacht', title='Rabenwacht', npc='konrad', type='kill', target='map:rabenhorst', count=20,
      goal='Diener des Königs besiegen', where='Ruinen von Altrabenfels',
      xp_pct=0.22, gold_lvl=20, req='dunkelritter', minlvl=41, repeat=True,
      text='Der König schickt immer neue Diener. Zwanzig, und die Wacht zahlt dich aus.',
      done='Die Rabenwacht dankt dir.')
