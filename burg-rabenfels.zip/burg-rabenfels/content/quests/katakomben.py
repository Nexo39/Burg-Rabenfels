"""Quests rund um die Katakomben.

type='depth' zählt die tiefste geschaffte Ebene eines Verlieses (target = Karte mit Verlies).
"""
from game.registry import quest

quest('abstieg', title='Hinab in die Katakomben', npc='anselm', type='depth', target='katakomben', count=3,
      goal='Ebene der Katakomben schaffen', where='Treppe hinter dem Altar der Kapelle',
      xp=1500, gold=250, req='fuerst', minlvl=6,
      text='Hinter dem Altar führt eine Treppe in die Katakomben. Niemand weiß, wie tief sie reichen – '
           'mit jeder Ebene werden die Toten stärker. Steig hinab und räume die ersten drei Ebenen.',
      done='Du bist zurück! Totenwächter Kaspian in der Vorhalle wird dir weiter den Weg weisen.')

quest('tiefe10', title='Die zehnte Ebene', npc='kaspian', type='depth', target='katakomben', count=10,
      goal='Ebene der Katakomben schaffen', where='Halle der Gebeine',
      xp=6000, gold=600, req='abstieg', minlvl=8,
      text='Auf jeder fünften Ebene wacht ein Gruftlord. Den ersten hast du vielleicht schon gesehen. '
           'Bezwinge auch den zweiten und kehre von Ebene zehn zurück.',
      done='Zehn Ebenen. Die meisten kommen nicht einmal halb so weit.')

quest('tiefe25', title='Wo kein Licht mehr hinfällt', npc='kaspian', type='depth', target='katakomben', count=25,
      goal='Ebene der Katakomben schaffen', where='Halle der Gebeine',
      xp=40000, gold=2500, req='tiefe10', minlvl=15,
      text='Unterhalb der zwanzigsten Ebene brennen selbst meine Kerzen nicht mehr. Schaffe Ebene 25.',
      done='Du hast gesehen, was ich nur aus Büchern kenne.')

quest('tiefe50', title='Das Herz der Katakomben', npc='kaspian', type='depth', target='katakomben', count=50,
      goal='Ebene der Katakomben schaffen', where='Halle der Gebeine',
      xp=250000, gold=10000, req='tiefe25', minlvl=30,
      text='Ebene 50. Dort unten soll liegen, was die Toten weckt. Ich kann dich nicht begleiten – nur warten.',
      done='Ein Held von Rabenfels, wie es keinen zweiten gibt. Und doch: Es geht noch tiefer.')

# Wiederholbar. Die Belohnung wächst mit der Stufe: ein Viertel einer Stufe und 12 Gold je Stufe.
quest('ernte', title='Knochenernte', npc='kaspian', type='kill', target='map:katakomben', count=30,
      goal='Tote in den Katakomben erlösen', where='Halle der Gebeine',
      xp_pct=0.25, gold_lvl=12, minlvl=6, repeat=True,
      text='Jeder erlöste Tote ist einer weniger, der nach oben drängt. Erlöse dreißig – '
           'ich entlohne dich nach deinem Können, so oft du willst.',
      done='Gut. Es werden nicht weniger, aber sie werden auch nicht mehr.')
