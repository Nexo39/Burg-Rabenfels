"""Quests im Moor bei Kräuterfrau Wilma (Stufe 11–20)."""
from game.registry import pickup, quest

pickup('moorkraut', 'Moorkraut', form='brocken', color='#7bc74d')

quest('schuppen', title='Schuppen und Zähne', npc='wilma', type='kill', target='sumpfechse', count=10,
      goal='Sumpfechsen erlegen', where='Echsenufer im Westen des Moors',
      xp=2900, gold=560, minlvl=11,
      text='Die Sumpfechsen trauen sich bis an meinen Steg. Gestern haben sie mir eine Ziege geholt. '
           'Zehn von ihnen, und sie lernen wieder, wo ihr Ufer endet.',
      done='Meine Ziegen danken dir. Na ja, die, die noch da sind.')

quest('kraeuter', title='Bitteres Kraut', npc='wilma', type='collect', target='moorkraut', count=6,
      goal='Moorkraut sammeln', where='Ufer des Moors, rund um den Irrlichtsee',
      xp=3200, gold=640, potions=3, minlvl=12,
      text='Aus Moorkraut braue ich die einzigen Tränke, die gegen das Gift der Echsen helfen. '
           'Es wächst an den Ufern. Bring mir sechs Büschel – und lass dich von den Irrlichtern nicht locken.',
      done='Wunderbar, schön bitter. Drei Fläschchen für dich, frisch gebraut.')

quest('irrlichter', title='Falsche Lichter', npc='wilma', type='kill', target='irrlicht', count=8,
      goal='Irrlichter löschen', where='Irrlichtsee in der Mitte des Moors',
      xp=3700, gold=740, req='schuppen', minlvl=13,
      text='Die Lichter über dem See sind keine Seelen, wie die Leute sagen. Die Hexe schickt sie, '
           'um Wanderer ins Wasser zu locken. Lösch acht davon.',
      done='Der See ist dunkler geworden. Gut so – ehrliche Dunkelheit ist mir lieber als falsches Licht.')

quest('echsendorf', title='Das Echsendorf', npc='wilma', type='kill', target='echsenschamane', count=6,
      goal='Echsenschamanen besiegen', where='Echsendorf im Osten des Moors',
      xp=5100, gold=1020, req='irrlichter', minlvl=15,
      text='Im Osten haben die Echsen ein Dorf gebaut. Ihre Schamanen beten zur Hexe und sie antwortet. '
           'Bring sechs von ihnen zum Schweigen.',
      done='Ohne ihre Schamanen sind die Echsen nur noch Echsen. Bleibt die Furt im Süden.')

quest('trollfurt', title='Die Trollfurt', npc='wilma', type='kill', target='sumpftroll', count=5,
      goal='Sumpftrolle besiegen', where='Trollfurt im Süden des Moors',
      xp=6200, gold=1240, req='echsendorf', minlvl=17,
      text='Die Furt im Süden ist der einzige Weg zur Zwergenmine – und zum Hain der Hexe. '
           'Fünf Trolle hausen dort. Zu zweit geht das besser, glaub mir.',
      done='Die Furt ist frei. Jetzt steht nur noch Mirra zwischen dem Moor und seinem Frieden.')

quest('mirra', title='Die Hexe im Hain', npc='wilma', type='kill', target='sumpfhexe', count=1,
      goal='Sumpfhexe Mirra besiegen', where='Hexenhain im Südwesten des Moors',
      xp=8500, gold=1700, potions=3, weapon=1, req='trollfurt', minlvl=18,
      text='Mirra war einmal meine Schülerin. Dann hat sie gelernt, dass das Moor mehr gibt, wenn man ihm '
           'etwas opfert. Beende es – im Hain hinter dem Baumring. Und nimm Gefährten mit.',
      done='Sie ist fort. Ich hätte es selbst tun sollen, vor vielen Jahren. Danke. '
           'Östlich der Furt liegt der Eingang zur Zwergenmine – Borin Grauhand wartet dort auf Hilfe.')

quest('moorwacht', title='Moorwacht', npc='wilma', type='kill', target='map:moor', count=20,
      goal='Kreaturen im Moor besiegen', where='Das Moor',
      xp_pct=0.22, gold_lvl=14, req='schuppen', minlvl=11, repeat=True,
      text='Das Moor bringt immer neue Kreaturen hervor. Zwanzig davon, und ich zahle nach deinem Können.',
      done='Das Moor ist für heute etwas stiller.')
