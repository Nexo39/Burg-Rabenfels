"""Quests in der Zwergenmine Grauhall bei Borin Grauhand (Stufe 21–30)."""
from game.registry import pickup, quest

pickup('glutkristall', 'Glutkristall', form='brocken', color='#ff9a3a')

quest('kobolde', title='Ungeziefer in den Stollen', npc='borin', type='kill', target='kobold', count=12,
      goal='Kobolde vertreiben', where='Koboldstollen im Nordosten der Mine',
      xp=8000, gold=1600, minlvl=21,
      text='Kobolde! In meiner Mine! Sie kratzen das Silber aus den Wänden und lachen dabei. '
           'Zwölf von ihnen, und der Rest wird es sich merken.',
      done='Ha! Das Lachen ist ihnen vergangen. Grauhall atmet wieder ein bisschen.')

quest('glut', title='Glut für die Esse', npc='borin', type='collect', target='glutkristall', count=6,
      goal='Glutkristalle bergen', where='Koboldstollen und Golemschmiede',
      xp=9000, gold=1800, weapon=1, minlvl=22,
      text='Ohne Glutkristalle bleibt meine Esse kalt. Die Kobolde horten sie in den Stollen, '
           'und in der alten Schmiede liegen noch welche. Sechs genügen.',
      done='Sie glühen noch! Gib her deine Waffe – das ist Zwergenarbeit, wie sie sein soll.')

quest('kriecher', title='Was in den Gruben haust', npc='borin', type='kill', target='grubenkriecher', count=10,
      goal='Grubenkriecher erlegen', where='Grubengänge südlich der Eingangshalle',
      xp=9800, gold=1960, req='kobolde', minlvl=23,
      text='In den tiefen Gruben ist etwas mit roten Augen. Viele roten Augen. Wir haben es Grubenkriecher genannt, '
           'bevor wir weggelaufen sind. Erlege zehn.',
      done='Zehn weniger. Ich zähle trotzdem noch Augen, wenn ich schlafe.')

quest('ahnen', title='Ruhelose Ahnen', npc='borin', type='kill', target='zwergengeist', count=8,
      goal='Ahnengeister erlösen', where='Halle der Ahnen in der Mitte der Mine',
      xp=11500, gold=2300, req='kriecher', minlvl=25,
      text='In der Halle der Ahnen gehen meine Vorfahren um. Das Eiserne Herz hält sie wach. '
           'Erlöse acht von ihnen – mit Respekt, wenn es geht.',
      done='Mögen sie in den Hallen aus Stein ruhen. Aber solange das Herz schlägt, kommen sie wieder.')

quest('golems', title='Die Golemschmiede', npc='borin', type='kill', target='steingolem', count=6,
      goal='Steingolems zerschlagen', where='Golemschmiede im Südosten der Mine',
      xp=13000, gold=2600, req='ahnen', minlvl=27,
      text='Wir haben die Golems gebaut, um die Mine zu schützen. Jetzt schützen sie das Herz vor uns. '
           'Zerschlag sechs von ihnen.',
      done='Gute Arbeit, schlechte Erinnerungen. Jetzt bleibt nur noch die Glutkammer.')

quest('herz', title='Das Eiserne Herz', npc='borin', type='kill', target='glutherz', count=1,
      goal='Glutherz besiegen', where='Glutkammer im Süden der Mine',
      xp=17000, gold=3400, potions=3, weapon=1, req='golems', minlvl=28,
      text='Glutherz war der mächtigste Wächter, den wir je geschmiedet haben. Dann haben wir zu tief gegraben, '
           'und etwas hat sich in ihm eingenistet. Zerbrich sein Herz. Allein schaffst du das nicht.',
      done='Es ist still in der Glutkammer. Zum ersten Mal seit Jahren hört Grauhall nur noch seine eigenen Hämmer. '
           'Wenn du Stärkeres suchst: Im Steinbruchtal westlich der Burg wartet Steinmetzin Hedda.')

quest('grubenwacht', title='Grubenwacht', npc='borin', type='kill', target='map:zwergenmine', count=20,
      goal='Feinde in der Mine besiegen', where='Zwergenmine Grauhall',
      xp_pct=0.22, gold_lvl=16, req='kobolde', minlvl=21, repeat=True,
      text='Grauhall gibt seine Feinde nicht so leicht auf. Zwanzig, und ich zahle in gutem Zwergengold.',
      done='Gutes Gold für gute Arbeit.')
