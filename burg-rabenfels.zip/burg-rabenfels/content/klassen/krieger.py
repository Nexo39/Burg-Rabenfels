"""Krieger: steht vorn und hält stand."""
from game.registry import active, passive, player_class

C = 'krieger'
player_class(
    C, name='Krieger', color='#ea7d66',
    desc='Steht vorn und hält stand. Viel Leben, schwere Rüstung, breite Schwerthiebe.',
    hp=150, hp_lvl=18, dmg=15, armor=0.25, main='str', res='ausdauer',
    atk={'name': 'Schwerthieb', 'type': 'melee', 'cd': 0.55, 'range': 2.7, 'arc': 2.0, 'tag': 'schnitt'},
    look={'cloth': '#8f2f28', 'legs': '#4a4038', 'arms': '#9aa1a8', 'hat': 'helmet', 'weapon': 'sword',
          'shield': '#6f757d', 'pads': '#9aa1a8', 'scale': 1.12},
    branches=[('Waffenmeister', 'Klingenkunst und Blutungen'),
              ('Bollwerk', 'Schutz, Kontrolle und Wucht'),
              ('Berserker', 'Ansturm und rohe Gewalt')],
    start='wirbel',
)

# --- Waffenmeister: Klingenkunst und Blutungen
active('wirbel', C, 0, 1, 'Wirbelschlag', 'nova', 'schnitt', 20, 6, 'Ein Rundumhieb trifft alle Gegner um dich.', r=3.6, mult=1.6)
active('aderschnitt', C, 0, 3, 'Aderschnitt', 'arc', 'schnitt', 15, 5, 'Ein tiefer Schnitt, der die Getroffenen bluten lässt.',
        range=3.0, arc=2.2, mult=1.4, apply='blutend')
passive('p_klinge', C, 0, 6, 'Scharfe Klinge', 'dmg_schnitt', 0.04, 'Schnittschaden +{v} %.')
active('ausfall', C, 0, 8, 'Ausfall', 'dash', 'schnitt', 20, 8, 'Du schnellst vor und schlitzt alles am Ziel auf.', dist=6.0, r=3.0, mult=1.8)
active('doppelhieb', C, 0, 14, 'Doppelhieb', 'arc', 'schnitt', 18, 5, 'Zwei schnelle Hiebe hintereinander.', range=3.0, arc=2.0, mult=1.25, hits=2)
passive('p_wunden', C, 0, 16, 'Tiefe Wunden', 'dot_blutend', 0.15, 'Blutungen richten {v} % mehr Schaden an.')
active('klingentanz', C, 0, 22, 'Klingentanz', 'zone', 'schnitt', 30, 12, 'Zweieinhalb Sekunden lang wirbelt deine Klinge um dich.',
        r=3.4, dur=2.4, tick=0.4, mult=0.55, follow=True)
passive('p_praezision', C, 0, 26, 'Präzision', 'crit', 0.02, 'Chance auf kritische Treffer +{v} %.')
active('henker', C, 0, 32, 'Henkersstreich', 'arc', 'schnitt', 30, 10, 'Ein gewaltiger Hieb. Trifft Gegner unter einem Drittel Leben um die Hälfte härter.',
        range=3.2, arc=1.8, mult=3.2, execute=True)
active('tausend', C, 0, 45, 'Tausend Schnitte', 'arc', 'schnitt', 40, 16, 'Sechs blitzschnelle Hiebe, jeder lässt die Gegner bluten.',
        range=3.0, arc=2.2, mult=0.7, hits=6, apply='blutend')
# --- Bollwerk: Schutz, Kontrolle und Wucht
active('schildstoss', C, 1, 2, 'Schildstoß', 'arc', 'wucht', 15, 7, 'Ein Stoß mit dem Schild: betäubt kurz und bringt Gegner ins Wanken.',
        range=2.6, arc=1.6, mult=1.2, apply='wankend', stun=1.0)
passive('p_haut', C, 1, 4, 'Dicke Haut', 'hp_pct', 0.04, 'Maximales Leben +{v} %.')
active('schrei', C, 1, 5, 'Kriegsschrei', 'buff', 'hilfe', 25, 18, 'Du und Gefährten in der Nähe teilen 8 Sekunden lang mehr Schaden aus.',
        r=9.0, dur=8.0, mods={'dmg': 0.3})
active('spott', C, 1, 10, 'Herausforderung', 'buff', 'hilfe', 15, 12, 'Gegner im Umkreis greifen dich an; 6 Sekunden lang hältst du mehr aus.',
        dur=6.0, mods={'armor': 0.3}, taunt=8.0)
passive('p_unbeugsam', C, 1, 14, 'Unbeugsam', 'dr', 0.03, 'Erlittener Schaden −{v} %.')
active('erdstoss', C, 1, 16, 'Erdstoß', 'nova', 'wucht', 25, 9, 'Du rammst die Waffe in den Boden: Gegner ringsum wanken und werden langsam.',
        r=4.8, mult=1.5, apply='wankend', slow=3.0)
active('schildwall', C, 1, 24, 'Schildwall', 'buff', 'hilfe', 25, 20, 'Ein Schild fängt 8 Sekunden lang Schaden in Höhe von 30 % deines Lebens ab.',
        dur=8.0, absorb=0.3)
passive('p_standhaft', C, 1, 28, 'Standhaft', 'res_regen_pct', 0.08, 'Ausdauer erholt sich {v} % schneller.')
active('banner', C, 1, 34, 'Schutzbanner', 'zone', 'hilfe', 35, 30, 'Ein Banner schützt 10 Sekunden lang alle Gefährten in seinem Kreis und heilt sie.',
        r=6.0, dur=10.0, tick=1.0, mult=0, at_self=True, ally={'armor': 0.25, 'regen': 0.02})
active('erdspalter', C, 1, 48, 'Erdspalter', 'shot', 'wucht', 35, 14, 'Eine Schockwelle rast durch die Reihen und bringt alle Getroffenen ins Wanken.',
        speed=14.0, range=14.0, size=1.2, mult=2.6, pierce=True, apply='wankend', kind='welle')
# --- Berserker: Ansturm und rohe Gewalt
active('sturm', C, 2, 4, 'Sturmangriff', 'dash', 'wucht', 20, 9, 'Du stürmst los und rammst die Gegner am Ziel – sie sind kurz betäubt.',
        dist=8.0, r=2.6, mult=1.5, stun=0.8)
passive('p_blutdurst', C, 2, 8, 'Blutdurst', 'kill_heal', 0.01, 'Jeder besiegte Gegner heilt dich um {v} % deines Lebens.')
active('blutrausch', C, 2, 12, 'Blutrausch', 'buff', 'hilfe', 20, 20, '8 Sekunden lang schlägst du deutlich schneller und härter zu.',
        dur=8.0, mods={'haste': 0.4, 'dmg': 0.15})
active('einschuechtern', C, 2, 18, 'Einschüchtern', 'nova', None, 20, 16, 'Dein Brüllen lässt Gegner wanken; 6 Sekunden lang schlagen sie schwächer zu.',
        r=6.0, mult=0, apply='wankend', weaken=6.0)
passive('p_kampfrausch', C, 2, 20, 'Kampfrausch', 'haste', 0.03, 'Angriffstempo +{v} %.')
active('sprung', C, 2, 28, 'Wilder Sprung', 'dash', 'wucht', 30, 12, 'Du springst an die Stelle des Mauszeigers und schlägst dort ein.',
        dist=9.0, leap=True, r=3.6, mult=2.2)
passive('p_schlaechter', C, 2, 34, 'Schlächter', 'combo', 0.10, 'Kombos richten {v} % mehr Zusatzschaden an.')
active('raserei', C, 2, 40, 'Raserei', 'buff', 'hilfe', 30, 30, '10 Sekunden lang mehr Schaden, und jeder Treffer heilt dich.',
        dur=10.0, mods={'dmg': 0.25, 'lifesteal': 0.12})
active('weltenbrecher', C, 2, 60, 'Weltenbrecher', 'blast', 'wucht', 50, 40, 'Nach kurzem Ausholen erschüttert ein Schlag die ganze Umgebung und betäubt.',
        r=6.5, delay=0.7, mult=4.5, stun=1.5, at_self=True)
