"""Paladin: Hammer, Licht und Schutz für die Gefährten."""
from game.registry import active, passive, player_class

C = 'paladin'
player_class(
    C, name='Paladin', color='#ffe08a',
    desc='Kämpft mit Hammer und heiligem Licht. Blendet Gegner, heilt Gefährten und hält mitten im Getümmel stand.',
    hp=135, hp_lvl=15, dmg=14, armor=0.2, main='str', res='ausdauer',
    atk={'name': 'Hammerschlag', 'type': 'melee', 'cd': 0.6, 'range': 2.6, 'arc': 1.8, 'tag': 'wucht'},
    look={'cloth': '#e8dcb0', 'legs': '#6a6050', 'arms': '#c8ccd0', 'hat': 'helmet', 'hatColor': '#c8ccd0',
          'plume': '#ffe9a8', 'weapon': 'hammer', 'shield': '#c8a45a', 'pads': '#c8a45a', 'cape': '#f2e6c0',
          'scale': 1.12},
    branches=[('Richter', 'Heiliges Licht, das blendet und straft'),
              ('Bewahrer', 'Heilung, Schilde und Auren für die Gefährten'),
              ('Kreuzritter', 'Hammer, Ansturm und Wucht')],
    start='paladin_lichtschlag',
)

# --- Richter: Licht und Blenden
active('paladin_lichtschlag', C, 0, 1, 'Lichtschlag', 'arc', 'licht', 15, 5,
       'Ein heiliger Hieb, der alle Gegner vor dir blendet.', range=3.0, arc=2.0, mult=1.5, apply='geblendet')
active('paladin_strahl', C, 0, 3, 'Lichtstrahl', 'shot', 'licht', 15, 4,
       'Ein Lichtstrahl durchbohrt alle Gegner in einer Linie.',
       speed=22.0, range=14.0, mult=1.3, pierce=True, kind='arkan', color='#ffe9a8')
passive('paladin_p_licht', C, 0, 6, 'Inbrunst', 'dmg_licht', 0.04, 'Lichtschaden +{v} %.')
active('paladin_urteil', C, 0, 8, 'Urteil', 'blast', 'licht', 25, 8,
       'Nach kurzer Verzögerung fährt ein Lichtstrahl am Mauszeiger herab und blendet alle Getroffenen.',
       r=3.5, delay=0.6, range=14.0, falling=True, mult=2.0, apply='geblendet')
active('paladin_kette', C, 0, 14, 'Heilige Kette', 'chain', 'licht', 25, 9,
       'Ein Lichtbogen springt von Gegner zu Gegner, bis zu fünf Ziele.', range=12.0, jump=6.0, n=5, mult=1.6)
passive('paladin_p_status', C, 0, 16, 'Strenges Licht', 'status_dur', 0.08, 'Zustände, die du verursachst, halten {v} % länger.')
active('paladin_weihe', C, 0, 22, 'Geweihter Boden', 'zone', 'licht', 30, 14,
       'Der Boden am Mauszeiger leuchtet 6 Sekunden lang, versengt Gegner darin und blendet sie.',
       r=4.0, dur=6.0, tick=1.0, mult=0.45, range=14.0, apply='geblendet')
passive('paladin_p_krit', C, 0, 26, 'Klarer Blick', 'crit', 0.02, 'Chance auf kritische Treffer +{v} %.')
active('paladin_sonnenschlag', C, 0, 32, 'Sonnenschlag', 'nova', 'licht', 35, 12,
       'Ein Lichtring um dich: hoher Schaden, alle Getroffenen sind geblendet und kurz betäubt.',
       r=5.0, mult=3.0, apply='geblendet', stun=0.8)
active('paladin_zorn', C, 0, 45, 'Zorn des Himmels', 'blast', 'licht', 55, 40,
       'Ein gewaltiger Lichtsturm fährt am Mauszeiger herab und blendet alle Getroffenen.',
       r=6.5, delay=0.9, range=14.0, falling=True, mult=5.0, apply='geblendet')

# --- Bewahrer: Heilung und Schutz
active('paladin_handauflegen', C, 1, 2, 'Handauflegen', 'heal', 'hilfe', 25, 12,
       'Heilt dich und Gefährten in der Nähe um 25 % ihres Lebens.', r=8.0, pct=0.25)
passive('paladin_p_glaube', C, 1, 4, 'Gottvertrauen', 'hp_pct', 0.04, 'Maximales Leben +{v} %.')
active('paladin_segen', C, 1, 5, 'Segen', 'buff', 'hilfe', 25, 20,
       'Du und Gefährten in der Nähe haltet 10 Sekunden lang mehr aus und erholt euch dabei.',
       r=9.0, dur=10.0, mods={'armor': 0.2, 'regen': 0.01})
active('paladin_schutz', C, 1, 10, 'Göttlicher Schutz', 'buff', 'hilfe', 25, 20,
       'Ein Schild fängt 8 Sekunden lang Schaden in Höhe von 35 % deines Lebens ab.', dur=8.0, absorb=0.35)
passive('paladin_p_heil', C, 1, 14, 'Gnade', 'heal_pct', 0.06, 'Heilung wirkt {v} % stärker.')
active('paladin_aura', C, 1, 16, 'Aura der Hingabe', 'zone', 'hilfe', 35, 30,
       'Eine Aura folgt dir 10 Sekunden lang: Gefährten darin halten mehr aus und werden geheilt.',
       r=6.0, dur=10.0, tick=1.0, mult=0, follow=True, ally={'armor': 0.2, 'heal': 0.02})
active('paladin_bann', C, 1, 24, 'Bannkreis', 'nova', None, 20, 16,
       'Ein Bannkreis blendet alle Gegner um dich; 6 Sekunden lang schlagen sie schwächer zu.',
       r=6.0, mult=0, apply='geblendet', weaken=6.0)
passive('paladin_p_andacht', C, 1, 28, 'Andacht', 'res_regen_pct', 0.08, 'Ausdauer erholt sich {v} % schneller.')
active('paladin_herausforderung', C, 1, 34, 'Herausforderung', 'buff', 'hilfe', 20, 14,
       'Gegner im Umkreis greifen dich an; 8 Sekunden lang hältst du deutlich mehr aus.',
       dur=8.0, mods={'armor': 0.35}, taunt=9.0)
active('paladin_wunder', C, 1, 50, 'Wunder', 'heal', 'hilfe', 50, 60,
       'Heilt dich und alle Gefährten in weitem Umkreis um 80 % ihres Lebens.', r=14.0, pct=0.8)

# --- Kreuzritter: Hammer und Ansturm
active('paladin_ansturm', C, 2, 4, 'Heiliger Ansturm', 'dash', 'wucht', 20, 9,
       'Du stürmst los und rammst die Gegner am Ziel – sie sind kurz betäubt.', dist=8.0, r=2.6, mult=1.5, stun=0.6)
passive('paladin_p_hammer', C, 2, 8, 'Schwerer Hammer', 'dmg_wucht', 0.04, 'Wuchtschaden +{v} %.')
active('paladin_hammerwurf', C, 2, 12, 'Hammerwurf', 'shot', 'wucht', 20, 7,
       'Ein geworfener Hammer trifft hart und bringt das Ziel ins Wanken.',
       speed=18.0, range=12.0, mult=2.0, apply='wankend', size=0.5, kind='welle')
active('paladin_eifer', C, 2, 18, 'Glaubenseifer', 'buff', 'hilfe', 25, 20,
       '10 Sekunden lang schlägst du schneller zu, und jeder Treffer heilt dich ein wenig.',
       dur=10.0, mods={'haste': 0.3, 'lifesteal': 0.08})
passive('paladin_p_fels', C, 2, 20, 'Unerschütterlich', 'dr', 0.03, 'Erlittener Schaden −{v} %.')
active('paladin_weihestoss', C, 2, 28, 'Weihestoß', 'arc', 'wucht', 30, 10,
       'Zwei schwere Hammerschläge vor dir; jeder bringt die Getroffenen ins Wanken.',
       range=3.0, arc=1.8, mult=1.6, hits=2, apply='wankend')
passive('paladin_p_gerecht', C, 2, 34, 'Gerechtigkeit', 'combo', 0.10, 'Kombos richten {v} % mehr Zusatzschaden an.')
active('paladin_himmelssturz', C, 2, 40, 'Himmelssturz', 'dash', 'licht', 35, 14,
       'Du springst an die Stelle des Mauszeigers, schlägst dort mit Licht ein und blendest alles ringsum.',
       dist=9.0, leap=True, r=3.6, mult=2.6, apply='geblendet')
active('paladin_gotteshammer', C, 2, 60, 'Gotteshammer', 'blast', 'wucht', 55, 40,
       'Nach kurzem Ausholen lässt dein Hammer die Erde beben: gewaltiger Schaden und Betäubung um dich.',
       r=6.5, delay=0.7, mult=4.8, stun=1.5, at_self=True)
