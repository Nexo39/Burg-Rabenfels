"""Waldläufer: schnell und treffsicher."""
from game.registry import active, passive, player_class

C = 'waldlaeufer'
player_class(
    C, name='Waldläufer', color='#94c96c',
    desc='Schnell und treffsicher. Pfeile, Gift und Fallen – und Heilkräuter für die Gruppe.',
    hp=105, hp_lvl=12, dmg=12, armor=0.08, main='ges', res='ausdauer',
    atk={'name': 'Pfeilschuss', 'type': 'shot', 'kind': 'arrow', 'cd': 0.45, 'range': 17.0, 'speed': 26.0,
         'splash': 0.0, 'tag': 'stich'},
    look={'cloth': '#4f7a35', 'legs': '#5a4630', 'arms': '#3f6a2c', 'hat': 'hood', 'hatColor': '#3f6a2c',
          'bow': True, 'cape': '#35532a', 'scale': 1.1},
    branches=[('Scharfschütze', 'Präzise Schüsse und Markierungen'),
              ('Wildnis', 'Gift, Fallen und Heilung'),
              ('Schattenläufer', 'Ausweichen und Hinterhalt')],
    start='faecher',
)

# --- Scharfschütze
active('faecher', C, 0, 1, 'Fächerschuss', 'shot', 'stich', 20, 6, 'Fünf Pfeile in einem breiten Fächer.',
        speed=26.0, range=17.0, mult=0.85, count=5, spread=0.16, kind='arrow')
active('jaegermal', C, 0, 2, 'Jägermal', 'shot', 'stich', 10, 4, 'Ein Pfeil, der sein Ziel markiert: Es erleidet mehr Schaden.',
        speed=30.0, range=18.0, mult=0.6, apply='markiert', kind='arrow')
passive('p_adler', C, 0, 5, 'Adlerauge', 'crit', 0.02, 'Chance auf kritische Treffer +{v} %.')
active('gezielt', C, 0, 6, 'Gezielter Schuss', 'shot', 'stich', 25, 8, 'Ein sorgfältig gezielter, sehr harter Schuss.',
        speed=34.0, range=20.0, mult=2.8, kind='arrow')
active('durchschuss', C, 0, 12, 'Durchschuss', 'shot', 'stich', 20, 6, 'Dieser Pfeil durchschlägt alle Gegner in einer Linie.',
        speed=28.0, range=18.0, mult=1.8, pierce=True, size=0.5, kind='arrow')
passive('p_toedlich', C, 0, 16, 'Tödliche Präzision', 'crit_dmg', 0.10, 'Kritische Treffer richten {v} % mehr Schaden an.')
active('schnellfeuer', C, 0, 18, 'Schnellfeuer', 'buff', 'hilfe', 25, 20, '6 Sekunden lang schießt du um die Hälfte schneller.', dur=6.0, mods={'haste': 0.5})
active('pfeilhagel', C, 0, 26, 'Pfeilhagel', 'zone', 'stich', 35, 14, '4 Sekunden lang regnen Pfeile auf die Stelle am Mauszeiger.',
        range=14.0, r=4.5, dur=4.0, tick=0.4, mult=0.5)
passive('p_durchschlag', C, 0, 30, 'Durchschlagskraft', 'dmg_stich', 0.04, 'Stichschaden +{v} %.')
active('todesschuss', C, 0, 50, 'Todesschuss', 'shot', 'stich', 50, 30, 'Ein einziger, vernichtender Pfeil, der alles in seiner Bahn durchschlägt.',
        speed=38.0, range=22.0, mult=5.5, pierce=True, size=0.5, kind='arrow')
# --- Wildnis: Gift, Fallen und Heilung
active('giftpfeil', C, 1, 3, 'Giftpfeil', 'shot', 'gift', 15, 5, 'Ein Pfeil, der sein Ziel vergiftet.',
        speed=26.0, range=17.0, mult=1.0, apply='vergiftet', kind='poison')
active('kraeuter', C, 1, 5, 'Heilkräuter', 'heal', 'hilfe', 30, 16, 'Heilt dich und Gefährten in der Nähe um 35 % ihres Lebens.', r=8.0, pct=0.35)
passive('p_giftmischer', C, 1, 7, 'Giftmischer', 'dot_vergiftet', 0.15, 'Gifte richten {v} % mehr Schaden an.')
active('fangeisen', C, 1, 9, 'Fangeisen', 'zone', 'stich', 20, 12, 'Eine Falle am Mauszeiger: Wer hineintritt, blutet und wird langsam.',
        range=10.0, r=2.4, dur=10.0, tick=0.5, mult=0.5, apply='blutend', slow=1.0, slow_f=0.5)
passive('p_natur', C, 1, 12, 'Naturverbunden', 'heal_pct', 0.08, 'Deine Heilungen wirken {v} % stärker.')
active('giftwolke', C, 1, 15, 'Giftwolke', 'zone', 'gift', 28, 14, 'Eine Giftwolke am Mauszeiger vergiftet 6 Sekunden lang alles darin.',
        range=13.0, r=4.0, dur=6.0, tick=0.6, mult=0.35, apply='vergiftet')
passive('p_zaeh', C, 1, 20, 'Zähigkeit', 'hp_pct', 0.04, 'Maximales Leben +{v} %.')
active('ruf', C, 1, 22, 'Ruf der Wildnis', 'buff', 'hilfe', 25, 22, 'Du und Gefährten in der Nähe lauft 8 Sekunden schneller und erholt euch.',
        r=9.0, dur=8.0, mods={'speed': 0.2, 'regen': 0.03})
active('ranken', C, 1, 31, 'Dornenranken', 'blast', 'gift', 30, 16, 'Ranken am Mauszeiger halten Gegner 2 Sekunden fest und vergiften sie.',
        range=12.0, r=4.0, delay=0.5, mult=1.2, stun=2.0, apply='vergiftet')
active('hain', C, 1, 44, 'Hain des Lebens', 'zone', 'hilfe', 40, 30, 'Ein heilender Kreis um dich, 8 Sekunden lang.',
        r=5.0, dur=8.0, tick=1.0, mult=0, at_self=True, ally={'heal': 0.05})
# --- Schattenläufer: Beweglichkeit und Hinterhalt
active('rolle', C, 2, 4, 'Ausweichrolle', 'dash', None, 12, 5, 'Eine schnelle Rolle in Zielrichtung.', dist=6.0)
passive('p_leichtfuss', C, 2, 6, 'Leichtfüßig', 'speed', 0.02, 'Lauftempo +{v} %.')
active('rauchbombe', C, 2, 10, 'Rauchbombe', 'nova', None, 20, 16, 'Gegner um dich sind 1,5 Sekunden benommen und lassen von dir ab.',
        r=5.0, mult=0, stun=1.5, fade=True, color='#9aa1a8')
active('klingenfaecher', C, 2, 14, 'Klingenfächer', 'nova', 'schnitt', 20, 7, 'Wurfklingen in alle Richtungen lassen Gegner bluten.', r=3.6, mult=1.4, apply='blutend')
passive('p_ausdauernd', C, 2, 16, 'Ausdauernd', 'res_regen_pct', 0.08, 'Ausdauer erholt sich {v} % schneller.')
active('schattenschritt', C, 2, 24, 'Schattenschritt', 'dash', None, 20, 12, 'Du huschst weit in Zielrichtung; 4 Sekunden lang triffst du viel öfter kritisch.',
        dist=9.0, mods={'crit': 0.5}, dur=4.0)
passive('p_jagd', C, 2, 28, 'Jagdinstinkt', 'combo', 0.10, 'Kombos richten {v} % mehr Zusatzschaden an.')
active('sperrfeuer', C, 2, 34, 'Sperrfeuer', 'shot', 'stich', 35, 12, 'Neun Pfeile in dichter Folge.',
        speed=28.0, range=17.0, mult=0.7, count=9, spread=0.1, kind='arrow')
active('pfeilsturm', C, 2, 58, 'Pfeilsturm', 'nova', 'stich', 55, 40, 'Pfeile in alle Richtungen: hoher Schaden, alle Getroffenen sind markiert.',
        r=7.5, mult=3.2, apply='markiert')
