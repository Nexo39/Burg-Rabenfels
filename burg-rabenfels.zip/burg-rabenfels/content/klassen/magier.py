"""Magier: zerbrechlich, aber verheerend."""
from game.registry import active, passive, player_class

C = 'magier'
player_class(
    C, name='Magier', color='#b0a4f7',
    desc='Zerbrechlich, aber verheerend. Feuer, Frost und Blitz aus sicherer Entfernung.',
    hp=85, hp_lvl=9, dmg=18, armor=0.0, main='int', res='mana',
    atk={'name': 'Feuerball', 'type': 'shot', 'kind': 'fire', 'cd': 0.75, 'range': 15.0, 'speed': 17.0,
         'splash': 1.8, 'tag': 'feuer'},
    look={'cloth': '#4b3f9e', 'robe': '#3d3384', 'hat': 'wizard', 'hatColor': '#3d3384', 'weapon': 'staff',
          'orb': '#9fdcff', 'scale': 1.1},
    branches=[('Feuer', 'Brände und große Einschläge'),
              ('Frost', 'Gefrieren, Betäuben, Schutz'),
              ('Sturm', 'Blitze, Arkanes, Beweglichkeit')],
    start='nova',
)

# --- Feuer
active('feuerlanze', C, 0, 2, 'Feuerlanze', 'shot', 'feuer', 18, 5, 'Ein Flammenspeer durchbohrt alle Gegner in einer Linie und setzt sie in Brand.',
        speed=20.0, range=15.0, mult=1.7, pierce=True, apply='brennend', kind='fire')
passive('p_brand', C, 0, 5, 'Brandstifter', 'dot_brennend', 0.15, 'Brände richten {v} % mehr Schaden an.')
active('flammenwelle', C, 0, 6, 'Flammenwelle', 'arc', 'feuer', 22, 7, 'Ein Feuerkegel vor dir setzt Gegner in Brand.', range=6.0, arc=1.6, mult=1.4, apply='brennend')
active('meteor', C, 0, 12, 'Meteor', 'blast', 'feuer', 35, 14, 'Schlägt nach kurzer Verzögerung am Mauszeiger ein.',
        range=13.0, r=3.6, delay=0.9, mult=3.2, apply='brennend', falling=True)
passive('p_glut', C, 0, 16, 'Glutherz', 'dmg_feuer', 0.04, 'Feuerschaden +{v} %.')
active('feuerwand', C, 0, 18, 'Feuerfeld', 'zone', 'feuer', 30, 14, 'Der Boden am Mauszeiger brennt 6 Sekunden lang.',
        range=12.0, r=3.0, dur=6.0, tick=0.5, mult=0.5, apply='brennend')
active('pyro', C, 0, 26, 'Pyroschlag', 'shot', 'feuer', 35, 10, 'Eine schwere Feuerkugel, die beim Aufprall weit um sich greift.',
        speed=13.0, range=16.0, mult=3.0, splash=3.0, size=0.5, kind='fire')
passive('p_zunder', C, 0, 30, 'Zunder', 'crit', 0.02, 'Chance auf kritische Treffer +{v} %.')
active('flammenaura', C, 0, 36, 'Flammenmantel', 'zone', 'feuer', 35, 20, '8 Sekunden lang verbrennt ein Flammenkreis alles um dich.',
        r=3.6, dur=8.0, tick=0.8, mult=0.6, apply='brennend', follow=True)
active('inferno', C, 0, 55, 'Inferno', 'blast', 'feuer', 60, 45, 'Ein riesiger Feuersturm am Mauszeiger.',
        range=13.0, r=7.0, delay=1.2, mult=5.0, apply='brennend', falling=True)
# --- Frost
active('nova', C, 1, 1, 'Frostnova', 'nova', 'frost', 20, 8, 'Ein Eisring um dich: Schaden, und alle Getroffenen gefrieren.', r=5.0, mult=1.0, apply='gefroren')
active('eislanze', C, 1, 3, 'Eislanze', 'shot', 'frost', 15, 4, 'Ein schneller Eissplitter, der sein Ziel gefrieren lässt.',
        speed=24.0, range=16.0, mult=1.6, apply='gefroren', kind='ice')
passive('p_kaelte', C, 1, 6, 'Eiseskälte', 'dmg_frost', 0.04, 'Frostschaden +{v} %.')
active('eisbarriere', C, 1, 9, 'Eisbarriere', 'buff', 'hilfe', 25, 20, 'Eine Eishülle fängt 8 Sekunden lang Schaden in Höhe von 35 % deines Lebens ab.',
        dur=8.0, absorb=0.35)
passive('p_frostpanzer', C, 1, 12, 'Frostpanzer', 'dr', 0.03, 'Erlittener Schaden −{v} %.')
active('blizzard', C, 1, 15, 'Blizzard', 'zone', 'frost', 35, 16, 'Ein Schneesturm am Mauszeiger: 6 Sekunden Schaden, alles darin gefriert.',
        range=13.0, r=4.5, dur=6.0, tick=0.6, mult=0.45, apply='gefroren')
active('gletscher', C, 1, 24, 'Gletscherdorn', 'blast', 'frost', 28, 10, 'Ein Eisdorn bricht am Mauszeiger aus dem Boden und betäubt.',
        range=12.0, r=2.6, delay=0.45, mult=2.6, stun=1.2, apply='gefroren')
passive('p_permafrost', C, 1, 28, 'Permafrost', 'status_dur', 0.10, 'Deine Zustände halten {v} % länger.')
active('frostgefaengnis', C, 1, 33, 'Frostgefängnis', 'blast', 'frost', 30, 18, 'Schließt alle Gegner am Mauszeiger für 2,5 Sekunden in Eis ein.',
        range=12.0, r=3.4, delay=0.3, mult=0.8, stun=2.5, apply='gefroren')
active('nullpunkt', C, 1, 50, 'Absoluter Nullpunkt', 'nova', 'frost', 60, 45, 'Eine gewaltige Kältewelle: hoher Schaden, 2 Sekunden Betäubung, alles gefriert.',
        r=8.0, mult=3.0, stun=2.0, apply='gefroren')
# --- Sturm: Blitz und Arkanes
active('blitz', C, 2, 4, 'Kettenblitz', 'chain', 'blitz', 18, 5, 'Ein Blitz springt über bis zu drei Gegner und schockt sie.',
        range=12.0, jump=6.0, n=3, mult=1.5, apply='geschockt')
passive('p_geist', C, 2, 7, 'Geistesstärke', 'res_max_pct', 0.08, 'Maximales Mana +{v} %.')
active('blinzeln', C, 2, 8, 'Blinzeln', 'dash', None, 15, 8, 'Du versetzt dich ein Stück in Zielrichtung.', dist=8.0)
active('geschosse', C, 2, 13, 'Arkane Geschosse', 'shot', 'arkan', 16, 4, 'Drei arkane Geschosse im schmalen Fächer.',
        speed=20.0, range=15.0, mult=0.9, count=3, spread=0.14, kind='arkan')
passive('p_meditation', C, 2, 17, 'Meditation', 'res_regen_pct', 0.08, 'Mana erholt sich {v} % schneller.')
active('gewitter', C, 2, 21, 'Gewitterfeld', 'zone', 'blitz', 32, 15, 'Blitze schlagen 5 Sekunden lang am Mauszeiger ein und schocken alles.',
        range=13.0, r=4.0, dur=5.0, tick=0.5, mult=0.5, apply='geschockt')
passive('p_elementarist', C, 2, 25, 'Elementarist', 'combo', 0.10, 'Kombos richten {v} % mehr Zusatzschaden an.')
active('klarheit', C, 2, 30, 'Geistesklarheit', 'buff', 'hilfe', 0, 40, 'Stellt über 6 Sekunden 60 % deines Manas wieder her.', dur=6.0, mods={'res_pct': 0.1})
active('zeitblase', C, 2, 42, 'Zeitblase', 'zone', None, 40, 30, 'In dieser Blase am Mauszeiger kommen Gegner 6 Sekunden lang kaum voran.',
        range=13.0, r=6.0, dur=6.0, tick=0.5, mult=0, slow=1.0, slow_f=0.3, color='#c58bff')
