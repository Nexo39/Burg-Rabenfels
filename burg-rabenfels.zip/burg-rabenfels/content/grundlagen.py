"""Grundlagen, auf die sich alle anderen Inhalte beziehen: Schadensarten, Zustände, Kombos,
Questgegenstände und Aussehen-Vorlagen."""
from game.registry import combo, look, pickup, status, tag

# ------------------------------------------------------------ Schadensarten
# 'hilfe' steht für Heilung, Schutz und Stärkung.
tag('schnitt', 'Schnitt', '#ece6d6')
tag('wucht', 'Wucht', '#d9b382')
tag('stich', 'Stich', '#f0cf73')
tag('feuer', 'Feuer', '#ff8a3a')
tag('frost', 'Frost', '#8fd8ff')
tag('blitz', 'Blitz', '#f4e04d')
tag('gift', 'Gift', '#7bc74d')
tag('arkan', 'Arkan', '#c58bff')
tag('hilfe', 'Unterstützung', '#8fe07a')

# ----------------------------------------------------------------- Zustände
# dot: Schaden je Sekunde als Anteil der Angriffskraft dessen, der den Zustand verursacht hat.
status('brennend', 'Brennend', '#ff8a3a', dur=5.0, dot=0.22, desc='Feuerschaden über Zeit.')
status('gefroren', 'Gefroren', '#8fd8ff', dur=4.0, slow=0.5, desc='Bewegt sich nur halb so schnell.')
status('geschockt', 'Geschockt', '#f4e04d', dur=5.0, weak=0.2, desc='Teilt 20 % weniger Schaden aus.')
status('blutend', 'Blutend', '#e0564a', dur=6.0, dot=0.18, desc='Blutungsschaden über Zeit.')
status('vergiftet', 'Vergiftet', '#7bc74d', dur=8.0, dot=0.14, desc='Giftschaden über Zeit.')
status('markiert', 'Markiert', '#ff7ab8', dur=8.0, vuln=0.10, desc='Erleidet 10 % mehr Schaden.')
status('wankend', 'Wankend', '#b9a6ff', dur=5.0, vuln=0.15, desc='Erleidet 15 % mehr Schaden.')

# ------------------------------------------------------------------- Kombos
# Zustand + Schadensart. Der Zustand wird verbraucht. Pro Treffer zündet höchstens eine Kombo:
# die erste passende in dieser Reihenfolge.
combo('zersplittern', 'Zersplittern', [('gefroren', 'wucht')], bonus=1.0,
      aoe={'r': 3.5, 'mult': 0.6, 'tag': 'frost'},
      desc='Doppelter Schaden. Eissplitter treffen alle Gegner im Umkreis.')
combo('thermoschock', 'Thermoschock', [('gefroren', 'feuer'), ('brennend', 'frost')], bonus=0.8, stun=1.5,
      desc='80 % mehr Schaden und 1,5 Sekunden Betäubung.')
combo('flaechenbrand', 'Flächenbrand', [('vergiftet', 'feuer'), ('brennend', 'gift')], bonus=0.6,
      aoe={'r': 4.0, 'mult': 0.8, 'tag': 'feuer', 'apply': 'brennend'},
      desc='60 % mehr Schaden. Eine Stichflamme setzt alle Gegner im Umkreis in Brand.')
combo('ausbrennen', 'Ausbrennen', [('blutend', 'feuer')], bonus=0.7, apply='brennend',
      desc='70 % mehr Schaden, das Ziel fängt Feuer.')
combo('ausbluten', 'Ausbluten', [('blutend', 'stich')], bonus=0.5, burst=2.0,
      desc='50 % mehr Schaden, dazu der restliche Blutungsschaden sofort und doppelt.')
combo('ueberladung', 'Überladung', [('geschockt', 'stich'), ('geschockt', 'schnitt')], bonus=0.5,
      chain={'n': 3, 'mult': 0.8, 'r': 7.0},
      desc='50 % mehr Schaden. Ein Kettenblitz springt auf bis zu drei weitere Gegner.')
combo('hinrichten', 'Hinrichten', [('wankend', 'schnitt')], bonus=0.9, execute=1.6,
      desc='90 % mehr Schaden – noch deutlich mehr gegen Gegner unter einem Drittel Leben.')
combo('volltreffer', 'Volltreffer', [('markiert', 'stich'), ('markiert', 'schnitt'), ('markiert', 'wucht')],
      bonus=0.5, crit=True, desc='Sicherer kritischer Treffer mit 50 % mehr Schaden.')

# --------------------------------------------------------- Questgegenstände
pickup('supply', 'Vorratskiste', form='kiste', color='#ffd76a')
pickup('ore', 'Rabeneisen', form='brocken', color='#8fd0ff')

# -------------------------------------------------------- Aussehen-Vorlagen
# Bewohner, Gegner und Klassen nennen entweder eine Vorlage beim Namen oder machen eigene Angaben.
look('captain', cloth='#2f4a7a', legs='#3a3a40', arms='#9aa1a8', hat='helmet', plume='#c23b30', weapon='sword',
     pads='#c8a45a', cape='#2f4a7a', scale=1.18)
look('cook', cloth='#b5653c', robe='#8e4d2c', hat='bonnet', apron='#efe6d2', weapon='club', scale=1.08)
look('smith', cloth='#6b4a32', legs='#3d3229', arms='#e2b48c', hat='hair', hair='#b5522a', apron='#3a2c20',
     weapon='hammer', scale=1.14)
look('priest', cloth='#e9e2cf', robe='#d8cfb6', hat='tonsure', hair='#6a4a2c', sash='#c8a45a', scale=1.1)
look('lady', cloth='#8f2338', robe='#7a1c30', hat='crown', hair='#2a1c12', cape='#5c1424', scale=1.1)
look('guardian', skin='#cfc8b8', cloth='#2f2a3c', robe='#262232', hat='hood', hatColor='#262232', weapon='staff',
     orb='#59ffc0', sash='#8d6fd0', scale=1.15)
look('skeleton', skin='#e4dcc6', cloth='#cfc6ae', legs='#d8d0ba', arms='#d8d0ba', thin=True, weapon='sword',
     bladeColor='#8a7a68', hilt='#5a4a3a', eye='#0d0b0a', shield='#5a4a3a', scale=1.05)
