#!/bin/sh
# Burg Rabenfels starten (Linux/macOS). Legt beim ersten Mal eine eigene Python-Umgebung an.
cd "$(dirname "$0")" || exit 1
if [ ! -x .venv/bin/python ]; then
    echo "Richte die Python-Umgebung ein ..."
    python3 -m venv .venv || exit 1
    .venv/bin/python -m pip install --quiet --upgrade pip
    .venv/bin/python -m pip install --quiet -r requirements.txt || exit 1
fi
exec .venv/bin/python app.py
