"""Burg Rabenfels – ein Top-Down-Fantasyspiel in 3D für mehrere Spieler.

Start:  python app.py      (danach im Browser http://localhost:5000 öffnen)

Flask liefert die Seite aus, Flask-SocketIO überträgt den Spielzustand in Echtzeit,
und Three.js zeichnet die Burg im Browser. Die Spiellogik liegt im Paket `game`,
die Inhalte (Klassen, Gegner, Quests, Karten) unter `content/`.
"""
import functools
import logging
import os
import socket
import threading
import time

from flask import Flask, render_template, request
from flask_socketio import SocketIO, join_room

import game
from game import registry
from game.engine import Game, TICK

BASE = os.path.dirname(os.path.abspath(__file__))
PORT = int(os.environ.get('PORT', 5000))
DEV = os.environ.get('RABENFELS_DEV') == '1'

app = Flask(__name__)
logging.getLogger('werkzeug').setLevel(logging.WARNING)   # nicht jede Anfrage in die Konsole schreiben
app.config['SEND_FILE_MAX_AGE_DEFAULT'] = 0          # Änderungen an JS/CSS sofort sichtbar
# Reihenfolge der Klassen, Quests und Fähigkeiten aus content/ beibehalten (statt alphabetisch zu sortieren)
app.json.sort_keys = False
app.jinja_env.policies['json.dumps_kwargs'] = {'sort_keys': False}
socketio = SocketIO(app, async_mode='threading', ping_interval=25, ping_timeout=60)


def emit(event, payload, to=None):
    socketio.emit(event, payload, to=to or 'game')


try:
    game.load()                                      # liest und prüft alles unter content/
except registry.ContentError as err:
    raise SystemExit(f'\n{err}\n\nBitte die genannten Stellen korrigieren (Hilfe: python tools/pruefen.py).\n')

for note in registry.NOTES:                          # kein Fehler, aber wahrscheinlich nicht so gemeint (z. B. Platzhalter)
    print('  Hinweis:', note)

world = Game(emit, os.path.join(BASE, 'saves', 'charaktere.json'), dev=DEV)

_loop_started = False
_loop_lock = threading.Lock()


def game_loop():
    last = time.time()
    while True:
        socketio.sleep(TICK)
        now = time.time()
        dt = min(now - last, 0.2)
        last = now
        try:
            world.tick(now, dt)
        except Exception as err:                     # ein Fehler darf die Welt nicht anhalten
            app.logger.exception('Fehler in der Spielschleife: %s', err)


def ensure_loop():
    global _loop_started
    with _loop_lock:
        if not _loop_started:
            _loop_started = True
            socketio.start_background_task(game_loop)


def handler(fn):
    """Nimmt nur Nachrichten in Form eines Objekts an und fängt Fehler einzelner Clients ab."""
    @functools.wraps(fn)
    def wrapper(payload=None):
        if not isinstance(payload, dict):
            payload = {}
        try:
            return fn(payload)
        except Exception as err:
            app.logger.exception('Fehler bei "%s": %s', fn.__name__, err)
    return wrapper


@app.route('/')
def index():
    return render_template('index.html', game_data=registry.client_data())


@socketio.on('connect')
def on_connect():
    ensure_loop()


@socketio.on('disconnect')
def on_disconnect(*_):
    world.leave(request.sid)


@socketio.on('join')
@handler
def on_join(d):
    result = world.join(request.sid, d.get('name'), d.get('cls'))
    if result.get('ok'):
        join_room('game')
    return result


@socketio.on('move')
@handler
def on_move(d):
    world.on_move(request.sid, d)


@socketio.on('attack')
@handler
def on_attack(d):
    world.on_attack(request.sid, d)


@socketio.on('skill')
@handler
def on_skill(d):
    return world.on_skill(request.sid, d)        # Antwort: ob die Fähigkeit gewirkt wurde und ihre Abklingzeit


@socketio.on('attr')
@handler
def on_attr(d):
    world.on_attr(request.sid, d)


@socketio.on('learn')
@handler
def on_learn(d):
    world.on_learn(request.sid, d)


@socketio.on('bind')
@handler
def on_bind(d):
    world.on_bind(request.sid, d)


@socketio.on('potion')
@handler
def on_potion(d):
    world.on_potion(request.sid)


@socketio.on('quest')
@handler
def on_quest(d):
    world.on_quest(request.sid, d)


@socketio.on('shop')
@handler
def on_shop(d):
    world.on_shop(request.sid, d)


@socketio.on('item')
@handler
def on_item(d):
    world.on_item(request.sid, d)


@socketio.on('chat')
@handler
def on_chat(d):
    world.on_chat(request.sid, d)


def lan_address():
    """Die Adresse dieses Rechners im Heimnetz – für Mitspieler."""
    try:
        with socket.socket(socket.AF_INET, socket.SOCK_DGRAM) as s:
            s.connect(('10.255.255.255', 1))
            return s.getsockname()[0]
    except OSError:
        return None


if __name__ == '__main__':
    ip = lan_address()
    print('\n  Burg Rabenfels öffnet ihre Tore.\n')
    print(f'  Auf diesem Rechner:   http://localhost:{PORT}')
    if ip:
        print(f'  Mitspieler im Netz:   http://{ip}:{PORT}')
    if DEV:
        print('  Entwicklermodus aktiv: /tp x z, /tp karte x z, /lvl n, /gold n, /tiefe n im Chat')
    print('\n  Beenden mit Strg+C\n')
    socketio.run(app, host='0.0.0.0', port=PORT, allow_unsafe_werkzeug=True)
