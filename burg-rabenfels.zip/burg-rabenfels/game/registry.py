"""Inhaltsverzeichnis des Spiels.

Die Dateien unter content/ rufen die Funktionen dieses Moduls auf und melden so alles an,
was es im Spiel gibt: Schadensarten, Zustände, Kombos, Klassen, Fähigkeiten, Gegner,
Questgegenstände, Quests und Karten. Engine und Browser lesen nur aus diesem Verzeichnis –
für neue Inhalte muss deshalb weder game/engine.py noch JavaScript angefasst werden.

Jede Anmeldung wird geprüft. Fehler werden gesammelt und beim Start gemeinsam gemeldet,
mit Datei und Ursache (siehe `python tools/pruefen.py`).
"""
import importlib.util
import os
import re
import traceback

from .data import BAG_MAX, ELITE_AFFIXES, ELIXIR_TIME, ELIXIRS, ITEM_SLOTS, ITEM_STATS, RARITIES
from .data import ATTRS, MAX_LEVEL, MAX_RANK, POTION_CD, POTION_MAX, GEAR_MAX, PLAYER_RADIUS, RANK_BONUS, RES_NAMES

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
CONTENT_DIR = os.path.join(ROOT, 'content')


class ContentError(Exception):
    """Die Inhalte unter content/ sind fehlerhaft. Die Meldung nennt jede Stelle."""


# ------------------------------------------------------------ Verzeichnisse
TAGS = {}        # Schadensarten
STATUS = {}      # Zustände auf Gegnern (Reihenfolge = Bit in der Momentaufnahme)
COMBOS = []      # Zustand + Schadensart
LOOKS = {}       # benannte Aussehen-Vorlagen
CLASSES = {}
SKILLS = {}
ENEMIES = {}
PICKUPS = {}     # aufsammelbare Questgegenstände
QUESTS = {}
MAPS = {}        # Karten, wie sie angemeldet wurden (world.py baut daraus die Welt)
PORTALS = []     # Übergänge, die außerhalb einer Karten-Anmeldung hinzugefügt wurden

ERRORS = []
NOTES = []       # Hinweise: kein Fehler, aber wahrscheinlich nicht so gemeint
_source = '?'    # Datei, die gerade geladen wird

# ------------------------------------------------------------- Vokabular
ID_RE = re.compile(r'^[a-z][a-z0-9_]*$')
COLOR_RE = re.compile(r'^#([0-9a-fA-F]{3}|[0-9a-fA-F]{6})$')

# Grundformen aktiver Fähigkeiten: Pflichtangaben und erlaubte Zusätze
HIT = {'mult', 'apply', 'stun', 'slow', 'slow_f', 'weaken', 'execute', 'color'}
FORMS = {
    'arc':   ({'range', 'arc'}, HIT | {'hits'}),
    'nova':  ({'r'}, HIT | {'fade'}),
    'shot':  ({'speed', 'range'}, HIT | {'count', 'spread', 'pierce', 'splash', 'size', 'kind'}),
    'blast': ({'r', 'delay'}, HIT | {'range', 'at_self', 'falling'}),
    'zone':  ({'r', 'dur', 'tick'}, HIT | {'range', 'at_self', 'follow', 'ally'}),
    'dash':  ({'dist'}, HIT | {'r', 'leap', 'mods', 'dur'}),
    'chain': ({'range', 'jump', 'n'}, HIT),
    'buff':  ({'dur'}, {'r', 'mods', 'absorb', 'taunt', 'color'}),
    'heal':  ({'r', 'pct'}, {'color'}),
}
NUM_PARAMS = {'range', 'arc', 'r', 'speed', 'dist', 'jump', 'n', 'delay', 'dur', 'tick', 'mult', 'stun', 'slow', 'slow_f',
              'weaken', 'hits', 'count', 'spread', 'splash', 'size', 'absorb', 'taunt', 'pct'}
FLAG_PARAMS = {'execute', 'fade', 'pierce', 'at_self', 'falling', 'follow', 'leap'}
BUFF_MODS = {'dmg', 'armor', 'haste', 'speed', 'crit', 'lifesteal', 'regen', 'res_pct'}
ALLY_MODS = {'armor', 'regen', 'heal'}
PASSIVE_STATS = {'hp_pct', 'res_max_pct', 'res_regen_pct', 'crit', 'crit_dmg', 'dr', 'speed', 'haste',
                 'heal_pct', 'combo', 'status_dur', 'kill_heal'}       # dazu dmg_<Schadensart> und dot_<Zustand>
SHOT_KINDS = {'fire', 'arrow', 'ice', 'arkan', 'poison', 'welle', 'dark'}
STYLES = {'klinge', 'magie', 'bogen'}
COMBO_EFFECTS = {'aoe', 'stun', 'apply', 'chain', 'burst', 'execute', 'crit'}
QUEST_TYPES = {'kill', 'collect', 'combo', 'depth'}
SERVICES = {'potion', 'weapon', 'armor', 'heal', 'respec', 'dungeon', 'elixir'}
# Sonderangriffe der Bosse (enemy(..., moves=[...])); ohne Angabe: nur 'slam'
BOSS_MOVES = {'slam', 'cone', 'charge', 'volley', 'nova', 'rain'}
# Hintergrundklänge einer Karte (game_map(..., ambient=...)); ohne Angabe nach dem Licht
AMBIENTS = {'wind', 'wald', 'sumpf', 'hoehle', 'gruft', 'ruine'}
PICKUP_FORMS = {'kiste', 'brocken'}
LIGHTS = {'tag', 'dunkel'}
DECO = {'torch', 'ghost', 'fire', 'banner'}

HUMAN_LOOK = {'body', 'skin', 'cloth', 'arms', 'legs', 'robe', 'thin', 'eye', 'eyeGlow', 'apron', 'sash', 'cape', 'pads',
              'ears', 'hat', 'hatColor', 'plume', 'hair', 'weapon', 'bladeColor', 'hilt', 'orb', 'bow', 'shield',
              'opacity', 'scale'}
BEAST_LOOK = {'body', 'fur', 'dark', 'ear', 'tail', 'eyeGlow', 'bushy', 'scale'}
LOOK_FLAGS = {'thin', 'bow', 'bushy'}
LOOK_NUMBERS = {'opacity', 'scale'}
HATS = {'helmet', 'wizard', 'hood', 'crown', 'bonnet', 'hair', 'tonsure'}
WEAPONS = {'sword', 'greatsword', 'staff', 'club', 'hammer'}


# ------------------------------------------------------------------ Hilfen
def _err(msg, src=None):
    ERRORS.append(f'{src or _source}: {msg}')


def _note(msg, src=None):
    NOTES.append(f'{src or _source}: {msg}')


def _new_id(kind, table, id):
    if not isinstance(id, str) or not ID_RE.match(id):
        _err(f"{kind} {id!r}: Kennungen bestehen aus Kleinbuchstaben, Ziffern und _ und beginnen mit einem Buchstaben.")
        return False
    if id in table:
        _err(f"{kind} '{id}' gibt es schon (angemeldet in {table[id].get('_src', '?')}).")
        return False
    return True


def _color(what, value):
    if not isinstance(value, str) or not COLOR_RE.match(value):
        _err(f"{what}: {value!r} ist keine Farbe. Erwartet wird '#rrggbb'.")


def _numbers(what, d, keys, src, positive=True):
    """Die genannten Angaben müssen Zahlen sein (True/False zählt nicht)."""
    for k in keys:
        v = d.get(k)
        if isinstance(v, bool) or not isinstance(v, (int, float)) or (positive and v <= 0) or v < 0:
            _err(f"{what}: {k} muss eine Zahl {'größer als 0' if positive else 'ab 0'} sein, angegeben ist {v!r}.", src)


def _keys(what, given, allowed, required=()):
    extra = sorted(set(given) - set(allowed))
    if extra:
        _err(f"{what}: unbekannte Angabe {', '.join(extra)}. Erlaubt: {', '.join(sorted(allowed))}.")
    missing = sorted(set(required) - set(given))
    if missing:
        _err(f"{what}: es fehlt {', '.join(missing)}.")
    return not extra and not missing


def reset():
    for table in (TAGS, STATUS, LOOKS, CLASSES, SKILLS, ENEMIES, PICKUPS, QUESTS, MAPS):
        table.clear()
    for lst in (COMBOS, PORTALS, ERRORS, NOTES):
        del lst[:]


# ============================================================ Anmeldung
def tag(id, name, color):
    """Schadensart. Kombos zünden über die Schadensart eines Treffers."""
    if _new_id('Schadensart', TAGS, id):
        _color(f"Schadensart '{id}'", color)
        TAGS[id] = {'name': name, 'color': color, '_src': _source}


def status(id, name, color, dur, desc, dot=0.0, slow=0.0, weak=0.0, vuln=0.0):
    """Zustand auf einem Gegner.

    dot:  Schaden je Sekunde als Anteil der Angriffskraft des Verursachers
    slow: Tempo-Faktor, solange der Zustand wirkt (0.5 = halb so schnell)
    weak: der Gegner teilt um diesen Anteil weniger Schaden aus
    vuln: der Gegner erleidet um diesen Anteil mehr Schaden
    """
    if _new_id('Zustand', STATUS, id):
        _color(f"Zustand '{id}'", color)
        if len(STATUS) >= 30:
            _err(f"Zustand '{id}': mehr als 30 Zustände werden nicht unterstützt.")
        s = {'name': name, 'dur': dur, 'color': color, 'desc': desc, '_src': _source}
        s.update({k: v for k, v in (('dot', dot), ('slow', slow), ('weak', weak), ('vuln', vuln)) if v})
        STATUS[id] = s


def combo(id, name, pairs, bonus, desc, **effects):
    """Kombo: Trifft die Schadensart auf den Zustand, wird er verbraucht und der Treffer verstärkt.

    pairs: [(Zustand, Schadensart), ...]   bonus: zusätzlicher Schaden (1.0 = doppelt)
    Zusatzwirkungen: stun=Sekunden, apply=Zustand, crit=True, burst=Faktor (Rest des Schadens über Zeit sofort),
    execute=Faktor auf den Bonus gegen Gegner unter 35 % Leben,
    aoe={'r', 'mult', 'tag', 'apply'?}, chain={'n', 'mult', 'r', 'tag'?}  (tag: Vorgabe 'blitz')
    """
    if any(c['id'] == id for c in COMBOS):
        return _err(f"Kombo '{id}' gibt es schon.")
    _keys(f"Kombo '{id}'", effects, COMBO_EFFECTS)
    COMBOS.append({'id': id, 'name': name, 'pairs': [tuple(p) for p in pairs], 'bonus': bonus, 'desc': desc,
                   '_src': _source, **effects})


def look(id, **options):
    """Benannte Aussehen-Vorlage, die Bewohner, Gegner und Klassen über ihren Namen verwenden können."""
    if _new_id('Aussehen', LOOKS, id):
        LOOKS[id] = {**options, '_src': _source}


def player_class(id, name, desc, color, hp, hp_lvl, dmg, armor, main, res, atk, look, branches, start, style=None):
    """Heldenklasse.

    main: Hauptattribut ('str', 'ges', 'int')        res: 'mana' oder 'ausdauer'
    atk:  Grundangriff, Nahkampf {'name', 'type': 'melee', 'cd', 'range', 'arc', 'tag'}
          oder Geschoss        {'name', 'type': 'shot', 'kind', 'cd', 'range', 'speed', 'splash', 'tag'}
    look: Aussehen (Vorlagenname oder Angaben)        branches: drei Zweige [(Name, Beschreibung), ...]
    start: Kennung der Fähigkeit, die jeder Held dieser Klasse von Anfang an beherrscht
    style: Bewegungsstil 'klinge', 'magie' oder 'bogen' (sonst aus dem Grundangriff abgeleitet)
    """
    if not _new_id('Klasse', CLASSES, id):
        return
    if style is None:
        style = 'klinge' if atk.get('type') == 'melee' else 'bogen' if atk.get('kind') == 'arrow' else 'magie'
    CLASSES[id] = {'name': name, 'desc': desc, 'color': color, 'hp': hp, 'hp_lvl': hp_lvl, 'dmg': dmg, 'armor': armor,
                   'main': main, 'res': res, 'atk': dict(atk), 'look': look, 'style': style,
                   'branches': [{'name': b[0], 'desc': b[1]} for b in branches], 'start': start, '_src': _source}


def active(id, cls, branch, lvl, name, form, tag, cost, cd, desc, **params):
    """Aktive Fähigkeit im Skilltree der Klasse `cls`, Zweig 0–2, lernbar ab Heldenstufe `lvl`.

    form bestimmt, wie sie wirkt (siehe FORMS), tag ist die Schadensart (None = keine),
    cost die Kosten an Mana/Ausdauer, cd die Abklingzeit in Sekunden.
    """
    if _new_id('Fähigkeit', SKILLS, id):
        SKILLS[id] = {'id': id, 'cls': cls, 'branch': branch, 'lvl': lvl, 'name': name, 'type': 'active',
                      'form': form, 'tag': tag, 'cost': cost, 'cd': cd, 'desc': desc, '_src': _source, **params}


def passive(id, cls, branch, lvl, name, stat, per, desc):
    """Passive Fähigkeit: erhöht `stat` je Stufe um `per`. In `desc` steht {v} für den Prozentwert."""
    if _new_id('Fähigkeit', SKILLS, id):
        SKILLS[id] = {'id': id, 'cls': cls, 'branch': branch, 'lvl': lvl, 'name': name, 'type': 'passive',
                      'stat': stat, 'per': per, 'desc': desc, '_src': _source}


def enemy(id, name, look, hp, dmg, speed, radius, aggro, range, cd, xp, gold, lvl=None, scale=False,
          respawn=15, boss=False, summon=None, shot=None, dust=None, moves=None):
    """Gegnerart.

    Feste Gegner haben `lvl` und feste Werte. Mit scale=True gelten die Werte für Stufe 1 und wachsen
    mit der Stufe (Verliese). aggro: Sichtweite, range: Angriffsreichweite, cd: Sekunden zwischen Angriffen,
    gold: (min, max), respawn: Sekunden bis zur Rückkehr, shot: Geschosstempo (macht ihn zum Fernkämpfer),
    boss: mit Sonderangriffen und – falls summon gesetzt ist – Dienern bei halbem Leben.
    moves: Sonderangriffe eines Bosses, der Reihe nach: 'slam' (Bodenschlag am Ziel), 'cone' (Kegel vor ihm),
           'charge' (Sturmangriff), 'volley' (Geschossfächer), 'nova' (Ring um ihn), 'rain' (Einschläge um alle Helden).
    """
    if _new_id('Gegner', ENEMIES, id):
        e = {'name': name, 'look': look, 'hp': hp, 'dmg': dmg, 'speed': speed, 'radius': radius, 'aggro': aggro,
             'range': range, 'cd': cd, 'xp': xp, 'gold': tuple(gold), 'respawn': respawn, '_src': _source}
        if scale:
            e['scale'] = True
        else:
            e['lvl'] = lvl
        e.update({k: v for k, v in (('boss', boss), ('summon', summon), ('shot', shot), ('dust', dust)) if v})
        if moves is not None:
            e['moves'] = list(moves)
        ENEMIES[id] = e


def pickup(id, name, form, color):
    """Questgegenstand zum Aufsammeln. form: 'kiste' oder 'brocken'."""
    if _new_id('Questgegenstand', PICKUPS, id):
        _color(f"Questgegenstand '{id}'", color)
        if form not in PICKUP_FORMS:
            _err(f"Questgegenstand '{id}': form {form!r} gibt es nicht. Erlaubt: {', '.join(sorted(PICKUP_FORMS))}.")
        PICKUPS[id] = {'name': name, 'form': form, 'color': color, '_src': _source}


def quest(id, title, npc, type, target, count, goal, where, text, done, xp=None, gold=None, xp_pct=None,
          gold_lvl=None, req=None, minlvl=1, repeat=False, potions=0, weapon=0):
    """Quest eines Bewohners.

    type 'kill':    target = Gegnerart, 'any' (beliebig) oder 'map:<Karte>' (alles auf dieser Karte)
    type 'collect': target = Questgegenstand
    type 'combo':   target = 'any'
    type 'depth':   target = Karte mit Verlies; count = Ebene, die geschafft sein muss
    goal: Kurzform für die Anzeige („Ratten erschlagen“), where: Ortsangabe, text: Auftrag, done: Dank.
    Belohnung fest (xp, gold) oder mit der Stufe wachsend (xp_pct = Anteil einer Stufe, gold_lvl = Gold je Stufe).
    req: Quest, die vorher abgeschlossen sein muss. repeat: beliebig oft annehmbar.
    """
    if _new_id('Quest', QUESTS, id):
        q = {'title': title, 'npc': npc, 'type': type, 'target': target, 'count': count, 'goal': goal, 'where': where,
             'text': text, 'done': done, 'req': req, 'minlvl': minlvl, '_src': _source}
        q.update({k: v for k, v in (('xp', xp), ('gold', gold), ('xp_pct', xp_pct), ('gold_lvl', gold_lvl),
                                    ('repeat', repeat), ('potions', potions), ('weapon', weapon)) if v})
        QUESTS[id] = q


def game_map(id, name, plan, start, light='tag', floor=',', legend=None, main=False, regions=(), zones=None,
             spawns=(), pickups=(), npcs=None, portals=None, deco=(), dungeon=None, ambient=None):
    """Karte. Alle Koordinaten sind Kacheln der eigenen Karte: (x, z) ab der linken oberen Ecke, Kommazahlen erlaubt.

    plan:    ASCII-Plan, ein Zeichen je Kachel, alle Zeilen gleich lang (Zeichen siehe world.py)
    start:   Ankunfts- und Wiederbelebungspunkt
    light:   'tag' oder 'dunkel'
    floor:   Untergrund unter Gegenständen, die keinen begehbaren Nachbarn haben
    legend:  eigene Zeichen {Zeichen: (Untergrund, Gegenstand)}
    main:    True für die Karte, auf der neue Helden beginnen (genau eine)
    regions: Ortsnamen [(Name, (x0, z0, x1, z1)), ...] – der erste Treffer gewinnt
    zones:   Gegnergebiete {Name: {'rect': (x0, z0, x1, z1), 'margin': Kacheln}}
    spawns:  [(Gegnerart, Zone, Anzahl), ...] oder mit festem Platz (Gegnerart, Zone, 1, (x, z))
    pickups: [(Questgegenstand, x, z), ...]
    npcs:    {Kennung: {'name', 'role', 'look', 'at': (x, z), 'greet', 'services': [...]}}
    portals: {Zeichen im Plan: {'to': Karte, 'target': (x, z)}} – Ziffern 1–9 im Plan sind Übergänge
    deco:    [(Art, x, z), ...] mit Art 'torch', 'ghost', 'fire' oder 'banner'
    dungeon: endloses Verlies {'zone', 'base_level', 'mix': [(Gegnerart, ab Ebene, Gewicht)], 'boss', 'boss_every'}
    ambient: Hintergrundklang 'wind', 'wald', 'sumpf', 'hoehle', 'gruft' oder 'ruine' (Vorgabe nach dem Licht)
    """
    if _new_id('Karte', MAPS, id):
        MAPS[id] = {'id': id, 'name': name, 'plan': plan, 'start': start, 'light': light, 'floor': floor,
                    'legend': dict(legend or {}), 'main': main, 'regions': list(regions), 'zones': dict(zones or {}),
                    'spawns': list(spawns), 'pickups': list(pickups), 'npcs': dict(npcs or {}),
                    'portals': dict(portals or {}), 'deco': list(deco), 'dungeon': dungeon,
                    'ambient': ambient or ('wind' if light == 'tag' else 'hoehle'), '_src': _source}
        if MAPS[id]['ambient'] not in AMBIENTS:
            _err(f"Karte '{id}': ambient {ambient!r} gibt es nicht. Erlaubt: {', '.join(sorted(AMBIENTS))}.")


def portal(map, at, to, target=None):
    """Übergang auf einer bestehenden Karte: Wer die Kachel `at` betritt, kommt auf Karte `to` bei `target` an.

    So kann die Datei einer neuen Karte ihren Eingang auf einer alten Karte selbst anlegen.
    Ohne target kommt man am Startpunkt der Zielkarte an.
    """
    PORTALS.append({'map': map, 'at': tuple(at), 'to': to, 'target': tuple(target) if target else None, '_src': _source})


# ================================================================= Laden
def read(dirs):
    """Führt alle .py-Dateien der Ordner aus (Unterordner eingeschlossen, alphabetisch; _dateien werden übersprungen)."""
    global _source
    for base in dirs:
        if not os.path.isdir(base):
            ERRORS.append(f'{base}: Ordner nicht gefunden.')
            continue
        for folder, subdirs, files in os.walk(base):
            subdirs[:] = sorted(d for d in subdirs if not d.startswith(('_', '.')))
            for fname in sorted(files):
                if not fname.endswith('.py') or fname.startswith('_'):
                    continue
                path = os.path.join(folder, fname)
                _source = os.path.relpath(path, ROOT) if path.startswith(ROOT) else path
                try:
                    spec = importlib.util.spec_from_file_location('rabenfels_content_' + re.sub(r'\W', '_', _source), path)
                    spec.loader.exec_module(importlib.util.module_from_spec(spec))
                except Exception as exc:                      # Fehler in einer Inhaltsdatei: melden statt abstürzen
                    line = next((f.lineno for f in reversed(traceback.extract_tb(exc.__traceback__)) if f.filename == path), '?')
                    ERRORS.append(f'{_source}, Zeile {line}: {type(exc).__name__}: {exc}')
    _source = '?'


def resolve_look(what, value, src):
    """Vorlagenname oder Angaben -> geprüfte Angaben."""
    if isinstance(value, str):
        if value not in LOOKS:
            _err(f"{what}: Aussehen-Vorlage '{value}' gibt es nicht. Vorhanden: {', '.join(sorted(LOOKS)) or 'keine'}.", src)
            return {'cloth': '#888888'}
        value = LOOKS[value]
    o = {k: v for k, v in value.items() if k != '_src'}
    beast = o.get('body') == 'beast'
    if o.get('body') not in (None, 'human', 'beast'):
        _err(f"{what}: body {o['body']!r} gibt es nicht. Erlaubt: 'human', 'beast'.", src)
    allowed = BEAST_LOOK if beast else HUMAN_LOOK
    for k in sorted(set(o) - allowed):
        _err(f"{what}: unbekannte Angabe '{k}' im Aussehen. Erlaubt: {', '.join(sorted(allowed))}.", src)
    if ('fur' if beast else 'cloth') not in o:
        _err(f"{what}: im Aussehen fehlt '{'fur' if beast else 'cloth'}'.", src)
    for k, v in o.items():
        if k == 'body' or k not in allowed:
            continue
        if k == 'hat':
            if v not in HATS:
                _err(f"{what}: hat {v!r} gibt es nicht. Erlaubt: {', '.join(sorted(HATS))}.", src)
        elif k == 'weapon':
            if v not in WEAPONS:
                _err(f"{what}: weapon {v!r} gibt es nicht. Erlaubt: {', '.join(sorted(WEAPONS))}.", src)
        elif k in LOOK_FLAGS:
            if not isinstance(v, bool):
                _err(f"{what}: '{k}' im Aussehen ist True oder False.", src)
        elif k in LOOK_NUMBERS:
            if not isinstance(v, (int, float)) or not 0 < v <= 4:
                _err(f"{what}: '{k}' im Aussehen ist eine Zahl zwischen 0 und 4.", src)
        elif not isinstance(v, str) or not COLOR_RE.match(v):
            _err(f"{what}: '{k}' im Aussehen ist keine Farbe ('#rrggbb'): {v!r}.", src)
    return o


def _check_effects(what, sk, src):
    """Angaben, die jede aktive Fähigkeit und jede Kombo tragen kann."""
    if sk.get('apply') is not None and sk['apply'] not in STATUS:
        _err(f"{what}: Zustand '{sk['apply']}' gibt es nicht. Vorhanden: {', '.join(STATUS)}.", src)


def check():
    """Prüft alle Querverweise und berechnet abgeleitete Angaben. Geometrie prüft world.build()."""
    global _source                                  # Meldungen ohne eigene Quelle nennen die Datei des geprüften Eintrags
    # ---- Kombos
    for c in COMBOS:
        what, src = f"Kombo '{c['id']}'", c['_src']
        _source = src
        if not c['pairs']:
            _err(f"{what}: braucht mindestens ein Paar (Zustand, Schadensart).", src)
        for st, tg in c['pairs']:
            if st not in STATUS:
                _err(f"{what}: Zustand '{st}' gibt es nicht.", src)
            if tg not in TAGS:
                _err(f"{what}: Schadensart '{tg}' gibt es nicht.", src)
        _check_effects(what, c, src)
        for st, tg in c['pairs']:                                   # kann die Kombo überhaupt jemand auslösen?
            if st in STATUS and not any(x.get('apply') == st for x in SKILLS.values()):
                _note(f"{what}: keine Fähigkeit verursacht den Zustand '{st}' – dieses Paar zündet nie.", src)
            if tg in TAGS and not (any(x.get('tag') == tg and x.get('mult') for x in SKILLS.values())
                                   or any(k['atk'].get('tag') == tg for k in CLASSES.values())):
                _note(f"{what}: nichts richtet Schaden der Art '{tg}' an – dieses Paar zündet nie.", src)
        aoe = c.get('aoe')
        if aoe is not None:
            if _keys(f"{what}, aoe", aoe, {'r', 'mult', 'tag', 'apply'}, {'r', 'mult', 'tag'}):
                if aoe['tag'] not in TAGS:
                    _err(f"{what}, aoe: Schadensart '{aoe['tag']}' gibt es nicht.", src)
                _check_effects(what + ', aoe', aoe, src)
        if c.get('chain') is not None:
            if _keys(f"{what}, chain", c['chain'], {'n', 'mult', 'r', 'tag'}, {'n', 'mult', 'r'}):
                c['chain'].setdefault('tag', 'blitz')
                if c['chain']['tag'] not in TAGS:
                    _err(f"{what}, chain: Schadensart '{c['chain']['tag']}' gibt es nicht.", src)

    # ---- Klassen
    for cid, c in CLASSES.items():
        what, src = f"Klasse '{cid}'", c['_src']
        _source = src
        _color(what, c['color'])
        _numbers(what, c, ('hp', 'hp_lvl', 'dmg'), src)
        _numbers(what, c, ('armor',), src, positive=False)
        if isinstance(c['armor'], (int, float)) and c['armor'] > 0.6:
            _err(f"{what}: armor ist der Anteil des Schadens, der abprallt (0 bis 0.6), angegeben ist {c['armor']}.", src)
        if c['main'] not in ATTRS or c['main'] == 'vit':
            _err(f"{what}: main {c['main']!r} ist kein Hauptattribut. Erlaubt: str, ges, int.", src)
        if c['res'] not in RES_NAMES:
            _err(f"{what}: res {c['res']!r} gibt es nicht. Erlaubt: {', '.join(RES_NAMES)}.", src)
        if c['style'] not in STYLES:
            _err(f"{what}: style {c['style']!r} gibt es nicht. Erlaubt: {', '.join(sorted(STYLES))}.", src)
        if len(c['branches']) != 3:
            _err(f"{what}: braucht genau drei Zweige, angegeben sind {len(c['branches'])}.", src)
        a = c['atk']
        if a.get('type') == 'melee':
            _keys(f"{what}, atk", a, {'name', 'type', 'cd', 'range', 'arc', 'tag'}, {'name', 'type', 'cd', 'range', 'arc', 'tag'})
        elif a.get('type') == 'shot':
            a.setdefault('splash', 0.0)
            if _keys(f"{what}, atk", a, {'name', 'type', 'kind', 'cd', 'range', 'speed', 'splash', 'tag'},
                     {'name', 'type', 'kind', 'cd', 'range', 'speed', 'tag'}) and a['kind'] not in SHOT_KINDS:
                _err(f"{what}, atk: kind {a['kind']!r} gibt es nicht. Erlaubt: {', '.join(sorted(SHOT_KINDS))}.", src)
        else:
            _err(f"{what}, atk: type ist 'melee' oder 'shot'.", src)
        if a.get('tag') not in TAGS:
            _err(f"{what}, atk: Schadensart {a.get('tag')!r} gibt es nicht. Vorhanden: {', '.join(TAGS)}.", src)
        _numbers(f"{what}, atk", a, [k for k in ('cd', 'range', 'arc', 'speed') if k in a], src)
        c['look'] = resolve_look(what, c['look'], src)
        st = SKILLS.get(c['start'])
        if not st or st['cls'] != cid or st['type'] != 'active' or st['lvl'] != 1:
            _err(f"{what}: start '{c['start']}' muss eine aktive Fähigkeit dieser Klasse mit lvl 1 sein.", src)
        mine = [s for s in SKILLS.values() if s['cls'] == cid]
        for b in range(3):
            if not any(s['branch'] == b for s in mine):
                _err(f"{what}: Zweig {b} hat keine Fähigkeit.", src)
        n_act = sum(1 for s in mine if s['type'] == 'active')
        if n_act < 4:
            _err(f"{what}: hat nur {n_act} aktive Fähigkeiten – für die Tasten 1–4 braucht es mindestens vier.", src)
        elif n_act < 20:
            _note(f"{what}: hat {n_act} aktive Fähigkeiten, die anderen Klassen haben 20.", src)

    # ---- Fähigkeiten
    for sid, s in SKILLS.items():
        what, src = f"Fähigkeit '{sid}'", s['_src']
        _source = src
        if s['cls'] not in CLASSES:
            _err(f"{what}: Klasse '{s['cls']}' gibt es nicht. Vorhanden: {', '.join(CLASSES)}.", src)
        if s['branch'] not in (0, 1, 2):
            _err(f"{what}: branch ist 0, 1 oder 2.", src)
        if not isinstance(s['lvl'], int) or not 1 <= s['lvl'] <= MAX_LEVEL:
            _err(f"{what}: lvl liegt zwischen 1 und {MAX_LEVEL}.", src)
        if s['type'] == 'passive':
            st = s['stat']
            ok = st in PASSIVE_STATS or (st.startswith('dmg_') and st[4:] in TAGS) or (st.startswith('dot_') and st[4:] in STATUS)
            if not ok:
                _err(f"{what}: stat {st!r} gibt es nicht. Erlaubt: {', '.join(sorted(PASSIVE_STATS))}, "
                     f"dmg_<Schadensart>, dot_<Zustand>.", src)
            _numbers(what, s, ('per',), src)
            if '{v}' not in s['desc']:
                _note(f"{what}: in desc fehlt {{v}} für den Prozentwert.", src)
            continue
        if s['form'] not in FORMS:
            _err(f"{what}: form {s['form']!r} gibt es nicht. Erlaubt: {', '.join(FORMS)}.", src)
            continue
        required, optional = FORMS[s['form']]
        params = {k for k in s if k not in ('id', 'cls', 'branch', 'lvl', 'name', 'type', 'form', 'tag', 'cost', 'cd', 'desc', '_src')}
        need = set(required)
        if s['form'] in ('blast', 'zone') and not (s.get('at_self') or s.get('follow')):
            need.add('range')
        if s.get('mods') and s['form'] == 'dash':
            need.add('dur')
        _keys(f"{what} (form '{s['form']}')", params, required | optional, need)
        if s['tag'] is not None and s['tag'] not in TAGS:
            _err(f"{what}: Schadensart '{s['tag']}' gibt es nicht. Vorhanden: {', '.join(TAGS)}.", src)
        if s.get('mult') and s['tag'] in (None, 'hilfe'):
            _err(f"{what}: richtet Schaden an (mult), braucht also eine Schadensart als tag.", src)
        _check_effects(what, s, src)
        if s.get('kind') is not None and s['kind'] not in SHOT_KINDS:
            _err(f"{what}: kind {s['kind']!r} gibt es nicht. Erlaubt: {', '.join(sorted(SHOT_KINDS))}.", src)
        if isinstance(s.get('mods'), dict):
            _keys(f"{what}, mods", s['mods'], BUFF_MODS)
        if isinstance(s.get('ally'), dict):
            _keys(f"{what}, ally", s['ally'], ALLY_MODS)
        if s['form'] == 'buff' and not (s.get('mods') or s.get('absorb') or s.get('taunt')):
            _err(f"{what}: ein buff braucht mods, absorb oder taunt.", src)
        if s.get('color') is not None:
            _color(what, s['color'])
        _numbers(what, s, ('cost',), src, positive=False)
        _numbers(what, s, ('cd',), src)
        _numbers(what, s, [k for k in params if k in NUM_PARAMS], src, positive=False)
        for k in params & FLAG_PARAMS:
            if not isinstance(s[k], bool):
                _err(f"{what}: {k} ist True oder False, angegeben ist {s[k]!r}.", src)
        for group in ('mods', 'ally'):
            if isinstance(s.get(group), dict):
                _numbers(f"{what}, {group}", s[group], list(s[group]), src)
            elif s.get(group) is not None:
                _err(f"{what}: {group} hat die Form {{'Wirkung': Zahl}}.", src)
    # Voraussetzung im Zweig: so viele Punkte müssen schon im selben Zweig stecken
    for cid in CLASSES:
        for b in range(3):
            nodes = sorted((s for s in SKILLS.values() if s['cls'] == cid and s['branch'] == b), key=lambda s: s['lvl'])
            for i, s in enumerate(nodes):
                s['need'] = i

    # ---- Gegner
    for eid, e in ENEMIES.items():
        what, src = f"Gegner '{eid}'", e['_src']
        _source = src
        e['look'] = resolve_look(what, e['look'], src)
        if not e.get('scale') and not isinstance(e.get('lvl'), int):
            _err(f"{what}: braucht lvl (feste Stufe) oder scale=True (wächst mit der Ebene).", src)
        _numbers(what, e, ('hp', 'dmg', 'speed', 'radius', 'aggro', 'range', 'cd', 'xp'), src)
        _numbers(what, e, ('respawn',), src, positive=False)
        if e.get('shot'):
            _numbers(what, e, ('shot',), src)
        if e.get('summon') and e['summon'] not in ENEMIES:
            _err(f"{what}: summon '{e['summon']}' gibt es nicht.", src)
        if 'moves' in e:
            if not e.get('boss'):
                _err(f"{what}: moves gibt es nur für Bosse (boss=True).", src)
            bad = [m for m in e['moves'] if m not in BOSS_MOVES]
            if bad or not e['moves']:
                _err(f"{what}: moves {bad or '[]'} – erlaubt sind {', '.join(sorted(BOSS_MOVES))}.", src)
        elif e.get('boss'):
            e['moves'] = ['slam']
        if len(e['gold']) != 2 or not all(isinstance(v, int) for v in e['gold']) or e['gold'][0] > e['gold'][1]:
            _err(f"{what}: gold ist (min, max).", src)
        if e.get('dust'):
            _color(what, e['dust'])
        else:
            e['dust'] = e['look'].get('fur') or e['look'].get('skin') or e['look'].get('cloth') or '#cccccc'

    # ---- Karten (ohne Geometrie)
    mains = [m for m in MAPS.values() if m['main']]
    if len(mains) != 1:
        ERRORS.append(f"Karten: genau eine Karte braucht main=True, gefunden: {len(mains)} ({', '.join(m['id'] for m in mains) or 'keine'}).")
    npc_home = {}
    for mid, m in MAPS.items():
        what, src = f"Karte '{mid}'", m['_src']
        _source = src
        if m['light'] not in LIGHTS:
            _err(f"{what}: light {m['light']!r} gibt es nicht. Erlaubt: {', '.join(sorted(LIGHTS))}.", src)
        for nid, n in m['npcs'].items():
            nwhat = f"{what}, Bewohner '{nid}'"
            if not ID_RE.match(nid):
                _err(f"{nwhat}: Kennung aus Kleinbuchstaben, Ziffern und _.", src)
            if nid in npc_home:
                _err(f"{nwhat}: diese Kennung gibt es schon auf Karte '{npc_home[nid]}'.", src)
            npc_home[nid] = mid
            if _keys(nwhat, n, {'name', 'role', 'look', 'at', 'greet', 'services'}, {'name', 'role', 'look', 'at', 'greet'}):
                n['look'] = resolve_look(nwhat, n['look'], src)
                bad = sorted(set(n.get('services', ())) - SERVICES)
                if bad:
                    _err(f"{nwhat}: Dienst {', '.join(bad)} gibt es nicht. Erlaubt: {', '.join(sorted(SERVICES))}.", src)
                if 'dungeon' in n.get('services', ()) and not m['dungeon']:
                    _err(f"{nwhat}: der Dienst 'dungeon' braucht ein Verlies auf derselben Karte.", src)
        for sp in m['spawns']:
            if len(sp) not in (3, 4):
                _err(f"{what}: spawns-Eintrag {sp!r} hat die Form (Gegnerart, Zone, Anzahl) oder (Gegnerart, Zone, 1, (x, z)).", src)
                continue
            if sp[0] not in ENEMIES:
                _err(f"{what}: Gegnerart '{sp[0]}' in spawns gibt es nicht.", src)
            elif ENEMIES[sp[0]].get('scale'):
                _err(f"{what}: '{sp[0]}' wächst mit der Ebene (scale=True) und gehört in ein Verlies, nicht in spawns.", src)
            elif not ENEMIES[sp[0]]['respawn'] > 0:
                _err(f"{what}: '{sp[0]}' hat respawn=0 (nur für beschworene Diener) und stünde in spawns sofort wieder auf.", src)
            if not isinstance(sp[2], int) or sp[2] < 1 or (len(sp) == 4 and sp[2] != 1):
                _err(f"{what}: spawns-Eintrag {sp!r}: die Anzahl ist eine ganze Zahl ab 1, mit festem Platz genau 1.", src)
            if sp[1] not in m['zones']:
                _err(f"{what}: Zone '{sp[1]}' in spawns gibt es auf dieser Karte nicht. Vorhanden: {', '.join(m['zones']) or 'keine'}.", src)
        for pk in m['pickups']:
            if len(pk) != 3 or pk[0] not in PICKUPS:
                _err(f"{what}: pickups-Eintrag {pk!r} hat die Form (Questgegenstand, x, z); vorhanden: {', '.join(PICKUPS)}.", src)
        for d in m['deco']:
            if len(d) != 3 or d[0] not in DECO:
                _err(f"{what}: deco-Eintrag {d!r} hat die Form (Art, x, z) mit Art {', '.join(sorted(DECO))}.", src)
        for sym, p in m['portals'].items():
            if _keys(f"{what}, Übergang '{sym}'", p, {'to', 'target'}, {'to'}) and p['to'] not in MAPS:
                _err(f"{what}, Übergang '{sym}': Zielkarte '{p['to']}' gibt es nicht.", src)
        d = m['dungeon']
        if d is not None:
            dwhat = f"{what}, dungeon"
            if _keys(dwhat, d, {'zone', 'base_level', 'mix', 'boss', 'boss_every', 'floor_xp'}, {'zone', 'base_level', 'mix'}):
                if d['zone'] not in m['zones']:
                    _err(f"{dwhat}: Zone '{d['zone']}' gibt es auf dieser Karte nicht.", src)
                if not d['mix'] or not any(first <= 1 for _, first, _ in d['mix']):
                    _err(f"{dwhat}: mix braucht mindestens eine Gegnerart ab Ebene 1.", src)
                for kind in [k for k, _, _ in d['mix']] + ([d['boss']] if d.get('boss') else []):
                    if kind not in ENEMIES or not ENEMIES[kind].get('scale'):
                        _err(f"{dwhat}: '{kind}' muss ein Gegner mit scale=True sein.", src)
                d.setdefault('boss', None)
                d.setdefault('boss_every', 5)
                d.setdefault('floor_xp', 6.0)
    for p in PORTALS:
        for key in ('map', 'to'):
            if p[key] not in MAPS:
                _err(f"Übergang: Karte '{p[key]}' gibt es nicht.", p['_src'])

    # ---- Quests
    spawned = {sp[0] for m in MAPS.values() for sp in m['spawns'] if len(sp) >= 3}
    spawned |= {e['summon'] for e in ENEMIES.values() if e.get('summon')}
    for m in MAPS.values():
        if m['dungeon'] and isinstance(m['dungeon'].get('mix'), list):
            spawned |= {k for k, _, _ in m['dungeon']['mix']} | {m['dungeon'].get('boss')}
    placed = {pk[0] for m in MAPS.values() for pk in m['pickups'] if len(pk) == 3}
    for qid, q in QUESTS.items():
        what, src = f"Quest '{qid}'", q['_src']
        _source = src
        if q['npc'] not in npc_home:
            _err(f"{what}: Bewohner '{q['npc']}' gibt es nicht. Vorhanden: {', '.join(npc_home) or 'keine'}.", src)
        if q['type'] not in QUEST_TYPES:
            _err(f"{what}: type {q['type']!r} gibt es nicht. Erlaubt: {', '.join(sorted(QUEST_TYPES))}.", src)
        t = q['target']
        if q['type'] == 'kill':
            if isinstance(t, str) and t.startswith('map:'):
                if t[4:] not in MAPS:
                    _err(f"{what}: Karte '{t[4:]}' im target gibt es nicht.", src)
            elif t != 'any' and t not in ENEMIES:
                _err(f"{what}: Gegnerart '{t}' gibt es nicht. Erlaubt ist auch 'any' oder 'map:<Karte>'.", src)
            elif t != 'any' and t not in spawned:
                _err(f"{what}: Gegnerart '{t}' taucht auf keiner Karte auf – die Quest wäre nicht lösbar.", src)
        elif q['type'] == 'collect':
            if t not in PICKUPS:
                _err(f"{what}: Questgegenstand '{t}' gibt es nicht. Vorhanden: {', '.join(PICKUPS)}.", src)
            elif t not in placed:
                _err(f"{what}: Questgegenstand '{t}' liegt auf keiner Karte – die Quest wäre nicht lösbar.", src)
        elif q['type'] == 'depth':
            if t not in MAPS or not MAPS[t]['dungeon']:
                _err(f"{what}: target muss eine Karte mit Verlies sein.", src)
        if not isinstance(q['count'], int) or q['count'] < 1:
            _err(f"{what}: count ist eine ganze Zahl ab 1.", src)
        if not isinstance(q['minlvl'], int) or not 1 <= q['minlvl'] <= MAX_LEVEL:
            _err(f"{what}: minlvl liegt zwischen 1 und {MAX_LEVEL}.", src)
        for key in ('xp', 'gold', 'xp_pct', 'gold_lvl', 'potions', 'weapon'):
            if key in q and (isinstance(q[key], bool) or not isinstance(q[key], (int, float)) or q[key] < 0):
                _err(f"{what}: {key} muss eine Zahl ab 0 sein, angegeben ist {q[key]!r}.", src)
        if q['req'] is not None and q['req'] not in QUESTS:
            _err(f"{what}: Vorgänger-Quest '{q['req']}' gibt es nicht.", src)
        if not (q.get('xp') or q.get('xp_pct')):
            _err(f"{what}: braucht eine Belohnung (xp oder xp_pct).", src)
        seen, cur = set(), qid                                   # Kette ohne Kreis?
        while cur is not None and cur in QUESTS:
            if cur in seen:
                _err(f"{what}: die Vorgänger-Kette dreht sich im Kreis.", src)
                break
            seen.add(cur)
            cur = QUESTS[cur]['req']
    _source = '?'
    _placeholders()


def _placeholders():
    """Texte, die der Gerüst-Generator (tools/neu.py) als TODO hinterlassen hat, sind ein Hinweis wert."""
    def todo(what, src, *texts):
        n = sum(1 for t in texts if isinstance(t, str) and 'TODO' in t)
        if n:
            _note(f"{what}: enthält noch {n} Platzhalter (TODO) – im Spiel zu sehen.", src)

    for cid, c in CLASSES.items():
        todo(f"Klasse '{cid}'", c['_src'], c['name'], c['desc'], c['atk'].get('name'), *(v for b in c['branches'] for v in b.values()))
    for sid, s in SKILLS.items():
        todo(f"Fähigkeit '{sid}'", s['_src'], s['name'], s['desc'])
    for eid, e in ENEMIES.items():
        todo(f"Gegner '{eid}'", e['_src'], e['name'])
    for qid, q in QUESTS.items():
        todo(f"Quest '{qid}'", q['_src'], q['title'], q['goal'], q['where'], q['text'], q['done'])
    for mid, m in MAPS.items():
        todo(f"Karte '{mid}'", m['_src'], m['name'], *(r[0] for r in m['regions'] if r))
        for nid, n in m['npcs'].items():
            todo(f"Karte '{mid}', Bewohner '{nid}'", m['_src'], n.get('name'), n.get('role'), n.get('greet'))


def finish():
    """Bricht mit einer Sammelmeldung ab, wenn beim Laden Fehler gefunden wurden."""
    if ERRORS:
        raise ContentError(f'{len(ERRORS)} Fehler in den Inhalten:\n  - ' + '\n  - '.join(ERRORS))


def find_combo(statuses, tag):
    """Welche Kombo löst ein Treffer der Art `tag` auf einem Gegner mit diesen Zuständen aus?"""
    if not tag:
        return None, None
    for c in COMBOS:
        for st, t in c['pairs']:
            if t == tag and st in statuses:
                return c, st
    return None, None


def _public(d):
    return {k: v for k, v in d.items() if k != '_src'}


def client_data():
    """Alles, was der Browser über Klassen, Fähigkeiten, Gegner und Quests wissen muss."""
    services = {nid: list(n.get('services', ())) for m in MAPS.values() for nid, n in m['npcs'].items()}
    return {
        'classes': {k: _public(v) for k, v in CLASSES.items()},
        'attrs': ATTRS,
        'resNames': RES_NAMES,
        'skills': {k: _public(v) for k, v in SKILLS.items()},
        'tags': {k: _public(v) for k, v in TAGS.items()},
        'status': [{'id': k, **_public(v)} for k, v in STATUS.items()],
        'combos': [_public(c) for c in COMBOS],
        'maxRank': MAX_RANK,
        'rankBonus': RANK_BONUS,
        'enemies': {k: {'name': v['name'], 'radius': v['radius'], 'look': v['look'], 'dust': v['dust'],
                        'boss': bool(v.get('boss'))} for k, v in ENEMIES.items()},
        'elites': {k: a['name'] for k, a in ELITE_AFFIXES.items()},
        'elixirs': {k: {'name': x['name'], 'desc': x['desc']} for k, x in ELIXIRS.items()},
        'elixirTime': ELIXIR_TIME,
        'itemSlots': ITEM_SLOTS,
        'itemStats': {k: v[0] for k, v in ITEM_STATS.items()},
        'rarities': [{'name': r[0], 'color': r[1], 'sell': r[5]} for r in RARITIES],
        'bagMax': BAG_MAX,
        'pickups': {k: _public(v) for k, v in PICKUPS.items()},
        'quests': {k: _public(v) for k, v in QUESTS.items()},
        'shops': services,
        'maps': {k: {'name': v['name'], 'dungeon': bool(v['dungeon']), 'ambient': v['ambient']} for k, v in MAPS.items()},
        'radius': PLAYER_RADIUS,
        'maxLevel': MAX_LEVEL,
        'gearMax': GEAR_MAX,
        'potion': {'cd': POTION_CD, 'max': POTION_MAX},
    }
