"""Burg Rabenfels – Spiellogik.

load() liest die Inhalte unter content/ ein, prüft sie und baut die Welt.
Das muss einmal geschehen, bevor ein Game entsteht (app.py und die Tests tun das).
"""
import os

from . import registry, world


def load(extra=()):
    """Lädt content/ und zusätzliche Ordner (auch aus der Umgebungsvariable RABENFELS_CONTENT).

    Bei fehlerhaften Inhalten bricht load() mit registry.ContentError ab; die Meldung nennt jede Stelle.
    """
    dirs = [registry.CONTENT_DIR, *extra]
    dirs += [d for d in os.environ.get('RABENFELS_CONTENT', '').split(os.pathsep) if d]
    registry.reset()
    registry.read(dirs)
    registry.check()
    world.build()
    registry.finish()
