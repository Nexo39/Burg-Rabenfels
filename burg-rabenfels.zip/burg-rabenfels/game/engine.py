"""Spiellogik: Helden, Fähigkeiten, Zustände und Kombos, Gegner-KI, Quests, Verliese, Speicherstände.

Der Server entscheidet alles, was zählt (Treffer, Schaden, Beute, Questfortschritt).
Nur die eigene Bewegung berechnet der Browser selbst vor – der Server prüft sie nach.

Die Engine kennt keine einzelnen Klassen, Gegner, Quests oder Karten: Sie liest alles aus dem
Inhaltsverzeichnis (registry.py) und der daraus gebauten Welt (world.py). Neue Inhalte gehören
deshalb nach content/, nicht hierher.
"""
import json
import math
import os
import random
import re
import threading
import time
from collections import defaultdict

from . import world as W
from .data import (ATTRS, ATTR_POINTS, BAR_SLOTS, BASE_ATTR, ARMOR_BONUS, GEAR_MAX, MAX_LEVEL, MAX_PLAYERS, MAX_RANK,
                   PLAYER_RADIUS, PLAYER_SPEED, POTION_CD, POTION_HEAL, POTION_MAX, RANK_BONUS, RESPAWN_TIME,
                   SHARE_RADIUS, WEAPON_BONUS, enemy_dmg_mult, enemy_gold, enemy_hp_mult, enemy_xp, gear_price,
                   potion_price, respec_price, xp_needed,
                   BAG_MAX, DROP_CHANCE, ELITE_AFFIXES, ELITE_CHANCE, ELITE_REWARD, ELIXIR_TIME, ELIXIRS, ITEM_SLOTS,
                   ITEM_STATS, RARITIES, elixir_price, item_scale)
from .registry import CLASSES, ENEMIES, QUESTS, SKILLS, STATUS, TAGS, find_combo

TICK = 1 / 20
NAME_RE = re.compile(r'^[A-Za-zÄÖÜäöüß0-9 _\-]{2,16}$')
hypot = math.hypot


def r2(v):
    return round(v, 2)


def num(d, key, default=0.0):
    """Liest eine endliche Zahl aus Client-Daten."""
    try:
        v = float(d.get(key, default))
    except (TypeError, ValueError):
        return default
    return v if math.isfinite(v) else default


def color_of(sk):
    return sk.get('color') or TAGS.get(sk.get('tag') or 'hilfe', TAGS['hilfe'])['color']


def item_ok(it, slot=None):
    """Ein Gegenstand aus einem Speicherstand – oder None, wenn er nicht (mehr) passt."""
    if not isinstance(it, dict) or it.get('slot') not in ITEM_SLOTS or (slot and it['slot'] != slot):
        return None
    mods = {k: float(v) for k, v in (it.get('mods') or {}).items() if k in ITEM_STATS}
    if not mods:
        return None
    rar = max(0, min(len(RARITIES) - 1, int(it.get('rar', 0))))
    return {'slot': it['slot'], 'name': str(it.get('name', ITEM_SLOTS[it['slot']]))[:48], 'lvl': int(it.get('lvl', 1)),
            'rar': rar, 'mods': mods}


class Player:
    def __init__(self, sid, pid, name, cls, save=None):
        save = save or {}
        self.sid, self.id, self.name = sid, pid, name
        self.cls = save['cls'] if save.get('cls') in CLASSES else cls
        self.level = max(1, min(MAX_LEVEL, int(save.get('level', 1))))
        self.xp = int(save.get('xp', 0))
        self.gold = int(save.get('gold', 0))
        self.potions = int(save.get('potions', 2))
        self.weapon = min(GEAR_MAX, int(save.get('weapon', 0)))
        self.armor = min(GEAR_MAX, int(save.get('armor', 0)))
        deep = save.get('deepest') or {}
        if not isinstance(deep, dict):                       # Speicherstand von vor den Karten: eine einzige Zahl
            deep = {'katakomben': int(deep)}
        self.deepest = {k: int(v) for k, v in deep.items() if k in W.MAPS and W.MAPS[k]['dungeon']}   # je Verlies
        self.quests = {k: dict(v) for k, v in save.get('quests', {}).items() if k in QUESTS}
        saved_attrs = save.get('attrs') or {}
        self.attrs = {k: max(BASE_ATTR, int(saved_attrs.get(k, BASE_ATTR))) for k in ATTRS}
        self.skills = {k: max(1, min(MAX_RANK, int(v))) for k, v in (save.get('skills') or {}).items()
                       if k in SKILLS and SKILLS[k]['cls'] == self.cls}
        self.bar = list(save.get('bar') or [])
        self._check_build()
        # Beute: angelegte Ringe/Amulette und die Tasche; Elixiere: Kennung -> Ablaufzeit
        saved_items = save.get('items') or {}
        self.items = {slot: item_ok(saved_items.get(slot), slot) for slot in ITEM_SLOTS}
        self.bag = [it for it in (item_ok(i) for i in (save.get('bag') or [])) if it][:BAG_MAX]
        self.elixirs = {k: time.time() + float(v) for k, v in (save.get('elixirs') or {}).items()
                        if k in ELIXIRS and float(v) > 0}
        self.x, self.z = W.MAPS[W.MAIN]['start']
        self.rot = math.pi
        self.buffs = {}
        self.shield = 0.0
        self.shield_until = 0.0
        self.recalc()
        self.hp = float(self.max_hp)
        self.res = float(self.stats['res'])
        self.dead = False
        self.respawn_at = 0.0
        self.next_atk = 0.0
        self.cds = {}
        self.last_combat = 0.0
        self.regen_at = 0.0
        self.last_move = time.time()
        self.budget = PLAYER_SPEED * 0.6
        self.last_chat = 0.0
        self.stairs_at = 0.0
        self.dirty = False

    # ---- Punkte
    def ap(self):
        """Freie Attributpunkte."""
        return (self.level - 1) * ATTR_POINTS - sum(v - BASE_ATTR for v in self.attrs.values())

    def sp(self):
        """Freie Fähigkeitspunkte (die Startfähigkeit ist der Punkt von Stufe 1)."""
        return self.level - sum(self.skills.values())

    def branch_points(self, branch):
        return sum(r for k, r in self.skills.items() if SKILLS[k]['branch'] == branch)

    def reset_build(self):
        self.attrs = {k: BASE_ATTR for k in ATTRS}
        start = CLASSES[self.cls]['start']
        self.skills = {start: 1}
        self.bar = [start] + [None] * (BAR_SLOTS - 1)

    def _check_build(self):
        """Bringt Fähigkeiten und Tastenbelegung eines (alten) Speicherstands in Ordnung."""
        self.skills.setdefault(CLASSES[self.cls]['start'], 1)
        if self.ap() < 0 or self.sp() < 0:
            self.reset_build()
        ok = lambda k: k in self.skills and SKILLS[k]['type'] == 'active'
        self.bar = [(b if ok(b) else None) for b in self.bar[:BAR_SLOTS]]
        self.bar += [None] * (BAR_SLOTS - len(self.bar))
        if not any(self.bar):
            self.bar[0] = CLASSES[self.cls]['start']

    # ---- abgeleitete Werte
    def recalc(self):
        c, a, lvl = CLASSES[self.cls], self.attrs, self.level
        pas = defaultdict(float)
        for k, rank in self.skills.items():
            sk = SKILLS[k]
            if sk['type'] == 'passive':
                pas[sk['stat']] += sk['per'] * rank
        power_bonus = 0.0
        for it in self.items.values():                      # angelegte Ringe und Amulette
            for k, v in (it or {}).get('mods', {}).items():
                if k == 'power':
                    power_bonus += v
                else:
                    pas[k] += v
        mana = c['res'] == 'mana'
        res_attr = a['int'] if mana else (a['str'] + a['ges']) / 2
        self.stats = {
            'power': (c['dmg'] + a[c['main']] * 0.5) * (1 + 0.03 * (lvl - 1)) * (1 + WEAPON_BONUS * self.weapon)
                     * (1 + power_bonus),
            'hp': round((c['hp'] + c['hp_lvl'] * (lvl - 1) + a['vit'] * 8) * (1 + pas['hp_pct'] + ARMOR_BONUS * self.armor)),
            'res': round((100 + res_attr * 0.5) * (1 + pas['res_max_pct'])),
            'resregen': ((4 + a['int'] * 0.03) if mana else (7 + a['ges'] * 0.02)) * (1 + pas['res_regen_pct']),
            'crit': 0.05 + a['ges'] * 0.0008 + pas['crit'],
            'critdmg': 1.8 + pas['crit_dmg'],
            'armor': min(0.75, c['armor'] + min(0.15, a['vit'] * 0.0005) + pas['dr']),
            'speed': PLAYER_SPEED * (1 + min(0.15, a['ges'] * 0.0005) + pas['speed']),
            'cdr': min(0.15, a['int'] * 0.0005),
            'haste': pas['haste'],
            'hpregen': 0.3 + a['vit'] * 0.04,
            'heal': 1 + pas['heal_pct'],
            'combo': 1 + pas['combo'],
            'statusdur': 1 + pas['status_dur'],
            'killheal': pas['kill_heal'],
        }
        self.tag_bonus = {t: pas['dmg_' + t] for t in TAGS}
        self.dot_bonus = {s: pas['dot_' + s] for s in STATUS}
        if hasattr(self, 'hp'):
            self.hp = min(self.hp, self.max_hp)
            self.res = min(self.res, self.stats['res'])

    @property
    def max_hp(self):
        return self.stats['hp']

    def buffv(self, key, now):
        """Summe einer Stärkung aus Fähigkeiten und Elixieren."""
        v = sum(b.get(key, 0) for b in self.buffs.values() if b['until'] > now)
        for k, until in self.elixirs.items():
            if until > now:
                v += ELIXIRS[k]['mods'].get(key, 0)
        return v

    def combat_buff(self, key, now):
        """Nur Stärkungen aus Fähigkeiten (für das Leuchten der Figur)."""
        return sum(b.get(key, 0) for b in self.buffs.values() if b['until'] > now)

    def speed(self, now):
        return self.stats['speed'] * (1 + self.buffv('speed', now))

    def atk_cd(self, now):
        return CLASSES[self.cls]['atk']['cd'] / (1 + self.stats['haste'] + self.buffv('haste', now))

    def to_save(self):
        return {'cls': self.cls, 'level': self.level, 'xp': self.xp, 'gold': self.gold, 'potions': self.potions,
                'weapon': self.weapon, 'armor': self.armor, 'deepest': self.deepest, 'quests': self.quests,
                'attrs': self.attrs, 'skills': self.skills, 'bar': self.bar,
                'items': self.items, 'bag': self.bag,
                'elixirs': {k: round(u - time.time()) for k, u in self.elixirs.items() if u - time.time() > 1}}


class Enemy:
    def __init__(self, eid, kind, zone, home, level=None, temp=False, hp_mult=1.0):
        d = ENEMIES[kind]
        self.id, self.kind, self.zone, self.home, self.temp, self.d = eid, kind, zone, home, temp, d
        self.level = level or d.get('lvl', 1)
        self.radius = d['radius']
        self.radius_c = min(d['radius'], 0.85)       # Kollisionsradius (passt durch Türen)
        if d.get('scale'):
            self.base_hp = round(d['hp'] * enemy_hp_mult(self.level) * hp_mult)
            self.dmg = d['dmg'] * enemy_dmg_mult(self.level)
            self.xp = enemy_xp(d['xp'], self.level)
            self.gold = enemy_gold(d['gold'], self.level)
        else:
            self.base_hp, self.dmg, self.xp, self.gold = round(d['hp'] * hp_mult), d['dmg'], d['xp'], d['gold']
        self.max_hp = self.base_hp
        self.boss = bool(d.get('boss'))
        self.elite = None                 # Kennung der Eigenart eines Elite-Gegners
        self.respawn_at = 0.0
        self.gone = False
        self.reset()

    def reset(self):
        self.x, self.z = self.home
        self.rot = random.uniform(-math.pi, math.pi)
        self.elite = None
        self.speed_f = self.cd_f = self.dmg_f = 1.0
        self.leech = 0.0
        self.max_hp = self.base_hp
        self.hp = self.max_hp
        self.dead = False
        self.target = None
        self.state = 'idle'
        self.status = {}                 # Zustand -> {'until', 'src', 'dps', 'next'}
        self.combo_at = 0.0
        self.next_atk = 0.0
        self.windup_until = 0.0
        self.ignore_until = 0.0
        self.stun_until = 0.0
        self.stun_free_until = 0.0       # kurz nach einer Betäubung nicht erneut betäubbar
        self.slow_until = 0.0
        self.slow_f = 1.0
        self.weak_until = 0.0
        self.wander_at = 0.0
        self.wander_to = None
        self.path_until = 0.0
        self.path_next = 0.0
        self.waypoint = None
        self.return_since = 0.0
        # nur für Bosse
        self.cast_until = 0.0
        self.next_slam = 0.0
        self.summoned = False
        self.enraged = False
        self.move_i = 0


class Game:
    def __init__(self, emit, save_path, dev=False):
        self.emit = emit                  # emit(event, data, to=None) – None = an alle im Spiel
        self.save_path = save_path
        self.dev = dev
        self.lock = threading.RLock()
        self.players = {}
        self.enemies = {}
        self.projs = []
        self.zones = []
        self.pickups = []
        self.timers = []
        self.fx = []
        self.now = time.time()
        self.last_save = self.now
        self._next_id = 100
        self.by_id = {}                   # Helden nach Kennung
        self.elite_chance = ELITE_CHANCE
        # Verliese: je Karte mit Verlies eine gemeinsame Halle für alle, Ebene für Ebene
        self.dungeons = {mid: {'depth': 0, 'phase': 'idle', 'start': 1, 'next_at': 0.0, 'empty_since': 0.0,
                               'reserve': 0, 'hp_mult': 1.0, 'fighters': set()}
                         for mid, b in W.MAPS.items() if b['dungeon']}
        self.saves = self._load()
        self._populate()

    # ------------------------------------------------------------------ Hilfen
    def _id(self):
        self._next_id += 1
        return self._next_id

    def _fx(self, **kw):
        """Merkt einen Effekt für die nächste Momentaufnahme vor – samt der Karte, auf der er zu sehen ist."""
        if 'x' in kw:
            where = W.map_at(kw['x'], kw['z'])
        elif 'pts' in kw:
            where = W.map_at(*kw['pts'][0])
        else:
            who = self.enemies.get(kw.get('id')) or self.by_id.get(kw.get('id'))
            where = who.zone['map'] if isinstance(who, Enemy) else W.map_at(who.x, who.z) if who else None
        self.fx.append((where, kw))

    def _spot(self, zone, kind, away_from=()):
        """Ein Platz in der Zone, an dem ein Gegner dieser Art nicht in einer Mauer steckt – möglichst fern der Helden."""
        radius = min(ENEMIES[kind]['radius'], 0.85)
        best = None
        for _ in range(40):
            x, z = W.random_point(zone)
            if W.blocked(x, z, radius):
                continue
            best = (x, z)
            if all(hypot(p.x - x, p.z - z) > 9 for p in away_from):
                break
        if best is None:                                          # sehr enge Zone: Kachelmitte nehmen
            tx, tz = random.choice(zone['tiles'])
            best = ((tx + 0.5) * W.TILE, (tz + 0.5) * W.TILE)
        return best

    def _near_start(self, map_id):
        """Ein freier Punkt am Ankunftspunkt einer Karte (leicht gestreut, damit Helden nicht aufeinander stehen)."""
        sx, sz = W.MAPS[map_id]['start']
        for _ in range(8):
            x, z = sx + random.uniform(-3, 3), sz + random.uniform(-2, 2)
            if not W.blocked(x, z, PLAYER_RADIUS) and W.los(sx, sz, x, z):
                return x, z
        return sx, sz

    def _sys(self, text):
        self.emit('chat', {'sys': True, 'text': text})

    def _toast(self, p, text, kind='info'):
        self.emit('toast', {'text': text, 'kind': kind}, to=p.sid)

    def _after(self, delay, fn):
        self.timers.append((self.now + delay, fn))

    def _roll_elite(self, e, affix=None):
        """Macht einen festen Gegner mit etwas Glück (oder ausdrücklich) zum Elite-Gegner."""
        if e.boss or e.temp or e.d.get('scale'):
            return
        if not affix and random.random() >= self.elite_chance:
            return
        affix = affix or random.choice(list(ELITE_AFFIXES))
        a = ELITE_AFFIXES[affix]
        e.elite = affix
        e.speed_f, e.cd_f, e.dmg_f, e.leech = a.get('speed', 1.0), a.get('cd', 1.0), a.get('dmg', 1.0), a.get('leech', 0.0)
        e.max_hp = e.hp = round(e.base_hp * a.get('hp', 1.0))

    def _populate(self):
        for kind, zone, count, at in W.SPAWNS:
            for _ in range(count):
                e = Enemy(self._id(), kind, zone, at or self._spot(zone, kind))
                self._roll_elite(e)
                self.enemies[e.id] = e
        for kind, x, z, map_id in W.PICKUPS:
            self.pickups.append({'id': self._id(), 'kind': kind, 'x': x, 'z': z, 'map': map_id, 'active': True, 'at': 0.0})

    # ------------------------------------------------------------ Speicherstände
    def _load(self):
        try:
            with open(self.save_path, encoding='utf-8') as f:
                data = json.load(f)
                return data if isinstance(data, dict) else {}
        except (OSError, ValueError):
            return {}

    def _save_all(self):
        for p in self.players.values():
            self.saves[p.name.lower()] = {'name': p.name, **p.to_save()}
        self.last_save = self.now
        try:
            os.makedirs(os.path.dirname(self.save_path), exist_ok=True)
            tmp = self.save_path + '.tmp'
            with open(tmp, 'w', encoding='utf-8') as f:
                json.dump(self.saves, f, ensure_ascii=False, indent=1)
            os.replace(tmp, self.save_path)
        except OSError as err:
            print('Speichern fehlgeschlagen:', err)

    # ------------------------------------------------------- Beitreten/Verlassen
    def join(self, sid, name, cls):
        name = re.sub(r'\s+', ' ', str(name or '')).strip()
        if not NAME_RE.match(name):
            return {'error': 'Der Name braucht 2 bis 16 Zeichen: Buchstaben, Ziffern, Leerzeichen, - oder _.'}
        if cls not in CLASSES:
            return {'error': 'Wähle eine Klasse.'}
        with self.lock:
            if sid in self.players:
                return {'error': 'Du bist bereits in der Burg.'}
            key = name.lower()
            if any(p.name.lower() == key for p in self.players.values()):
                return {'error': f'„{name}“ ist gerade schon in der Burg unterwegs. Wähle einen anderen Namen.'}
            if len(self.players) >= MAX_PLAYERS:
                return {'error': 'Die Burg ist voll. Versuch es später noch einmal.'}
            save = self.saves.get(key)
            self.now = time.time()
            p = Player(sid, self._id(), name, cls, save)
            p.x, p.z = self._near_start(W.MAIN)
            self.players[sid] = self.by_id[p.id] = p
            self._sys(f'{p.name} betritt die Burg.')
            return {'ok': True, 'id': p.id, 'world': W.CLIENT, 'you': self._you(p),
                    'x': r2(p.x), 'z': r2(p.z), 'returning': bool(save), 'dev': self.dev}

    def leave(self, sid):
        with self.lock:
            p = self.players.pop(sid, None)
            if not p:
                return
            self.saves[p.name.lower()] = {'name': p.name, **p.to_save()}
            self._save_all()
            for e in self.enemies.values():
                if e.target == sid:
                    e.target = None
                    e.state, e.return_since = 'return', time.time()
            self.zones = [z for z in self.zones if z['owner'] != sid]
            self.by_id.pop(p.id, None)
            self._sys(f'{p.name} verlässt die Burg.')

    def _you(self, p):
        now, s = self.now, p.stats
        return {
            'name': p.name, 'cls': p.cls, 'lvl': p.level, 'xp': p.xp,
            'xpn': xp_needed(p.level) if p.level < MAX_LEVEL else 0,
            'gold': p.gold, 'pot': p.potions, 'wpn': p.weapon, 'arm': p.armor,
            'quests': {k: dict(v) for k, v in p.quests.items()},
            'dead': max(0.0, r2(p.respawn_at - now)) if p.dead else 0,
            'attrs': dict(p.attrs), 'ap': p.ap(), 'sp': p.sp(),
            'skills': dict(p.skills), 'bar': list(p.bar),
            'speed': r2(p.speed(now)), 'atkcd': r2(p.atk_cd(now)),
            'stats': {'hp': s['hp'], 'res': s['res'], 'resregen': r2(s['resregen']), 'power': round(s['power'], 1),
                      'crit': round(s['crit'], 3), 'critdmg': r2(s['critdmg']), 'armor': round(s['armor'], 3),
                      'speed': r2(s['speed']), 'cdr': round(s['cdr'], 3), 'haste': r2(s['haste']),
                      'hpregen': r2(s['hpregen']), 'heal': r2(s['heal']), 'combo': r2(s['combo'])},
            'prices': {'weapon': gear_price(p.weapon), 'armor': gear_price(p.armor),
                       'potion': potion_price(p.level), 'respec': respec_price(p.level), 'elixir': elixir_price(p.level)},
            'items': dict(p.items), 'bag': list(p.bag),
            'elix': {k: round(u - now) for k, u in p.elixirs.items() if u > now},
            # je Verlies: tiefste geschaffte Ebene und die Ebenen, auf denen der Held einsteigen darf
            'dungeons': {mid: {'deep': p.deepest.get(mid, 0), 'steps': self._entries(p, mid)} for mid in self.dungeons},
        }

    def _entries(self, p, mid):
        """Einstiegs-Ebenen eines Verlieses: Ebene 1 und die Ebenen nach den Bossen, die der Held schon bezwungen hat."""
        every = W.MAPS[mid]['dungeon']['boss_every']
        steps = list(range(every + 1, p.deepest.get(mid, 0) + 2, every))[-3:]
        return [1] + [d for d in steps if d != 1]

    # --------------------------------------------------------------- Bewegung
    def on_move(self, sid, d):
        with self.lock:
            p = self.players.get(sid)
            if not p or p.dead:
                return
            x, z = num(d, 'x', p.x), num(d, 'z', p.z)
            now = time.time()
            dt = min(max(now - p.last_move, 0.0), 0.5)
            p.last_move = now
            speed = p.speed(now)
            # Bewegungsguthaben: füllt sich mit der Zeit, jede Strecke verbraucht davon
            p.budget = min(p.budget + speed * 1.15 * dt, speed * 0.6)
            dist = hypot(x - p.x, z - p.z)
            if dist > p.budget + 0.05 or W.blocked(x, z, PLAYER_RADIUS * 0.9):
                self.emit('correct', {'x': r2(p.x), 'z': r2(p.z)}, to=sid)
                return
            p.budget -= dist
            p.x, p.z, p.rot = x, z, num(d, 'r', p.rot)

    def _teleport(self, p, x, z, dash=False):
        p.x, p.z = x, z
        p.budget = PLAYER_SPEED * 0.6
        p.last_move = time.time()
        self.emit('correct', {'x': r2(x), 'z': r2(z), 'dash' if dash else 'tp': 1}, to=p.sid)

    # ------------------------------------------------------- Angriff und Treffer
    def _aim(self, p, d):
        dx, dz = num(d, 'x', p.x) - p.x, num(d, 'z', p.z) - p.z
        dist = hypot(dx, dz)
        if dist < 0.05:
            return math.sin(p.rot), math.cos(p.rot), 0.0
        return dx / dist, dz / dist, dist

    def _roll(self, p, mult, tag):
        s, now = p.stats, self.now
        dmg = s['power'] * mult * (1 + p.tag_bonus.get(tag, 0)) * (1 + p.buffv('dmg', now))
        crit = random.random() < s['crit'] + p.buffv('crit', now)
        dmg *= random.uniform(0.9, 1.1) * (s['critdmg'] if crit else 1.0)
        return max(1, round(dmg)), crit

    def _can_hit(self, e, p):
        """Außerhalb seiner Zone lässt sich ein Gegner nicht bekämpfen (kein Beschuss aus sicherer Ecke)."""
        if W.in_rect(p.x, p.z, e.zone['leash']):
            return True
        return not (e.state == 'return' or e.boss)

    def _strike(self, p, e, mult, sk, splash=False):
        """Ein Treffer eines Helden: Schaden, Kombo, Zustände."""
        if e.dead:
            return
        if not self._can_hit(e, p):
            self._fx(t='miss', x=r2(e.x), z=r2(e.z))
            return
        now, tag = self.now, sk.get('tag')
        dmg, crit = self._roll(p, mult, tag) if mult > 0 else (0, False)
        combo, status = (None, None) if splash or mult <= 0 or now < e.combo_at else find_combo(e.status, tag)
        burst = 0
        if combo:
            e.combo_at = now + 1.0                     # derselbe Gegner ist kurz nicht erneut kombinierbar
            st = e.status.pop(status)
            bonus = combo['bonus'] * p.stats['combo']
            if combo.get('execute') and e.hp < e.max_hp * 0.35:
                bonus *= combo['execute']
            if combo.get('crit') and not crit:
                crit, dmg = True, dmg * p.stats['critdmg']
            if combo.get('burst') and st.get('dps'):
                burst = st['dps'] * max(0.0, st['until'] - now) * combo['burst']
            dmg = dmg * (1 + bonus) + burst
        dmg *= 1 + sum(STATUS[s].get('vuln', 0) for s in e.status)
        if sk.get('execute') and e.hp < e.max_hp * 0.35:
            dmg *= 1.5
        if dmg > 0:
            self._damage_enemy(e, p, max(1, round(dmg)), crit)
            steal = p.buffv('lifesteal', now)
            if steal and not p.dead:
                p.hp = min(p.max_hp, p.hp + dmg * steal)
        elif not e.target and W.in_rect(p.x, p.z, e.zone['leash']):
            self._engage(e, p)
        if combo:
            self._combo_effect(p, e, combo)
        if e.dead:
            return
        if sk.get('apply'):
            self._apply(e, sk['apply'], p)
        if sk.get('stun'):
            self._stun(e, sk['stun'])
        if sk.get('slow'):
            e.slow_until, e.slow_f = now + sk['slow'], sk.get('slow_f', 0.5)
        if sk.get('weaken'):
            e.weak_until = now + sk['weaken']

    def _combo_effect(self, p, e, combo):
        self._fx(t='combo', x=r2(e.x), z=r2(e.z), k=combo['id'])
        self._quest_progress(p, 'combo', 'any')
        if combo.get('stun') and not e.dead:
            self._stun(e, combo['stun'])
        if combo.get('apply') and not e.dead:
            self._apply(e, combo['apply'], p)
        aoe = combo.get('aoe')
        if aoe:
            extra = {'tag': aoe['tag'], 'apply': aoe.get('apply')}
            self._fx(t='ring', x=r2(e.x), z=r2(e.z), r=aoe['r'], c=TAGS[aoe['tag']]['color'])
            for o in list(self.enemies.values()):
                if o is not e and not o.dead and hypot(o.x - e.x, o.z - e.z) <= aoe['r'] + o.radius:
                    self._strike(p, o, aoe['mult'], extra, splash=True)
        chain = combo.get('chain')
        if chain:
            self._chain(p, e.x, e.z, chain['n'], chain['mult'], {'tag': chain['tag']}, chain['r'], skip={e.id})

    def _chain(self, p, x, z, n, mult, sk, jump, skip=(), first=None):
        """Blitz, der von Gegner zu Gegner springt. Liefert die getroffenen Punkte für die Darstellung."""
        pts, hit = [[r2(x), r2(z)]], set(skip)
        target = first
        for _ in range(n):
            if target is None:
                near = [o for o in self.enemies.values() if not o.dead and o.id not in hit
                        and hypot(o.x - x, o.z - z) <= jump and self._can_hit(o, p)]
                if not near:
                    break
                target = min(near, key=lambda o: hypot(o.x - x, o.z - z))
            hit.add(target.id)
            x, z = target.x, target.z
            pts.append([r2(x), r2(z)])
            self._strike(p, target, mult, sk, splash=first is None)
            target, first = None, None
        if len(pts) > 1:
            self._fx(t='bolt', pts=pts, c=TAGS['blitz']['color'])
        return len(pts) - 1

    def _apply(self, e, status, p):
        """Setzt einen Zustand auf einen Gegner (oder frischt ihn auf)."""
        s = STATUS[status]
        dur = s['dur'] * p.stats['statusdur']
        dps = s.get('dot', 0) * p.stats['power'] * (1 + p.dot_bonus.get(status, 0))
        e.status[status] = {'until': self.now + dur, 'src': p.sid, 'dps': round(dps), 'next': self.now + 1.0}

    def _stun(self, e, seconds):
        now = self.now
        if e.boss or now < e.stun_free_until:
            return
        e.stun_until = max(e.stun_until, now + seconds)
        e.stun_free_until = e.stun_until + 3.0
        e.windup_until = 0.0

    def _damage_enemy(self, e, p, dmg, crit=False, dot=None):
        """Zieht einem Gegner Leben ab. p ist der Verursacher (None, wenn er die Burg verlassen hat)."""
        if e.dead:
            return
        if p and not dot:
            inside = W.in_rect(p.x, p.z, e.zone['leash'])
            if inside and (not e.target or e.state == 'return'):
                self._engage(e, p)
            p.last_combat = self.now
        e.hp -= dmg
        fx = {'t': 'dmg', 'id': e.id, 'x': r2(e.x), 'z': r2(e.z), 'v': dmg}
        if crit:
            fx['c'] = 1
        if dot:
            fx['s'] = dot
        self._fx(**fx)
        if e.hp <= 0:
            self._kill(e, p)
        elif p and not dot and not e.target:
            # Angreifer steht außerhalb der Zone: Gegner zieht sich zurück und erholt sich
            e.state, e.ignore_until, e.return_since = 'return', self.now + 1.5, self.now

    def _engage(self, e, p):
        """Gegner nimmt den Kampf auf. Ein fester Boss wird zäher, je mehr Helden in seinem Gebiet stehen."""
        if e.boss and not e.zone['dungeon'] and e.state == 'idle' and e.hp >= e.max_hp:
            leash = e.zone['leash']
            n = sum(1 for o in self.players.values() if not o.dead and W.in_rect(o.x, o.z, leash))
            e.max_hp = round(e.base_hp * (1 + 0.7 * (min(max(n, 1), 6) - 1)))
            e.hp = e.max_hp
        e.target, e.state = p.sid, 'chase'

    def _hurt(self, p, dmg):
        if p.dead:
            return
        now = self.now
        dmg = dmg * (1 - min(0.85, p.stats['armor'] + p.buffv('armor', now)))
        if p.shield > 0 and now < p.shield_until:
            soak = min(p.shield, dmg)
            p.shield -= soak
            dmg -= soak
            if dmg <= 0.5:
                self._fx(t='block', id=p.id)
                return
        dmg = max(1, round(dmg))
        p.hp -= dmg
        p.last_combat = now
        self._fx(t='dmg', id=p.id, x=r2(p.x), z=r2(p.z), v=dmg, p=1)
        if p.hp <= 0:
            p.hp = 0
            p.dead = True
            p.respawn_at = now + RESPAWN_TIME
            p.buffs.clear()
            p.shield = 0
            p.dirty = True
            self._fx(t='pdie', id=p.id)
            self._sys(f'{p.name} ist gefallen.')

    def _heal(self, p, amount, source=None):
        if p.dead:
            return
        amount = min(round(amount * (source.stats['heal'] if source else 1.0)), round(p.max_hp - p.hp))
        if amount > 0:
            p.hp += amount
            self._fx(t='heal', id=p.id, v=amount)

    def _allies(self, x, z, radius):
        return [o for o in self.players.values() if not o.dead and hypot(o.x - x, o.z - z) <= radius]

    def _aoe(self, p, x, z, radius, mult, sk):
        for e in list(self.enemies.values()):
            if not e.dead and hypot(e.x - x, e.z - z) <= radius + e.radius:
                self._strike(p, e, mult, sk)

    def _buff(self, p, key, dur, mods):
        p.buffs[key] = {'until': self.now + dur, **mods}
        p.dirty = True

    # ------------------------------------------------------------ Grundangriff
    def on_attack(self, sid, d):
        with self.lock:
            p = self.players.get(sid)
            now = time.time()
            if not p or p.dead or now < p.next_atk - 0.06:
                return
            self.now = now
            a = CLASSES[p.cls]['atk']
            p.next_atk = now + p.atk_cd(now)
            dx, dz, _ = self._aim(p, d)
            p.rot = math.atan2(dx, dz)
            p.last_combat = now
            basic = {'tag': a['tag'], 'basic': True}
            if a['type'] == 'melee':
                self._fx(t='slash', id=p.id, x=r2(p.x), z=r2(p.z), a=r2(p.rot), r=a['range'], w=a['arc'])
                self._arc(p, a['range'], a['arc'], 1.0, basic)
            else:
                self._fx(t='atk', id=p.id, k='shoot' if CLASSES[p.cls]['style'] == 'bogen' else 'cast')
                self._shoot(p, dx, dz, basic, 1.0, a['kind'], a['speed'], a['range'], splash=a['splash'])

    def _arc(self, p, rng, arc, mult, sk):
        for e in list(self.enemies.values()):
            if e.dead:
                continue
            ex, ez = e.x - p.x, e.z - p.z
            dist = hypot(ex, ez)
            if dist > rng + e.radius:
                continue
            if dist > 1.0:
                diff = abs((math.atan2(ex, ez) - p.rot + math.pi) % (2 * math.pi) - math.pi)
                if diff > arc / 2:
                    continue
            self._strike(p, e, mult, sk)

    def _shoot(self, p, dx, dz, sk, mult, kind, speed, rng, splash=0.0, pierce=False, size=0.3):
        self.projs.append({'id': self._id(), 'kind': kind, 'owner': p.sid, 'x': p.x + dx * 0.7, 'z': p.z + dz * 0.7,
                           'dx': dx, 'dz': dz, 'speed': speed, 'left': rng, 'sk': sk, 'mult': mult, 'splash': splash,
                           'pierce': pierce, 'hit': set(), 'r': size, 'c': color_of(sk), 'map': W.map_at(p.x, p.z)})

    # ------------------------------------------------------------- Fähigkeiten
    def on_skill(self, sid, d):
        """Wirkt die Fähigkeit auf Taste d['n'] (1–4). Antwort an den Browser: ok und Abklingzeit."""
        with self.lock:
            p = self.players.get(sid)
            now = time.time()
            try:
                slot = int(d.get('n', 0))
            except (TypeError, ValueError):
                return {'ok': False}
            if not p or p.dead or not 1 <= slot <= BAR_SLOTS:
                return {'ok': False}
            key = p.bar[slot - 1]
            sk, rank = SKILLS.get(key), p.skills.get(key, 0)
            if not sk or rank < 1 or sk['type'] != 'active':
                return {'ok': False}
            left = p.cds.get(key, 0) - now
            if left > 0.06:
                return {'ok': False, 'cd': r2(left)}
            if p.res < sk['cost']:
                return {'ok': False, 'why': 'res'}
            self.now = now
            cd = sk['cd'] * (1 - p.stats['cdr'])
            p.cds[key] = now + cd
            p.res -= sk['cost']
            p.last_combat = now
            dx, dz, dist = self._aim(p, d)
            p.rot = math.atan2(dx, dz)
            self._cast(p, sk, rank, dx, dz, dist)
            return {'ok': True, 'cd': r2(cd)}

    def _cast(self, p, sk, rank, dx, dz, dist):
        now, form, col = self.now, sk['form'], color_of(sk)
        power = 1 + RANK_BONUS * (rank - 1)
        mult = sk.get('mult', 0) * power
        anim, style = 'cast', CLASSES[p.cls]['style']
        if form == 'arc':
            anim = 'melee' if style == 'klinge' else 'cast'
            self._fx(t='slash', id=p.id, x=r2(p.x), z=r2(p.z), a=r2(p.rot), r=sk['range'], w=sk['arc'], c=col, sk=1)
            for i in range(sk.get('hits', 1)):
                if i == 0:
                    self._arc(p, sk['range'], sk['arc'], mult, sk)
                else:
                    self._after(0.13 * i, lambda: None if p.dead else self._arc(p, sk['range'], sk['arc'], mult, sk))
        elif form == 'nova':
            anim = 'cast' if style == 'magie' else 'spin'
            self._fx(t='ring', x=r2(p.x), z=r2(p.z), r=sk['r'], c=col)
            self._aoe(p, p.x, p.z, sk['r'], mult, sk)
            if sk.get('fade'):
                for e in self.enemies.values():
                    if e.target == p.sid and not e.boss:
                        e.target, e.ignore_until = None, now + 2.5
        elif form == 'shot':
            anim = 'shoot' if style == 'bogen' else 'cast'
            n, spread, base = sk.get('count', 1), sk.get('spread', 0), math.atan2(dx, dz)
            for i in range(n):
                a = base + (i - (n - 1) / 2) * spread
                self._shoot(p, math.sin(a), math.cos(a), sk, mult, sk.get('kind', 'arrow'), sk['speed'], sk['range'],
                            splash=sk.get('splash', 0.0), pierce=sk.get('pierce', False), size=sk.get('size', 0.3))
        elif form == 'blast':
            if sk.get('at_self'):
                x, z = p.x, p.z
            else:
                dist = min(dist, sk['range'])
                x, z = p.x + dx * dist, p.z + dz * dist
            self._fx(t='tele', x=r2(x), z=r2(z), r=sk['r'], d=sk['delay'], c=col, fall=int(bool(sk.get('falling'))))
            self._after(sk['delay'], lambda: self._blast(p, x, z, sk, mult))
        elif form == 'zone':
            if sk.get('at_self') or sk.get('follow'):
                x, z = p.x, p.z
            else:
                dist = min(dist, sk['range'])
                x, z = p.x + dx * dist, p.z + dz * dist
            dur = sk['dur'] * (1 + 0.1 * (rank - 1))
            self.zones.append({'id': self._id(), 'x': x, 'z': z, 'r': sk['r'], 'until': now + dur, 'tick': sk['tick'],
                               'next': now + 0.15, 'owner': p.sid, 'sk': sk, 'mult': mult, 'power': power, 'c': col,
                               'follow': bool(sk.get('follow')), 'map': W.map_at(p.x, p.z)})
        elif form == 'dash':
            anim = 'melee'
            reach = min(dist, sk['dist']) if sk.get('leap') else sk['dist']
            x0, z0 = p.x, p.z
            x, z, step = p.x, p.z, 0.25
            for _ in range(int(reach / step)):
                if W.blocked(x + dx * step, z + dz * step, PLAYER_RADIUS):
                    break
                x, z = x + dx * step, z + dz * step
            self._teleport(p, x, z, dash=True)
            self._fx(t='dash', id=p.id, x0=r2(x0), z0=r2(z0), x=r2(x), z=r2(z), c=col)
            if sk.get('r'):
                self._fx(t='ring', x=r2(x), z=r2(z), r=sk['r'], c=col)
                self._aoe(p, x, z, sk['r'], mult, sk)
            if sk.get('mods'):
                self._buff(p, sk['id'], sk['dur'] * (1 + 0.1 * (rank - 1)), sk['mods'])
                self._fx(t='buff', id=p.id, c=col)
        elif form == 'chain':
            first, best = None, 0.6
            for e in self.enemies.values():
                ex, ez = e.x - p.x, e.z - p.z
                ed = hypot(ex, ez)
                if e.dead or ed > sk['range'] + e.radius or not W.shot_los(p.x, p.z, e.x, e.z):
                    continue
                diff = abs((math.atan2(ex, ez) - p.rot + math.pi) % (2 * math.pi) - math.pi)
                if diff < best or ed < 1.5:
                    first, best = e, min(diff, best)
            if first:
                self._chain(p, p.x, p.z, sk['n'] + (rank - 1) // 2, mult, sk, sk['jump'], first=first)
            else:
                self._fx(t='bolt', pts=[[r2(p.x), r2(p.z)], [r2(p.x + dx * sk['range'] * 0.6), r2(p.z + dz * sk['range'] * 0.6)]], c=col)
        elif form == 'buff':
            dur = sk['dur'] * (1 + 0.1 * (rank - 1))
            targets = self._allies(p.x, p.z, sk['r']) if sk.get('r') else [p]
            if sk.get('r'):
                self._fx(t='ring', x=r2(p.x), z=r2(p.z), r=sk['r'], c=col, soft=1)
            for o in targets:
                if sk.get('mods'):
                    self._buff(o, sk['id'], dur, sk['mods'])
                if sk.get('absorb'):
                    o.shield, o.shield_until = o.max_hp * sk['absorb'] * power, now + dur
                self._fx(t='buff', id=o.id, c=col)
            if sk.get('taunt'):
                self._fx(t='ring', x=r2(p.x), z=r2(p.z), r=sk['taunt'], c='#ea7d66', soft=1)
                for e in self.enemies.values():
                    if not e.dead and hypot(e.x - p.x, e.z - p.z) <= sk['taunt'] and W.in_rect(p.x, p.z, e.zone['leash']):
                        self._engage(e, p)
        elif form == 'heal':
            self._fx(t='ring', x=r2(p.x), z=r2(p.z), r=sk['r'], c=col, soft=1)
            for o in self._allies(p.x, p.z, sk['r']):
                self._heal(o, o.max_hp * sk['pct'] * power, p)
        self._fx(t='atk', id=p.id, k=anim)

    def _blast(self, p, x, z, sk, mult):
        self._fx(t='boom', x=r2(x), z=r2(z), r=sk['r'], c=color_of(sk), big=1)
        if p.sid in self.players:
            self._aoe(p, x, z, sk['r'], mult, sk)

    # ------------------------------------------------------- Stufen und Punkte
    def _gain_xp(self, p, amount):
        if p.level >= MAX_LEVEL:
            return
        amount = round(amount * (1 + p.buffv('xp', self.now)))
        p.xp += amount
        while p.level < MAX_LEVEL and p.xp >= xp_needed(p.level):
            p.xp -= xp_needed(p.level)
            p.level += 1
            p.recalc()
            p.hp, p.res = float(p.max_hp), float(p.stats['res'])
            self._fx(t='lvl', id=p.id, lvl=p.level)
            if p.level % 5 == 0 or p.level <= 10:
                self._sys(f'{p.name} hat Stufe {p.level} erreicht!')
            self._toast(p, f'Stufe {p.level}: {ATTR_POINTS} Attributpunkte (C) und 1 Fähigkeitspunkt (K)', 'level')
        if p.level >= MAX_LEVEL:
            p.xp = 0
        p.dirty = True

    def on_attr(self, sid, d):
        with self.lock:
            p = self.players.get(sid)
            key = d.get('k')
            if not p or key not in ATTRS:
                return
            n = max(1, min(int(num(d, 'n', 1)), p.ap()))
            if p.ap() < 1:
                return
            p.attrs[key] += n
            p.recalc()
            p.dirty = True

    def on_learn(self, sid, d):
        with self.lock:
            p = self.players.get(sid)
            sk = SKILLS.get(d.get('id'))
            if not p or not sk or sk['cls'] != p.cls:
                return
            rank = p.skills.get(sk['id'], 0)
            if rank >= MAX_RANK or p.sp() < 1 or p.level < sk['lvl']:
                return
            if rank == 0 and p.branch_points(sk['branch']) < sk['need']:
                return
            p.skills[sk['id']] = rank + 1
            if rank == 0 and sk['type'] == 'active' and None in p.bar:
                p.bar[p.bar.index(None)] = sk['id']
            p.recalc()
            p.dirty = True
            self._fx(t='questdone', id=p.id)

    def on_bind(self, sid, d):
        """Legt eine gelernte aktive Fähigkeit auf eine der Tasten 1–4 (id None leert die Taste)."""
        with self.lock:
            p = self.players.get(sid)
            try:
                slot = int(d.get('slot', 0))
            except (TypeError, ValueError):
                return
            key = d.get('id')
            if not p or not 1 <= slot <= BAR_SLOTS:
                return
            if key is None:
                p.bar[slot - 1] = None
            elif key in p.skills and SKILLS[key]['type'] == 'active':
                if key in p.bar:                               # schon belegt -> Plätze tauschen
                    p.bar[p.bar.index(key)] = p.bar[slot - 1]
                p.bar[slot - 1] = key
            p.dirty = True

    # ------------------------------------------------------------------ Quests
    def _wants(self, p, typ, target):
        for qid, st in p.quests.items():
            q = QUESTS[qid]
            if st.get('s') == 'active' and q['type'] == typ and q['target'] in (target, 'any'):
                return True
        return False

    def _quest_progress(self, p, typ, target, value=None, map_id=None):
        """Zählt aktive Quests weiter. target: Gegnerart, Questgegenstand oder Karte; value setzt einen Stand (Tiefe)."""
        for qid, st in p.quests.items():
            q = QUESTS[qid]
            if st.get('s') != 'active' or q['type'] != typ:
                continue
            if q['target'] not in (target, 'any') and not (map_id and q['target'] == 'map:' + map_id):
                continue
            st['n'] = min(q['count'], max(st.get('n', 0), value) if value is not None else st.get('n', 0) + 1)
            if st['n'] >= q['count']:
                st['s'] = 'ready'
                npc = W.NPCS[q['npc']]['name']
                self._toast(p, f'{q["title"]} erfüllt – kehre zu {npc} zurück', 'quest')
            p.dirty = True

    def _quest_open(self, p, qid):
        q = QUESTS[qid]
        st = p.quests.get(qid)
        if st and not (st.get('s') == 'done' and q.get('repeat')):
            return False
        if p.level < q['minlvl']:
            return False
        return not q['req'] or p.quests.get(q['req'], {}).get('s') == 'done'

    def _near_npc(self, p, npc):
        n = W.NPCS.get(npc)
        return bool(n) and hypot(p.x - n['x'] * W.TILE, p.z - n['z'] * W.TILE) <= 7.0

    def on_quest(self, sid, d):
        with self.lock:
            p = self.players.get(sid)
            qid = d.get('id')
            if not p or p.dead or qid not in QUESTS:
                return
            q = QUESTS[qid]
            if not self._near_npc(p, q['npc']):
                return
            if d.get('do') == 'accept' and self._quest_open(p, qid):
                start = min(q['count'], p.deepest.get(q['target'], 0)) if q['type'] == 'depth' else 0
                p.quests[qid] = {'s': 'ready' if q['type'] == 'depth' and start >= q['count'] else 'active', 'n': start}
                self._toast(p, f'Quest angenommen: {q["title"]}', 'quest')
            elif d.get('do') == 'turnin' and p.quests.get(qid, {}).get('s') == 'ready':
                xp = q.get('xp') or round(xp_needed(p.level) * q.get('xp_pct', 0))
                gold = q.get('gold') or q.get('gold_lvl', 0) * p.level
                p.quests[qid] = {'s': 'done', 'n': q['count']}
                p.gold += gold
                p.potions = min(POTION_MAX, p.potions + q.get('potions', 0))
                p.weapon = min(GEAR_MAX, p.weapon + q.get('weapon', 0))
                p.recalc()
                self._toast(p, f'Quest abgeschlossen: {q["title"]}  +{xp} EP, +{gold} Gold', 'quest')
                self._fx(t='questdone', id=p.id)
                self._gain_xp(p, xp)
                self._save_all()
            p.dirty = True

    def on_shop(self, sid, d):
        with self.lock:
            p = self.players.get(sid)
            npc, item = d.get('npc'), d.get('item')
            if not p or p.dead or item not in W.NPCS.get(npc, {}).get('services', ()) or not self._near_npc(p, npc):
                return
            self.now = time.time()
            poor = lambda price: p.gold < price and (self._toast(p, 'Dafür reicht dein Gold nicht.', 'warn') or True)
            if item == 'potion':
                price = potion_price(p.level)
                if p.potions >= POTION_MAX:
                    self._toast(p, 'Mehr Tränke kannst du nicht tragen.', 'warn')
                elif not poor(price):
                    p.gold -= price
                    p.potions += 1
                    self._toast(p, 'Heiltrank gekauft', 'loot')
            elif item in ('weapon', 'armor'):
                tier = getattr(p, item)
                if tier >= GEAR_MAX:
                    self._toast(p, f'Besser kann {W.NPCS[npc]["name"]} das nicht mehr machen.', 'warn')
                elif not poor(gear_price(tier)):
                    p.gold -= gear_price(tier)
                    setattr(p, item, tier + 1)
                    p.recalc()
                    self._toast(p, f'{"Waffe" if item == "weapon" else "Rüstung"} geschmiedet: Stufe {tier + 1}', 'loot')
                    self._fx(t='questdone', id=p.id)
            elif item == 'heal':
                self._heal(p, p.max_hp)
            elif item == 'elixir':
                kind = d.get('kind')
                if kind in ELIXIRS and not poor(elixir_price(p.level)):
                    p.gold -= elixir_price(p.level)
                    p.elixirs[kind] = max(p.elixirs.get(kind, 0), self.now) + ELIXIR_TIME     # Dauer stapelt sich
                    self._toast(p, f'{ELIXIRS[kind]["name"]}: {ELIXIRS[kind]["desc"]}', 'loot')
                    self._fx(t='buff', id=p.id, c='#c58bff')
            elif item == 'respec':
                if not poor(respec_price(p.level)):
                    p.gold -= respec_price(p.level)
                    p.reset_build()
                    p.buffs.clear()
                    p.recalc()
                    self._toast(p, 'Attribute und Fähigkeiten sind zurückgesetzt – verteile deine Punkte neu.', 'level')
            elif item == 'dungeon':                             # Start-Ebene des Verlieses auf der Karte des Bewohners
                mid = W.NPCS[npc]['map']
                dg, depth = self.dungeons[mid], int(num(d, 'depth', 1))
                if dg['phase'] != 'idle':
                    self._toast(p, 'Im Verlies wird gerade gekämpft – geh einfach hinein.', 'warn')
                elif depth in self._entries(p, mid):
                    dg['start'] = depth
                    for o in self.players.values():
                        if W.map_at(o.x, o.z) == mid:
                            self._toast(o, f'Das Verlies erwacht auf Ebene {depth}, sobald jemand es betritt.', 'quest')
            p.dirty = True

    def on_potion(self, sid):
        with self.lock:
            p = self.players.get(sid)
            now = time.time()
            if not p or p.dead or p.potions <= 0 or p.hp >= p.max_hp or now < p.cds.get('potion', 0) - 0.06:
                return
            self.now = now
            p.cds['potion'] = now + POTION_CD
            p.potions -= 1
            self._heal(p, p.max_hp * POTION_HEAL)
            p.dirty = True

    def on_chat(self, sid, d):
        with self.lock:
            p = self.players.get(sid)
            now = time.time()
            text = re.sub(r'\s+', ' ', str(d.get('text', ''))).strip()[:200]
            if not p or not text or now - p.last_chat < 0.4:
                return
            p.last_chat = now
            if self.dev and text.startswith('/') and self._dev_command(p, text):
                return
            self.emit('chat', {'name': p.name, 'cls': p.cls, 'text': text})

    def _dev_command(self, p, text):
        """Hilfsbefehle für Entwickler – nur aktiv, wenn RABENFELS_DEV=1 gesetzt ist."""
        parts = text.split()
        try:
            here = W.map_at(p.x, p.z) or W.MAIN
            if parts[0] == '/tp' and len(parts) in (3, 4):          # /tp x z  oder  /tp karte x z
                mid = parts[1] if len(parts) == 4 else here
                if mid in W.MAPS:
                    x, z = W.to_world(mid, float(parts[-2]), float(parts[-1]))
                    if not W.blocked(x, z, PLAYER_RADIUS):
                        self._teleport(p, x, z)
            elif parts[0] == '/lvl' and len(parts) == 2:
                p.level = max(1, min(MAX_LEVEL, int(parts[1])))
                p.xp = 0
                p._check_build()
                p.recalc()
                p.hp, p.res = float(p.max_hp), float(p.stats['res'])
            elif parts[0] == '/gold' and len(parts) == 2:
                p.gold = max(0, int(parts[1]))
            elif parts[0] == '/tiefe' and len(parts) == 2:           # tiefste geschaffte Ebene im Verlies dieser Karte
                mid = here if here in self.dungeons else next(iter(self.dungeons), None)
                if mid:
                    p.deepest[mid] = max(0, int(parts[1]))
            elif parts[0] == '/beute' and len(parts) in (1, 2):      # Ringe und Amulette deiner Stufe
                for _ in range(max(1, min(BAG_MAX, int(parts[1]) if len(parts) == 2 else 3))):
                    self._give_item(p, self._make_item(p.level, floor=random.randint(0, len(RARITIES) - 1)))
            elif parts[0] == '/elite' and len(parts) == 1:           # nächster fester Gegner wird Elite
                foes = [e for e in self.enemies.values() if not e.dead and not e.boss and not e.temp and not e.d.get('scale')
                        and e.zone['map'] == here]
                if foes:
                    e = min(foes, key=lambda e: hypot(e.x - p.x, e.z - p.z))
                    self._roll_elite(e, random.choice(list(ELITE_AFFIXES)))
                    e.dead, e.respawn_at = True, self.now            # kommt sofort als Elite wieder
                    self._fx(t='edie', id=e.id, x=r2(e.x), z=r2(e.z), k=e.kind)
                    e.elite_next = e.elite
            else:
                return False
        except ValueError:
            return False
        p.dirty = True
        return True

    # ------------------------------------------------------------- Gegner: Tod
    def _kill(self, e, killer):
        e.dead = True
        e.target = None
        e.hp = 0
        e.status = {}
        e.respawn_at = self.now + e.d.get('respawn', 0)
        if e.temp:
            e.gone = True
        self._fx(t='edie', id=e.id, x=r2(e.x), z=r2(e.z), k=e.kind)
        heroes = []
        hall = e.zone['leash'] if e.zone['dungeon'] else None       # im Verlies teilen alle, die in der Halle stehen
        for p in self.players.values():
            close = hypot(p.x - e.x, p.z - e.z) <= SHARE_RADIUS or (hall and W.in_rect(p.x, p.z, hall))
            if p is not killer and (p.dead or not close):
                continue
            heroes.append(p.name)
            diff = p.level - e.level
            mult = 1.0 if diff < 5 else 0.6 if diff < 10 else 0.25
            bonus = ELITE_REWARD if e.elite else 1.0
            xp = max(1, round(e.xp * mult * bonus))
            gold = round(random.randint(*e.gold) * bonus)
            p.gold += gold
            self._fx(t='loot', id=p.id, xp=xp, gold=gold)
            if random.random() < 0.1 and p.potions < POTION_MAX:
                p.potions += 1
                self._toast(p, 'Heiltrank gefunden', 'loot')
            if p is killer and p.stats['killheal'] and not p.dead:
                p.hp = min(p.max_hp, p.hp + p.max_hp * p.stats['killheal'])
            self._gain_xp(p, xp)
            self._quest_progress(p, 'kill', e.kind, map_id=e.zone['map'])
            chance = DROP_CHANCE['boss' if e.boss else 'elite' if e.elite else 'normal']
            if diff < 10 and random.random() < chance:              # zu leichte Gegner lassen nichts fallen
                self._give_item(p, self._make_item(e.level, floor=1 if e.boss else 0), e)
            p.dirty = True
        if e.boss and not e.zone['dungeon']:                     # fester Boss: seine Diener vergehen mit ihm
            for o in self.enemies.values():
                if o.temp and not o.dead and o.zone is e.zone and o is not e:
                    o.dead = o.gone = True
                    self._fx(t='edie', id=o.id, x=r2(o.x), z=r2(o.z), k=o.kind)
            self._sys(f'{e.d["name"]} wurde bezwungen von {", ".join(heroes)}!')

    # ------------------------------------------------------------------ Beute
    def _make_item(self, ilvl, floor=0):
        """Ein Ring oder Amulett der Stufe ilvl mit zufälligen Werten. floor: Mindest-Seltenheit."""
        weights = [r[4] for r in RARITIES]
        rar = max(floor, random.choices(range(len(RARITIES)), weights)[0])
        _, _, n, f, _, _ = RARITIES[rar]
        slot = random.choice(list(ITEM_SLOTS))
        stats = random.sample(list(ITEM_STATS), n)
        scale = item_scale(ilvl) * f
        mods = {k: round(ITEM_STATS[k][1] * scale * random.uniform(0.7, 1.15), 4) for k in stats}
        return {'slot': slot, 'name': f'{ITEM_SLOTS[slot]} {ITEM_STATS[stats[0]][2]}', 'lvl': ilvl, 'rar': rar, 'mods': mods}

    def _item_value(self, it):
        return max(1, it['lvl'] * RARITIES[it['rar']][5])

    def _give_item(self, p, it, src=None):
        name, rar = it['name'], RARITIES[it['rar']]
        if len(p.bag) >= BAG_MAX:
            gold = self._item_value(it)
            p.gold += gold
            self._toast(p, f'Tasche voll – {name} für {gold} Gold verkauft.', 'warn')
        else:
            p.bag.append(it)
            self._toast(p, f'Beute: {name} ({rar[0]}) – im Charakterbogen (C)', 'loot')
        if src is not None:
            self._fx(t='drop', x=r2(src.x), z=r2(src.z), c=rar[1], rar=it['rar'])
        if it['rar'] >= 2:
            self._sys(f'{p.name} hat {name} gefunden ({rar[0]})!')
        p.dirty = True

    def on_item(self, sid, d):
        """Ring oder Amulett anlegen, ablegen oder verkaufen."""
        with self.lock:
            p = self.players.get(sid)
            if not p:
                return
            act, i, slot = d.get('act'), d.get('i'), d.get('slot')
            if act in ('equip', 'sell') and not (isinstance(i, int) and 0 <= i < len(p.bag)):
                return
            if act == 'equip':
                it = p.bag.pop(i)
                old = p.items.get(it['slot'])
                p.items[it['slot']] = it
                if old:
                    p.bag.insert(i, old)
            elif act == 'unequip' and p.items.get(slot):
                if len(p.bag) >= BAG_MAX:
                    self._toast(p, 'Deine Tasche ist voll.', 'warn')
                    return
                p.bag.append(p.items[slot])
                p.items[slot] = None
            elif act == 'sell':
                it = p.bag.pop(i)
                p.gold += self._item_value(it)
                self._toast(p, f'{it["name"]} für {self._item_value(it)} Gold verkauft.', 'loot')
            else:
                return
            hp_share = p.hp / max(1, p.max_hp)
            p.recalc()
            p.hp = min(p.max_hp, p.max_hp * hp_share)
            p.dirty = True

    # ----------------------------------------------------------------- Gegner
    def _steer(self, e, tx, tz, speed, dt):
        gx, gz = tx, tz
        if self.now < e.path_until or not W.los(e.x, e.z, tx, tz):
            if self.now >= e.path_next:
                e.path_next = self.now + 0.3
                e.waypoint = W.next_step(e.x, e.z, tx, tz)
            if e.waypoint:
                gx, gz = e.waypoint
        dx, dz = gx - e.x, gz - e.z
        dist = hypot(dx, dz)
        if dist < 1e-3:
            return
        step = min(speed * dt, dist)
        ox, oz = e.x, e.z
        nx, nz = e.x + dx / dist * step, e.z + dz / dist * step
        if not W.blocked(nx, e.z, e.radius_c):
            e.x = nx
        if not W.blocked(e.x, nz, e.radius_c):
            e.z = nz
        e.rot = math.atan2(dx, dz)
        if hypot(e.x - ox, e.z - oz) < step * 0.3:
            e.path_until = self.now + 1.0            # hängt fest -> eine Weile über Wegpunkte laufen

    def _tick_status(self, e):
        """Zustände laufen ab; Brand, Blutung und Gift richten jede Sekunde Schaden an."""
        now = self.now
        for name in list(e.status):
            st = e.status.get(name)
            if not st:
                continue
            if st['dps'] and now >= st['next'] and st['next'] <= st['until'] + 1e-6:
                st['next'] += 1.0
                self._damage_enemy(e, self.players.get(st['src']), max(1, st['dps']), dot=name)
                if e.dead:
                    return
            if now >= st['until']:
                e.status.pop(name, None)

    def _enemy_dmg(self, e):
        f = random.uniform(0.85, 1.15)
        for name in e.status:
            f *= 1 - STATUS[name].get('weak', 0)
        if self.now < e.weak_until:
            f *= 0.75
        return e.dmg * f * e.dmg_f

    def _update_enemy(self, e, dt):
        now, d = self.now, e.d
        if e.dead:
            if not e.temp and now >= e.respawn_at:
                forced = getattr(e, 'elite_next', None)
                e.reset()
                e.elite_next = None
                self._roll_elite(e, forced)
                self._fx(t='spawn', x=r2(e.x), z=r2(e.z))
            return
        if e.status:
            self._tick_status(e)
            if e.dead:
                return
        leash = e.zone['leash']
        t = self.players.get(e.target) if e.target else None
        if e.target and (not t or t.dead or not W.in_rect(t.x, t.z, leash)):
            t, e.target = None, None
            e.state, e.ignore_until, e.return_since = 'return', now + 1.5, now
            e.windup_until = e.cast_until = 0.0
        if now < e.stun_until:
            return
        if not t and now >= e.ignore_until:
            best, bd = None, d['aggro']
            for p in self.players.values():
                if p.dead or not W.in_rect(p.x, p.z, leash):
                    continue
                dist = hypot(p.x - e.x, p.z - e.z)
                if dist < bd and (dist < 3.0 or d['aggro'] >= 40 or W.los(e.x, e.z, p.x, p.z)):
                    best, bd = p, dist
            if best:
                t = best
                self._engage(e, best)
        speed = d['speed'] * e.speed_f
        for name in e.status:
            slow = STATUS[name].get('slow')
            if slow:
                speed *= max(slow, 0.75) if e.boss else slow
        if now < e.slow_until:
            speed *= max(e.slow_f, 0.6) if e.boss else e.slow_f

        if t:
            dx, dz = t.x - e.x, t.z - e.z
            dist = hypot(dx, dz)
            if e.boss and self._boss_ai(e, t):
                return
            if e.windup_until:
                e.rot = math.atan2(dx, dz)
                if now >= e.windup_until:
                    e.windup_until = 0.0
                    if d.get('shot'):
                        self.projs.append({'id': self._id(), 'kind': 'dark', 'hostile': True, 'x': e.x + dx / max(dist, 0.1) * 0.6,
                                           'z': e.z + dz / max(dist, 0.1) * 0.6, 'dx': dx / max(dist, 0.1), 'dz': dz / max(dist, 0.1),
                                           'speed': d['shot'], 'left': d['range'] + 4, 'dmg': self._enemy_dmg(e), 'r': 0.35, 'c': '#b38cff',
                                           'map': e.zone['map']})
                    elif dist <= d['range'] + 1.0:
                        dmg = self._enemy_dmg(e)
                        self._hurt(t, dmg)
                        if e.leech and not e.dead:                  # blutdurstige Elite heilt sich
                            e.hp = min(e.max_hp, e.hp + dmg * e.leech)
                return
            if dist <= d['range'] and (not d.get('shot') or W.shot_los(e.x, e.z, t.x, t.z)):
                e.rot = math.atan2(dx, dz)
                if now >= e.next_atk:
                    e.next_atk = now + d['cd'] * e.cd_f
                    e.windup_until = now + (0.55 if d.get('shot') else 0.35)
                    self._fx(t='eatk', id=e.id, **({'k': 'cast'} if d.get('shot') else {}))
                return
            self._steer(e, t.x, t.z, speed, dt)
            return

        hx, hz = e.home
        if e.state == 'return':
            e.hp = min(e.max_hp, e.hp + e.max_hp * 0.3 * dt)
            if hypot(hx - e.x, hz - e.z) < 0.7 or now - e.return_since > 8.0:
                e.x, e.z = hx, hz
                e.state, e.hp = 'idle', e.max_hp
                if e.boss and not e.zone['dungeon']:
                    self._boss_reset(e)
            else:
                self._steer(e, hx, hz, speed * 1.3, dt)
            return
        # Gemächlich um den Heimatpunkt wandern
        if now >= e.wander_at and not e.boss:
            e.wander_at = now + random.uniform(2.5, 7.0)
            a, r = random.uniform(0, 2 * math.pi), random.uniform(1.0, 3.5)
            wx, wz = hx + math.sin(a) * r, hz + math.cos(a) * r
            e.wander_to = (wx, wz) if not W.blocked(wx, wz, e.radius_c) and W.los(e.x, e.z, wx, wz) else None
        if e.wander_to:
            if hypot(e.wander_to[0] - e.x, e.wander_to[1] - e.z) < 0.3:
                e.wander_to = None
            else:
                self._steer(e, e.wander_to[0], e.wander_to[1], speed * 0.3, dt)

    def _boss_ai(self, e, t):
        """Sonderangriffe der Bosse. Gibt True zurück, solange einer zaubert."""
        now, d = self.now, e.d
        if e.cast_until:
            if now < e.cast_until:
                return True
            e.cast_until = 0.0
        if not e.summoned and e.hp < e.max_hp * 0.5:
            e.summoned = True
            deep = e.zone['dungeon']
            count = 2 + sum(1 for p in self.players.values() if not p.dead and W.in_rect(p.x, p.z, e.zone['leash'])) if deep else 3
            for i in range(min(count, 6) if d.get('summon') else 0):
                a = i * 2.1
                x, z = e.x + math.sin(a) * 3.0, e.z + math.cos(a) * 3.0
                if W.blocked(x, z, 0.5):
                    x, z = e.x, e.z
                add = Enemy(self._id(), d['summon'], e.zone, (x, z), level=max(1, e.level - 2) if deep else None, temp=True)
                add.target, add.state = t.sid, 'chase'
                self.enemies[add.id] = add
                self._fx(t='spawn', x=r2(x), z=r2(z))
            if d.get('summon') and not deep:
                self._sys(f'{d["name"]} ruft Diener herbei!')
        if not e.enraged and e.hp < e.max_hp * 0.25:            # Raserei: schneller, öfter Sonderangriffe
            e.enraged = True
            e.speed_f, e.cd_f = 1.3, 0.7
            self._fx(t='enrage', id=e.id, x=r2(e.x), z=r2(e.z))
            if not e.zone['dungeon']:
                self._sys(f'{d["name"]} gerät in Raserei!')
        if not e.next_slam:
            e.next_slam = now + 4.0
        if now >= e.next_slam:
            e.next_slam = now + (4.5 if e.enraged else 7.5 if e.hp > e.max_hp * 0.5 else 5.5)
            moves = d.get('moves') or ['slam']
            move = moves[e.move_i % len(moves)]
            e.move_i += 1
            e.windup_until = 0.0
            self._fx(t='eatk', id=e.id, k='cast')
            getattr(self, '_move_' + move)(e, t)
            return True
        return False

    def _boss_foes(self, e):
        return [p for p in self.players.values() if not p.dead and W.in_rect(p.x, p.z, e.zone['leash'])]

    def _move_slam(self, e, t):
        """Bodenschlag unter dem Ziel; tief im Verlies an mehreren Stellen."""
        e.cast_until = self.now + 1.5
        spots = [(t.x, t.z)]
        if e.zone['dungeon'] and self.dungeons[e.zone['map']]['depth'] >= 10:
            others = [p for p in self._boss_foes(e) if p is not t]
            spots += [(p.x, p.z) for p in others[:2]] or [(t.x + random.uniform(-6, 6), t.z + random.uniform(-6, 6))]
        dmg = self._enemy_dmg(e) * 1.7
        for x, z in spots:
            self._fx(t='tele', x=r2(x), z=r2(z), r=4.2, d=1.4, c='#ff3a28')
            self._after(1.4, lambda x=x, z=z: self._slam(e, x, z, 4.2, dmg))

    def _move_nova(self, e, t):
        """Ein Ring um den Boss – raus da!"""
        x, z, r = e.x, e.z, 6.5
        e.cast_until = self.now + 1.9
        dmg = self._enemy_dmg(e) * 1.6
        self._fx(t='tele', x=r2(x), z=r2(z), r=r, d=1.6, c='#ff3a28')
        self._after(1.6, lambda: self._slam(e, x, z, r, dmg))

    def _move_cone(self, e, t):
        """Ein Kegel vor dem Boss in Richtung seines Ziels – zur Seite ausweichen."""
        a = math.atan2(t.x - e.x, t.z - e.z)
        e.rot, length, half = a, 9.5, 0.6
        e.cast_until = self.now + 1.6
        dmg = self._enemy_dmg(e) * 1.6
        for i, (dist, r) in enumerate(((2.2, 1.3), (4.4, 2.0), (6.6, 2.7), (8.6, 3.2))):
            self._fx(t='tele', x=r2(e.x + math.sin(a) * dist), z=r2(e.z + math.cos(a) * dist), r=r, d=1.2, c='#ff3a28')
        ox, oz = e.x, e.z

        def hit():
            if e.dead or e.gone or e.state == 'return':
                return
            for i, (dist, r) in enumerate(((2.2, 1.3), (4.4, 2.0), (6.6, 2.7), (8.6, 3.2))):
                self._fx(t='boom', x=r2(ox + math.sin(a) * dist), z=r2(oz + math.cos(a) * dist), r=r, c=e.d['dust'],
                         **({'big': 1} if i == 3 else {}))
            for p in list(self.players.values()):
                dx, dz = p.x - ox, p.z - oz
                dist = hypot(dx, dz)
                off = abs((math.atan2(dx, dz) - a + math.pi) % (2 * math.pi) - math.pi)
                if not p.dead and (dist < 1.6 or (dist <= length and off <= half)):
                    self._hurt(p, dmg)
        self._after(1.2, hit)

    def _move_charge(self, e, t):
        """Sturmangriff: die Bahn leuchtet auf, dann rast der Boss hindurch."""
        dx, dz = t.x - e.x, t.z - e.z
        dist = max(hypot(dx, dz), 0.1)
        ux, uz = dx / dist, dz / dist
        x0, z0, x1, z1 = e.x, e.z, e.x, e.z
        step, leash = 0.0, e.zone['leash']
        while step < min(14.0, dist + 2.5):
            nx, nz = x0 + ux * (step + 0.5), z0 + uz * (step + 0.5)
            if W.blocked(nx, nz, e.radius_c) or not W.in_rect(nx, nz, leash):
                break
            step += 0.5
            x1, z1 = nx, nz
        e.rot = math.atan2(ux, uz)
        e.cast_until = self.now + 1.5
        dmg = self._enemy_dmg(e) * 1.5
        n = max(1, int(step // 2))
        for i in range(1, n + 1):
            self._fx(t='tele', x=r2(x0 + ux * step * i / n), z=r2(z0 + uz * step * i / n), r=1.6, d=1.0, c='#ff3a28')

        def go():
            if e.dead or e.gone or e.state == 'return':
                return
            sx, sz = e.x, e.z
            e.x, e.z = x1, z1
            self._fx(t='dash', x0=r2(sx), z0=r2(sz), x=r2(x1), z=r2(z1), c=e.d['dust'])
            self._fx(t='boom', x=r2(x1), z=r2(z1), r=2.4, c=e.d['dust'], big=1)
            lx, lz = x1 - sx, z1 - sz
            ll = max(lx * lx + lz * lz, 1e-6)
            for p in list(self.players.values()):
                if p.dead:
                    continue
                k = max(0.0, min(1.0, ((p.x - sx) * lx + (p.z - sz) * lz) / ll))
                if hypot(p.x - (sx + lx * k), p.z - (sz + lz * k)) <= 1.9:
                    self._hurt(p, dmg)
        self._after(1.0, go)

    def _move_volley(self, e, t):
        """Ein Fächer aus Geschossen; in Raserei gleich zwei hintereinander."""
        e.cast_until = self.now + (1.6 if e.enraged else 1.0)
        dmg = self._enemy_dmg(e) * 0.7

        def fire(shift):
            if e.dead or e.gone or e.state == 'return':
                return
            tgt = self.players.get(e.target) or t
            base = math.atan2(tgt.x - e.x, tgt.z - e.z) + shift
            for i in range(7):
                a = base + (i - 3) * 0.16
                dx, dz = math.sin(a), math.cos(a)
                self.projs.append({'id': self._id(), 'kind': 'dark', 'hostile': True, 'x': e.x + dx * 1.2, 'z': e.z + dz * 1.2,
                                   'dx': dx, 'dz': dz, 'speed': 11.0, 'left': 17.0, 'dmg': dmg, 'r': 0.4,
                                   'c': e.d['dust'], 'map': e.zone['map']})
        self._after(0.6, lambda: fire(0.0))
        if e.enraged:
            self._after(1.1, lambda: fire(0.08))

    def _move_rain(self, e, t):
        """Einschläge fallen vom Himmel – um jeden Helden in der Arena drei."""
        e.cast_until = self.now + 1.2
        dmg = self._enemy_dmg(e) * 1.2
        for p in self._boss_foes(e)[:6]:
            spots = [(p.x, p.z)] + [(p.x + random.uniform(-3.5, 3.5), p.z + random.uniform(-3.5, 3.5)) for _ in range(2)]
            for x, z in spots:
                self._fx(t='tele', x=r2(x), z=r2(z), r=2.6, d=1.5, c='#ff3a28', fall=1)
                self._after(1.5, lambda x=x, z=z: self._slam(e, x, z, 2.6, dmg))

    def _slam(self, e, x, z, radius, dmg):
        if e.dead or e.gone or e.state == 'return':
            return
        self._fx(t='boom', x=r2(x), z=r2(z), r=radius, c=e.d.get('dust', '#b38cff'), big=1)
        for p in list(self.players.values()):
            if not p.dead and hypot(p.x - x, p.z - z) <= radius:
                self._hurt(p, dmg)

    def _boss_reset(self, e):
        e.summoned, e.next_slam, e.cast_until = False, 0.0, 0.0
        e.enraged, e.move_i, e.speed_f, e.cd_f = False, 0, 1.0, 1.0
        for o in self.enemies.values():
            if o.temp and o.zone is e.zone:
                o.dead = o.gone = True

    def _separate(self):
        """Schiebt sich überlappende Gegner sanft auseinander."""
        live = [e for e in self.enemies.values() if not e.dead and e.target]
        for i, a in enumerate(live):
            for b in live[i + 1:]:
                dx, dz = b.x - a.x, b.z - a.z
                dist = hypot(dx, dz)
                need = (a.radius_c + b.radius_c) * 0.9
                if 1e-4 < dist < need:
                    push = (need - dist) / 2
                    ux, uz = dx / dist * push, dz / dist * push
                    if not W.blocked(a.x - ux, a.z - uz, a.radius_c):
                        a.x, a.z = a.x - ux, a.z - uz
                    if not W.blocked(b.x + ux, b.z + uz, b.radius_c):
                        b.x, b.z = b.x + ux, b.z + uz

    # ------------------------------------------------------ Geschosse und Felder
    def _update_projs(self, dt):
        flying = []
        for pr in self.projs:
            dist = pr['speed'] * dt
            steps = max(1, math.ceil(dist / 0.4))
            done = False
            for _ in range(steps):
                pr['x'] += pr['dx'] * dist / steps
                pr['z'] += pr['dz'] * dist / steps
                pr['left'] -= dist / steps
                if pr.get('hostile'):
                    for p in self.players.values():
                        if not p.dead and hypot(p.x - pr['x'], p.z - pr['z']) < 0.5 + pr['r']:
                            self._fx(t='boom', x=r2(pr['x']), z=r2(pr['z']), r=0.6, c=pr['c'])
                            self._hurt(p, pr['dmg'])
                            done = True
                            break
                else:
                    for e in list(self.enemies.values()):
                        if not e.dead and e.id not in pr['hit'] and hypot(e.x - pr['x'], e.z - pr['z']) < e.radius + pr['r']:
                            self._proj_hit(pr, e)
                            if not pr['pierce']:
                                done = True
                                break
                if done:
                    break
                if pr['left'] <= 0 or W.shot_blocked(pr['x'], pr['z']):
                    if pr.get('splash'):
                        self._proj_hit(pr, None)                   # schlägt am Ende der Flugbahn ein
                    else:
                        self._fx(t='boom', x=r2(pr['x']), z=r2(pr['z']), r=0.6, c=pr['c'])
                    done = True
                    break
            if not done:
                flying.append(pr)
        self.projs = flying

    def _proj_hit(self, pr, target):
        p = self.players.get(pr['owner'])
        sk, splash = pr['sk'], pr.get('splash', 0)
        self._fx(t='boom', x=r2(pr['x']), z=r2(pr['z']), r=splash or 0.6, c=pr['c'])
        if not p:
            return
        if target:
            pr['hit'].add(target.id)
            self._strike(p, target, pr['mult'], sk)
        if splash:
            side = {'tag': sk.get('tag')}
            for e in list(self.enemies.values()):
                if e is not target and not e.dead and hypot(e.x - pr['x'], e.z - pr['z']) <= splash + e.radius:
                    self._strike(p, e, pr['mult'] * 0.5, side, splash=True)

    def _update_zones(self):
        now, keep = self.now, []
        for zn in self.zones:
            p = self.players.get(zn['owner'])
            if not p or now >= zn['until'] or (zn['follow'] and p.dead):
                continue
            keep.append(zn)
            if zn['follow']:
                zn['x'], zn['z'] = p.x, p.z
            if now < zn['next']:
                continue
            zn['next'] += zn['tick']
            sk = zn['sk']
            ally = sk.get('ally')
            if ally:
                for o in self._allies(zn['x'], zn['z'], zn['r']):
                    if ally.get('heal'):
                        self._heal(o, o.max_hp * ally['heal'] * zn['power'], p)
                    mods = {k: v for k, v in ally.items() if k != 'heal'}
                    if mods:
                        fresh = 'zone:' + sk['id'] not in o.buffs or o.buffs['zone:' + sk['id']]['until'] <= now
                        o.buffs['zone:' + sk['id']] = {'until': now + zn['tick'] + 0.4, **mods}
                        o.dirty = o.dirty or fresh
            else:
                for e in list(self.enemies.values()):
                    if not e.dead and hypot(e.x - zn['x'], e.z - zn['z']) <= zn['r'] + e.radius:
                        self._strike(p, e, zn['mult'], sk)
        self.zones = keep

    # ------------------------------------------------------------------ Verliese
    # Eine Karte mit `dungeon` hat eine Halle (Zone), die Ebene für Ebene Gegner weckt, solange Helden darin stehen.
    def _dungeon_enemies(self, zone):
        return [e for e in self.enemies.values() if e.zone is zone and not e.dead and not e.gone]

    def _dungeon_clear(self, zone):
        for e in self.enemies.values():
            if e.zone is zone:
                e.dead = e.gone = True
        self.projs = [pr for pr in self.projs if not (pr.get('hostile') and pr['map'] == zone['map'])]

    def _dungeon_spawn(self, zone, kind, level, inside, hp_mult=1.0):
        x, z = self._spot(zone, kind, away_from=inside)           # nicht direkt neben einem Helden auftauchen
        e = Enemy(self._id(), kind, zone, (x, z), level=level, temp=True, hp_mult=hp_mult)
        self.enemies[e.id] = e
        self._fx(t='spawn', x=r2(x), z=r2(z))

    def _dungeon_wave(self, mid, zone, inside):
        """Weckt den nächsten Schwung: nie mehr auf einmal, als die Helden bewältigen können."""
        dg, cfg = self.dungeons[mid], W.MAPS[mid]['dungeon']
        level = cfg['base_level'] + dg['depth']
        kinds = [k for k, first, w in cfg['mix'] if dg['depth'] >= first for _ in range(w)]
        batch = min(dg['reserve'], 3 + 2 * len(inside))
        dg['reserve'] -= batch
        for _ in range(batch):
            self._dungeon_spawn(zone, random.choice(kinds), level, inside, hp_mult=dg['hp_mult'])

    def _dungeon_floor(self, mid, zone, depth, inside):
        """Beginnt eine Ebene. Jede `boss_every`-te gehört dem Boss des Verlieses."""
        dg, cfg = self.dungeons[mid], W.MAPS[mid]['dungeon']
        dg['depth'], dg['phase'] = depth, 'fight'
        dg['fighters'] = set()                                    # wer auf dieser Ebene mitgekämpft hat
        n = len(inside)
        boss = bool(cfg['boss']) and depth % cfg['boss_every'] == 0
        dg['reserve'] = 2 + n if boss else min(4 + depth // 3, 12) + 2 * (n - 1)
        dg['hp_mult'] = 1 + 0.4 * (n - 1)                         # zu mehreren: mehr und zähere Gegner
        if boss:
            self._dungeon_spawn(zone, cfg['boss'], cfg['base_level'] + depth + 1, inside, hp_mult=1 + 0.8 * (n - 1))
        self._dungeon_wave(mid, zone, inside)
        for p in self.players.values():
            if W.map_at(p.x, p.z) == mid:
                self._toast(p, f'Ebene {depth}' + (f' – {ENEMIES[cfg["boss"]]["name"]} erwacht!' if boss else ''),
                            'warn' if boss else 'info')

    def _update_dungeon(self, mid):
        dg, cfg, now = self.dungeons[mid], W.MAPS[mid]['dungeon'], self.now
        zone = W.MAPS[mid]['zones'][cfg['zone']]
        inside = [p for p in self.players.values() if not p.dead and W.in_rect(p.x, p.z, zone['leash'])]
        if dg['phase'] == 'idle':
            if inside:
                self._dungeon_floor(mid, zone, dg['start'], inside)
                dg['empty_since'] = 0.0
            return
        if not inside:                                            # alle gefallen oder gegangen
            dg['empty_since'] = dg['empty_since'] or now
            if now - dg['empty_since'] > 6.0:
                self._dungeon_clear(zone)
                dg['start'] = dg['depth'] if dg['phase'] == 'fight' else dg['depth'] + 1
                dg['phase'], dg['empty_since'], dg['reserve'] = 'idle', 0.0, 0
            return
        dg['empty_since'] = 0.0
        dg['fighters'].update(p.sid for p in inside)
        alive = len(self._dungeon_enemies(zone))
        if dg['phase'] == 'fight' and dg['reserve'] and alive <= 2:
            self._dungeon_wave(mid, zone, inside)                 # Verstärkung
        elif dg['phase'] == 'fight' and not alive:
            dg['phase'], dg['next_at'] = 'cleared', now + 4.0
            depth, level = dg['depth'], cfg['base_level'] + dg['depth']
            boss = bool(cfg['boss']) and depth % cfg['boss_every'] == 0
            for p in self.players.values():
                if p.sid not in dg['fighters'] or W.map_at(p.x, p.z) != mid:
                    continue
                bonus = enemy_xp(cfg['floor_xp'], level) * (3 if boss else 1)
                p.gold += 10 + 4 * level
                p.deepest[mid] = max(p.deepest.get(mid, 0), depth)
                self._toast(p, f'Ebene {depth} geschafft  +{bonus} EP', 'quest')
                self._fx(t='questdone', id=p.id)
                self._gain_xp(p, bonus)
                self._quest_progress(p, 'depth', mid, depth)
                if p.dead:                                        # wer gefallen ist, steht zur nächsten Ebene wieder auf
                    p.respawn_at = min(p.respawn_at, now + 0.5)
                p.dirty = True
            if boss:
                self._sys(f'{W.MAPS[mid]["name"]}: Ebene {depth} ist bezwungen!')
                self._save_all()
        elif dg['phase'] == 'cleared' and now >= dg['next_at']:
            self._dungeon_floor(mid, zone, dg['depth'] + 1, inside)

    # ------------------------------------------------------------- Spielschleife
    def _update_players(self, dt):
        now = self.now
        for p in self.players.values():
            if p.dead:
                if now >= p.respawn_at:                           # steht am Ankunftspunkt seiner Karte wieder auf
                    p.dead = False
                    p.hp, p.res = float(p.max_hp), float(p.stats['res'])
                    p.dirty = True
                    self._teleport(p, *self._near_start(W.map_at(p.x, p.z) or W.MAIN))
                    self._fx(t='spawn', x=r2(p.x), z=r2(p.z))
                continue
            s = p.stats
            p.res = min(s['res'], p.res + (s['resregen'] + s['res'] * p.buffv('res_pct', now)) * dt)
            regen = s['hpregen'] + p.max_hp * p.buffv('regen', now)
            if now - p.last_combat > 6.0:
                regen += p.max_hp * 0.05
            p.hp = min(p.max_hp, p.hp + regen * dt)
            if p.buffs and any(b['until'] <= now for b in p.buffs.values()):
                p.buffs = {k: b for k, b in p.buffs.items() if b['until'] > now}
                p.dirty = True
            if p.shield and now >= p.shield_until:
                p.shield = 0
            if p.elixirs and any(u <= now for u in p.elixirs.values()):
                for k in [k for k, u in p.elixirs.items() if u <= now]:
                    del p.elixirs[k]
                    self._toast(p, f'Die Wirkung von {ELIXIRS[k]["name"]} lässt nach.', 'info')
                p.dirty = True
            # Übergänge zwischen den Karten
            if now >= p.stairs_at:
                portal = W.PORTAL_AT.get((int(p.x // W.TILE), int(p.z // W.TILE)))
                if portal:
                    p.stairs_at = now + 1.5
                    self._fx(t='spawn', x=r2(p.x), z=r2(p.z))
                    self._teleport(p, portal['x'], portal['z'])
                    self._fx(t='spawn', x=r2(p.x), z=r2(p.z))
            for k in self.pickups:
                if k['active'] and hypot(p.x - k['x'], p.z - k['z']) < 1.5 and self._wants(p, 'collect', k['kind']):
                    k['active'] = False
                    k['at'] = now + 18.0
                    self._fx(t='pick', x=r2(k['x']), z=r2(k['z']), k=k['kind'])
                    for o in self.players.values():
                        if o is p or (not o.dead and hypot(o.x - k['x'], o.z - k['z']) <= SHARE_RADIUS):
                            self._quest_progress(o, 'collect', k['kind'])
        for k in self.pickups:
            if not k['active'] and now >= k['at']:
                k['active'] = True

    def tick(self, now, dt):
        """Ein Schritt der Spielwelt. Liefert nichts zurück, sondern sendet jedem Helden den Zustand seiner Karte."""
        with self.lock:
            if not self.players:
                return
            self.now = now
            due = [t for t in self.timers if t[0] <= now]
            self.timers = [t for t in self.timers if t[0] > now]
            for _, fn in due:
                fn()
            busy = {W.map_at(p.x, p.z) for p in self.players.values()}     # Karten ohne Helden ruhen
            for e in list(self.enemies.values()):
                if e.zone['map'] in busy:
                    self._update_enemy(e, dt)
            self._separate()
            self._update_projs(dt)
            self._update_zones()
            self._update_players(dt)
            for mid in self.dungeons:
                self._update_dungeon(mid)
            self.enemies = {i: e for i, e in self.enemies.items() if not e.gone}
            here = defaultdict(list)
            for p in self.players.values():
                here[W.map_at(p.x, p.z) or W.MAIN].append(p)
            out = [(p.sid, snap) for mid, ps in here.items() for snap in [self._snapshot(mid, ps)] for p in ps]
            self.fx = []
            dirty = [(p.sid, self._you(p)) for p in self.players.values() if p.dirty]
            for p in self.players.values():
                p.dirty = False
            if now - self.last_save > 30:
                self._save_all()
        for sid, snap in out:
            self.emit('state', snap, to=sid)
        for sid, you in dirty:
            self.emit('you', you, to=sid)

    def _snapshot(self, mid, players):
        """Alles, was auf der Karte `mid` zu sehen ist."""
        now, order = self.now, list(STATUS)
        dg = self.dungeons.get(mid)

        def mask(e):
            return sum(1 << i for i, s in enumerate(order) if s in e.status)

        return {
            'p': [[p.id, p.name, p.cls, r2(p.x), r2(p.z), r2(p.rot), max(0, round(p.hp)), p.max_hp, p.level,
                   (1 if p.dead else 0) | (2 if p.combat_buff('dmg', now) else 0) | (4 if p.shield > 0 and now < p.shield_until else 0),
                   round(p.res), p.stats['res']] for p in players],
            'e': [[e.id, e.kind, r2(e.x), r2(e.z), r2(e.rot), max(0, round(e.hp)), e.max_hp,
                   (1 if e.windup_until or e.cast_until else 0) | (2 if now < e.slow_until else 0) | (4 if now < e.stun_until else 0)
                   | (8 if e.enraged else 0),
                   e.level, mask(e), e.elite or ''] for e in self.enemies.values() if not e.dead and e.zone['map'] == mid],
            's': [[pr['id'], pr['kind'], r2(pr['x']), r2(pr['z']), r2(math.atan2(pr['dx'], pr['dz'])), pr['c']]
                  for pr in self.projs if pr['map'] == mid],
            'k': [[k['id'], k['kind'], k['x'], k['z']] for k in self.pickups if k['active'] and k['map'] == mid],
            'z': [[zn['id'], r2(zn['x']), r2(zn['z']), zn['r'], zn['c']] for zn in self.zones if zn['map'] == mid],
            # Verlies dieser Karte: [Ebene, lebende Gegner, Phase, nächste Start-Ebene] – sonst None
            'c': [dg['depth'] if dg['phase'] != 'idle' else 0,
                  len(self._dungeon_enemies(W.MAPS[mid]['zones'][W.MAPS[mid]['dungeon']['zone']])) + dg['reserve'],
                  dg['phase'], dg['start']] if dg else None,
            'fx': [kw for where, kw in self.fx if where is None or where == mid],
            # alle Helden im Spiel, auch auf anderen Karten: [Name, Klasse, Stufe, Karte]
            'r': [[p.name, p.cls, p.level, W.map_at(p.x, p.z) or W.MAIN] for p in self.players.values()],
        }
