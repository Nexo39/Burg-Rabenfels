"""Die Welt: baut aus den angemeldeten Karten ein gemeinsames Kachelraster und beantwortet
Fragen nach Kollision, Sichtlinien und Wegen.

Jede Karte wird als ASCII-Plan angemeldet (ein Zeichen je Kachel, 2 x 2 Einheiten) und hat ihre
eigenen Koordinaten. Intern liegen alle Karten nebeneinander in einem großen Raster, getrennt durch
undurchdringliche Leere; Übergänge (Portale) versetzen Helden von einer Karte auf die andere.
Engine und Browser rechnen deshalb durchgehend in Weltkoordinaten – Karten-Dateien nie.

Zeichen im Plan
  Untergrund:  , Gras   : Erdweg   . Pflaster   _ Dielen   = Bohlen/Brücke   c Kellerboden
               g Friedhofserde   k Gruftboden   D Burgtor   d Türdurchgang   v u Treppe
               # Ringmauer   H Hauswand   O Turm   M massiver Fels   ~ Wasser      (diese fünf sind fest)
  Gegenstände: T Baum   R Felsbrocken   + Grabstein   B Fässer   X Kiste   W Brunnen   ^ Zelt
               A Amboss   F Esse (leuchtet)   S Steinblock   P Säule                  (alle fest)
  Übergänge:   1–9 (Treppenkachel; wohin sie führt, steht in `portals` der Karte)
Ein Gegenstand steht auf dem Untergrund seines begehbaren Nachbarn (links, oben, rechts, unten),
sonst auf dem `floor` der Karte. Eigene Zeichen legt `legend` fest.
"""
import math
import random
import textwrap
from collections import deque

from . import registry as R

TILE = 2.0
GAP = 16                                 # Kacheln Leere zwischen zwei Karten
MAX_SIZE = 96                            # größte Kantenlänge einer Karte (Grenze der Bodentextur im Browser)
VOID = ' '

FLOOR_CHARS = frozenset(',:._=cgkDdvu#HOM~')
OBJ_CHARS = frozenset('TR+BXW^AFSP')
PORTAL_CHARS = frozenset('123456789')
SOLID_FLOOR = frozenset('#HO~M' + VOID)
SOLID_OBJ = OBJ_CHARS
SHOT_FLOOR = frozenset('#HOM' + VOID)    # hält Geschosse auf (Wasser nicht)
SHOT_OBJ = frozenset('TRP^')             # niedrige Gegenstände lassen Geschosse durch

# Wird von build() gefüllt
W = H = 0
FLOOR, OBJ, SOLID, SHOT = [], [], [], []
MAPS = {}            # Kennung -> gebaute Karte
MAIN = None          # Karte, auf der neue Helden beginnen
NPCS = {}            # Kennung -> Bewohner (x, z in Welt-Kacheln)
SPAWNS = []          # (Gegnerart, Zone, Anzahl, fester Platz in Welteinheiten oder None)
PICKUPS = []         # (Questgegenstand, x, z in Welteinheiten, Karte)
PORTAL_AT = {}       # (Kachel-x, Kachel-z) -> {'to', 'x', 'z'}
CLIENT = {}


# ------------------------------------------------------------- Plan lesen
def parse_plan(m):
    """ASCII-Plan -> (floor, obj, portal_tiles) oder None bei Fehlern."""
    what, src = f"Karte '{m['id']}'", m['_src']
    rows = [r.rstrip() for r in textwrap.dedent(m['plan']).strip('\n').split('\n')]
    w, h = len(rows[0]) if rows else 0, len(rows)
    if not 6 <= w <= MAX_SIZE or not 6 <= h <= MAX_SIZE:
        R._err(f"{what}: der Plan ist {w} x {h} Kacheln groß; erlaubt sind 6 bis {MAX_SIZE} je Richtung.", src)
        return None
    ok = True
    for z, row in enumerate(rows):
        if len(row) != w:
            R._err(f"{what}: Zeile {z + 1} des Plans ist {len(row)} Zeichen lang, die erste {w}. Alle Zeilen müssen gleich lang sein.", src)
            ok = False
    legend = m['legend']
    for ch, pair in legend.items():
        if len(ch) != 1 or len(pair) != 2 or pair[0] not in FLOOR_CHARS or (pair[1] not in OBJ_CHARS and pair[1] != ' '):
            R._err(f"{what}: legend[{ch!r}] muss (Untergrund, Gegenstand) sein, z. B. ('_', 'X').", src)
            ok = False
    if m['floor'] not in FLOOR_CHARS or m['floor'] in SOLID_FLOOR:
        R._err(f"{what}: floor {m['floor']!r} muss ein begehbarer Untergrund sein.", src)
        ok = False
    if not ok:
        return None
    floor = [[None] * w for _ in range(h)]
    obj = [[' '] * w for _ in range(h)]
    portals = {}
    for z, row in enumerate(rows):
        for x, ch in enumerate(row):
            if ch in legend:
                floor[z][x], obj[z][x] = legend[ch]
            elif ch in FLOOR_CHARS:
                floor[z][x] = ch
            elif ch in PORTAL_CHARS:
                floor[z][x] = 'v'
                portals.setdefault(ch, []).append((x, z))
            elif ch in OBJ_CHARS:
                obj[z][x] = ch
                under = None
                for nx, nz, done in ((x - 1, z, True), (x, z - 1, True), (x + 1, z, False), (x, z + 1, False)):
                    if 0 <= nx < w and 0 <= nz < h:
                        c = floor[nz][nx] if done else (rows[nz][nx] if rows[nz][nx] in FLOOR_CHARS else None)
                        if c and c not in SOLID_FLOOR:
                            under = c
                            break
                floor[z][x] = under or m['floor']
            else:
                R._err(f"{what}: unbekanntes Zeichen {ch!r} im Plan, Zeile {z + 1}, Spalte {x + 1}. "
                       f"Leerzeichen sind nicht erlaubt; für Leere 'M' (Fels) verwenden.", src)
                ok = False
    return (floor, obj, portals) if ok else None


# ------------------------------------------------------------------ Bauen
def build():
    """Baut die Welt aus registry.MAPS. Fehler landen in registry.ERRORS."""
    global W, H, FLOOR, OBJ, SOLID, SHOT, MAIN
    MAPS.clear(); NPCS.clear(); PORTAL_AT.clear(); CLIENT.clear()
    del SPAWNS[:], PICKUPS[:]
    parsed = {mid: parse_plan(m) for mid, m in R.MAPS.items()}
    if not R.MAPS or any(p is None for p in parsed.values()) or sum(1 for m in R.MAPS.values() if m['main']) != 1:
        return
    order = sorted(R.MAPS, key=lambda mid: not R.MAPS[mid]['main'])      # Hauptkarte zuerst, also bei (0, 0)
    MAIN = order[0]
    ox = 0
    for mid in order:
        floor, obj, portal_tiles = parsed[mid]
        m = R.MAPS[mid]
        MAPS[mid] = {'id': mid, 'name': m['name'], 'ox': ox, 'oz': 0, 'w': len(floor[0]), 'h': len(floor), 'light': m['light'],
                     'floor': floor, 'obj': obj, 'portal_tiles': portal_tiles, 'zones': {}, 'dungeon': None, 'src': m['_src']}
        ox += len(floor[0]) + GAP
    W, H = ox - GAP, max(b['h'] for b in MAPS.values())
    FLOOR = [[VOID] * W for _ in range(H)]
    OBJ = [[' '] * W for _ in range(H)]
    for b in MAPS.values():
        for z in range(b['h']):
            FLOOR[z][b['ox']:b['ox'] + b['w']] = b['floor'][z]
            OBJ[z][b['ox']:b['ox'] + b['w']] = b['obj'][z]
        b['rect'] = (b['ox'] * TILE, 0.0, (b['ox'] + b['w']) * TILE, b['h'] * TILE)

    def inside(b, x, z):
        return 0 <= x < b['w'] and 0 <= z < b['h']

    def walkable(b, x, z):
        tx, tz = int(math.floor(x)), int(math.floor(z))
        return inside(b, tx, tz) and b['floor'][tz][tx] not in SOLID_FLOOR and b['obj'][tz][tx] not in SOLID_OBJ

    # ---- Übergänge sammeln: aus dem Plan (Ziffern) und aus portal(...)
    links = []                                                   # (Karte, Kacheln, Ziel-Karte, Ziel oder None, Quelle, Name)
    for mid, b in MAPS.items():
        m, what = R.MAPS[mid], f"Karte '{mid}'"
        for sym in sorted(set(b['portal_tiles']) | set(m['portals'])):
            if sym not in b['portal_tiles']:
                R._err(f"{what}: Übergang '{sym}' ist in portals beschrieben, kommt im Plan aber nicht vor.", m['_src'])
            elif sym not in m['portals']:
                R._err(f"{what}: im Plan steht der Übergang '{sym}', aber portals beschreibt nicht, wohin er führt.", m['_src'])
            elif m['portals'][sym].get('to') in MAPS:
                links.append((mid, b['portal_tiles'][sym], m['portals'][sym]['to'], m['portals'][sym].get('target'), m['_src'], f"Übergang '{sym}'"))
    for p in R.PORTALS:
        if p['map'] not in MAPS or p['to'] not in MAPS:
            continue
        b, (x, z) = MAPS[p['map']], p['at']
        if not walkable(b, x, z):
            R._err(f"Übergang auf Karte '{p['map']}' bei {p['at']}: die Kachel ist nicht begehbar.", p['_src'])
            continue
        tile = (int(math.floor(x)), int(math.floor(z)))
        b['floor'][tile[1]][tile[0]] = FLOOR[tile[1]][b['ox'] + tile[0]] = 'v'
        links.append((p['map'], [tile], p['to'], p['target'], p['_src'], f"Übergang bei {p['at']}"))
    portal_tiles = {mid: {t for l in links if l[0] == mid for t in l[1]} for mid in MAPS}
    arrivals = {mid: [] for mid in MAPS}
    for mid, tiles, to, target, src, name in links:
        b, tb = MAPS[mid], MAPS[to]
        tx, tz = target if target else R.MAPS[to]['start']
        what = f"Karte '{mid}', {name}"
        if not walkable(tb, tx, tz):
            R._err(f"{what}: das Ziel {(tx, tz)} auf Karte '{to}' ist nicht begehbar.", src)
            continue
        if (int(math.floor(tx)), int(math.floor(tz))) in portal_tiles[to]:
            R._err(f"{what}: das Ziel {(tx, tz)} auf Karte '{to}' liegt selbst auf einem Übergang – man würde sofort zurückspringen.", src)
            continue
        arrivals[to].append((tx, tz))
        dest = {'to': to, 'x': (tb['ox'] + tx) * TILE, 'z': tz * TILE}
        for x, z in tiles:
            PORTAL_AT[(b['ox'] + x, z)] = dest
        b.setdefault('portal_deco', []).append((sum(x for x, _ in tiles) / len(tiles) + 0.5, sum(z for _, z in tiles) / len(tiles) + 0.5))

    SOLID = [[FLOOR[z][x] in SOLID_FLOOR or OBJ[z][x] in SOLID_OBJ for x in range(W)] for z in range(H)]
    SHOT = [[FLOOR[z][x] in SHOT_FLOOR or OBJ[z][x] in SHOT_OBJ for x in range(W)] for z in range(H)]

    # ---- je Karte: Erreichbarkeit, Zonen, Bewohner, Gegner, Fundstücke
    for mid, b in MAPS.items():
        m, what, src, o = R.MAPS[mid], f"Karte '{mid}'", R.MAPS[mid]['_src'], b['ox']
        sx, sz = m['start']
        if not walkable(b, sx, sz):
            R._err(f"{what}: der Startpunkt {m['start']} ist nicht begehbar.", src)
            continue
        # Ankommende Helden werden leicht gestreut (1,7 Kacheln seitlich, 1,2 nach oben und unten) – dort darf kein Übergang liegen
        near = [t for t in sorted(portal_tiles[mid]) if t[0] < sx + 1.7 and t[0] + 1 > sx - 1.7 and t[1] < sz + 1.2 and t[1] + 1 > sz - 1.2]
        if near:
            R._err(f"{what}: der Übergang auf Kachel {near[0]} liegt direkt am Startpunkt {m['start']} – wer ankommt, "
                   f"stolpert hinein. Halte mindestens zwei Kacheln Abstand.", src)
        b['start'] = ((o + sx) * TILE, sz * TILE)
        seeds = [(sx, sz)] + arrivals[mid]
        reach = {(int(math.floor(x)), int(math.floor(z))) for x, z in seeds}
        todo = deque(reach)
        while todo:
            x, z = todo.popleft()
            for nb in ((x + 1, z), (x - 1, z), (x, z + 1), (x, z - 1)):
                if nb not in reach and walkable(b, *nb):
                    reach.add(nb)
                    todo.append(nb)
        b['reach'] = reach

        def reachable(x, z):
            return (int(math.floor(x)), int(math.floor(z))) in reach

        for t in sorted(portal_tiles[mid]):
            if t not in reach:
                R._err(f"{what}: der Übergang auf Kachel {t} ist vom Startpunkt aus nicht erreichbar.", src)
        for name, zdef in m['zones'].items():
            zdef = {'rect': zdef} if isinstance(zdef, (tuple, list)) else zdef
            rect = zdef.get('rect')
            if not rect or len(rect) != 4 or not (0 <= rect[0] <= rect[2] < b['w'] and 0 <= rect[1] <= rect[3] < b['h']):
                R._err(f"{what}, Zone '{name}': rect {rect!r} muss (x0, z0, x1, z1) innerhalb der Karte ({b['w']} x {b['h']}) sein.", src)
                continue
            margin = zdef.get('margin', 3)
            leash = ((o + rect[0] - margin) * TILE, (rect[1] - margin) * TILE, (o + rect[2] + 1 + margin) * TILE, (rect[3] + 1 + margin) * TILE)
            leash = (max(leash[0], b['rect'][0]), max(leash[1], b['rect'][1]), min(leash[2], b['rect'][2]), min(leash[3], b['rect'][3]))
            tiles = [(o + x, z) for z in range(rect[1], rect[3] + 1) for x in range(rect[0], rect[2] + 1) if (x, z) in reach]
            if not tiles:
                R._err(f"{what}, Zone '{name}': im Rechteck {tuple(rect)} liegt keine erreichbare Kachel.", src)
                continue
            b['zones'][name] = {'name': name, 'map': mid, 'leash': leash, 'tiles': tiles, 'dungeon': False}
        for sp in m['spawns']:
            if len(sp) not in (3, 4) or sp[1] not in b['zones'] or sp[0] not in R.ENEMIES:
                continue
            at = None
            if len(sp) == 4:
                if not reachable(*sp[3]):
                    R._err(f"{what}: der feste Platz {sp[3]} für '{sp[0]}' ist nicht erreichbar.", src)
                    continue
                at = ((o + sp[3][0]) * TILE, sp[3][1] * TILE)
            SPAWNS.append((sp[0], b['zones'][sp[1]], sp[2], at))
        for pk in m['pickups']:
            if len(pk) == 3 and pk[0] in R.PICKUPS:
                if not reachable(pk[1], pk[2]):
                    R._err(f"{what}: der Questgegenstand '{pk[0]}' bei {(pk[1], pk[2])} liegt auf keiner erreichbaren Kachel.", src)
                else:
                    PICKUPS.append((pk[0], (o + int(pk[1]) + 0.5) * TILE, (int(pk[2]) + 0.5) * TILE, mid))
        for nid, n in m['npcs'].items():
            at = n.get('at')
            if not at or len(at) != 2 or not reachable(*at):
                R._err(f"{what}, Bewohner '{nid}': der Platz {at!r} ist nicht erreichbar (Mauer, Gegenstand oder abgeschnitten).", src)
                continue
            NPCS[nid] = {'name': n.get('name'), 'role': n.get('role'), 'look': n.get('look'), 'greet': n.get('greet'),
                         'services': list(n.get('services', ())), 'map': mid, 'x': o + at[0], 'z': at[1]}
        # Start und Bewohner gehören nicht in ein Gegnergebiet (Rechteck samt margin)
        hostile = {name: z for name, z in b['zones'].items()
                   if any(sp[1] == name for sp in m['spawns'] if len(sp) >= 3) or (m['dungeon'] or {}).get('zone') == name}
        spots = [('der Startpunkt', m['start'])] + [(f"Bewohner '{nid}'", m['npcs'][nid]['at']) for nid in m['npcs'] if nid in NPCS]
        for label, (x, z) in spots:
            for name, zone in hostile.items():
                zdef = m['zones'][name]
                x0, z0, x1, z1 = zdef['rect'] if isinstance(zdef, dict) else zdef
                if (m['dungeon'] or {}).get('zone') == name:
                    if in_rect((o + x) * TILE, z * TILE, zone['leash']):
                        R._err(f"{what}: {label} {(x, z)} liegt im Verlies '{name}' (Rechteck samt margin). "
                               f"Es käme nie zur Ruhe – trenne beides durch einen Gang.", src)
                elif x0 <= x < x1 + 1 and z0 <= z < z1 + 1:
                    R._note(f"{what}: {label} {(x, z)} liegt mitten im Gegnergebiet '{name}'.", src)
        for r in m['regions']:
            if len(r) != 2 or len(r[1]) != 4:
                R._err(f"{what}: regions-Eintrag {r!r} hat die Form (Name, (x0, z0, x1, z1)).", src)
        d = m['dungeon']
        if d and d.get('zone') in b['zones']:
            b['dungeon'] = d
            b['zones'][d['zone']]['dungeon'] = True
        deco = [{'k': k, 'x': x * TILE, 'z': z * TILE} for k, x, z in (e for e in m['deco'] if len(e) == 3)]
        deco += [{'k': 'portal', 'x': x * TILE, 'z': z * TILE} for x, z in b.get('portal_deco', ())]
        b['client'] = {
            'id': mid, 'name': b['name'], 'ox': o, 'oz': 0, 'w': b['w'], 'h': b['h'], 'light': b['light'],
            'floor': [''.join(r) for r in b['floor']], 'obj': [''.join(r) for r in b['obj']], 'deco': deco,
            'regions': [{'name': r[0], 'rect': list(r[1])} for r in m['regions'] if len(r) == 2 and len(r[1]) == 4],
            'npcs': {nid: {**{k: n[k] for k in ('name', 'role', 'look', 'greet')}, 'x': n['x'] * TILE, 'z': n['z'] * TILE}
                     for nid, n in NPCS.items() if n['map'] == mid},
        }

    # ---- Jede Karte muss von der Hauptkarte aus erreichbar sein – und wieder zurück
    def spread(start, forward):
        seen, todo = {start}, [start]
        while todo:
            cur = todo.pop()
            for mid, _, to, *_ in links:
                a, c = (mid, to) if forward else (to, mid)
                if a == cur and c not in seen:
                    seen.add(c)
                    todo.append(c)
        return seen

    out, back = spread(MAIN, True), spread(MAIN, False)
    for mid in MAPS:
        if mid not in out:
            R._err(f"Karte '{mid}': von der Hauptkarte '{MAIN}' führt kein Übergang hierher. "
                   f"Lege einen an, z. B. portal('{MAIN}', at=(x, z), to='{mid}').", R.MAPS[mid]['_src'])
        elif mid not in back:
            R._err(f"Karte '{mid}': von hier führt kein Übergang zurück zur Hauptkarte '{MAIN}' – Helden säßen fest.", R.MAPS[mid]['_src'])

    CLIENT.update({'tile': TILE, 'main': MAIN, 'solidFloor': ''.join(sorted(SOLID_FLOOR - {VOID})),
                   'solidObj': ''.join(sorted(SOLID_OBJ)), 'maps': [b['client'] for b in MAPS.values() if 'client' in b]})


# ---------------------------------------------------------------- Abfragen
def map_at(x, z):
    """Kennung der Karte an einer Weltposition (None in der Leere)."""
    for mid, b in MAPS.items():
        r = b['rect']
        if r[0] <= x < r[2] and r[1] <= z < r[3]:
            return mid
    return None


def to_world(map_id, x, z):
    """Kachelkoordinaten einer Karte -> Weltkoordinaten."""
    return ((MAPS[map_id]['ox'] + x) * TILE, z * TILE)


def in_rect(x, z, r):
    return r[0] <= x <= r[2] and r[1] <= z <= r[3]


def solid_at(tx, tz):
    if tx < 0 or tz < 0 or tx >= W or tz >= H:
        return True
    return SOLID[tz][tx]


def blocked(x, z, r):
    """Stößt ein Kreis mit Radius r an eine feste Kachel? (Im Browser identisch umgesetzt.)"""
    x0, x1 = math.floor((x - r) / TILE), math.floor((x + r) / TILE)
    z0, z1 = math.floor((z - r) / TILE), math.floor((z + r) / TILE)
    for tz in range(z0, z1 + 1):
        for tx in range(x0, x1 + 1):
            if not solid_at(tx, tz):
                continue
            cx = max(tx * TILE, min(x, (tx + 1) * TILE))
            cz = max(tz * TILE, min(z, (tz + 1) * TILE))
            if (x - cx) ** 2 + (z - cz) ** 2 < r * r:
                return True
    return False


def shot_blocked(x, z):
    tx, tz = int(x // TILE), int(z // TILE)
    if tx < 0 or tz < 0 or tx >= W or tz >= H:
        return True
    return SHOT[tz][tx]


def los(x0, z0, x1, z1):
    """Freie Sichtlinie (für Bewegung) zwischen zwei Punkten?"""
    dx, dz = x1 - x0, z1 - z0
    dist = math.hypot(dx, dz)
    steps = max(1, int(dist / 0.5))
    for i in range(1, steps):
        t = i / steps
        if solid_at(int((x0 + dx * t) // TILE), int((z0 + dz * t) // TILE)):
            return False
    return True


def shot_los(x0, z0, x1, z1):
    """Freie Schussbahn zwischen zwei Punkten?"""
    dx, dz = x1 - x0, z1 - z0
    steps = max(1, int(math.hypot(dx, dz) / 0.2))          # fein genug, um auch gestreifte Säulenecken zu bemerken
    return not any(shot_blocked(x0 + dx * i / steps, z0 + dz * i / steps) for i in range(1, steps))


def next_step(sx, sz, tx, tz, limit=900):
    """Breitensuche auf dem Kachelraster: liefert den nächsten Wegpunkt von (sx, sz) Richtung (tx, tz)."""
    start = (int(sx // TILE), int(sz // TILE))
    goal = (int(tx // TILE), int(tz // TILE))
    if start == goal:
        return (tx, tz)
    if solid_at(*goal):
        return None
    came = {goal: None}
    todo = deque([goal])
    n = 0
    while todo and n < limit:
        cur = todo.popleft()
        n += 1
        if cur == start:
            nxt = came[cur]
            if nxt == goal:
                return (tx, tz)
            return ((nxt[0] + 0.5) * TILE, (nxt[1] + 0.5) * TILE)
        x, z = cur
        for nb in ((x + 1, z), (x - 1, z), (x, z + 1), (x, z - 1)):
            if nb not in came and not solid_at(*nb):
                came[nb] = cur
                todo.append(nb)
    return None


def floor_at(x, z):
    """Untergrund an einer Weltposition."""
    tx, tz = int(x // TILE), int(z // TILE)
    return FLOOR[tz][tx] if 0 <= tx < W and 0 <= tz < H else VOID


def random_point(zone, rng=random):
    """Zufälliger begehbarer Punkt in einer Zone (Weltkoordinaten)."""
    x, z = rng.choice(zone['tiles'])
    return ((x + rng.uniform(0.3, 0.7)) * TILE, (z + rng.uniform(0.3, 0.7)) * TILE)


def ascii_map(map_id, marks=None):
    """Der gebaute Plan einer Karte als Text – zur Kontrolle in tools/pruefen.py.

    marks: {(x, z): Zeichen} überlagert einzelne Kacheln (Bewohner, Start, Fundstücke ...).
    """
    b = MAPS[map_id]
    marks = marks or {}
    lines = ['    ' + ''.join(str(x // 10 % 10) if x % 10 == 0 else ' ' for x in range(b['w'])),
             '    ' + ''.join(str(x % 10) for x in range(b['w']))]
    for z in range(b['h']):
        row = ''.join(marks.get((x, z)) or (b['obj'][z][x] if b['obj'][z][x] != ' ' else b['floor'][z][x]) for x in range(b['w']))
        lines.append(f'{z:3d} {row}')
    return '\n'.join(lines)
