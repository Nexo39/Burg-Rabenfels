"""Feste Spielregeln: Grenzwerte, Attribute und Wachstumskurven.

Hier steht nur, was für das ganze Spiel gilt. Alles, was es *im* Spiel gibt – Klassen,
Fähigkeiten, Gegner, Quests, Karten – melden die Dateien unter content/ an (siehe registry.py).
"""

MAX_LEVEL = 100
MAX_PLAYERS = 12
PLAYER_SPEED = 6.5       # Einheiten pro Sekunde (Grundwert, Geschick erhöht ihn)
PLAYER_RADIUS = 0.4
SHARE_RADIUS = 16.0      # Umkreis, in dem Mitspieler EP, Gold und Questfortschritt teilen
RESPAWN_TIME = 5.0       # Sekunden bis zur Wiederbelebung

POTION_HEAL = 0.45       # Anteil des maximalen Lebens
POTION_CD = 8.0
POTION_MAX = 9
GEAR_MAX = 40            # Schmiedestufen für Waffe und Rüstung (ab 26 deutlich teurer)
WEAPON_BONUS = 0.04      # Schaden je Waffenstufe
ARMOR_BONUS = 0.03       # Leben je Rüstungsstufe

BASE_ATTR = 5            # Startwert jedes Attributs
ATTR_POINTS = 3          # Attributpunkte pro Stufenaufstieg
MAX_RANK = 5             # höchste Stufe einer Fähigkeit
RANK_BONUS = 0.12        # jede weitere Stufe einer aktiven Fähigkeit: +12 % Wirkung
BAR_SLOTS = 4            # Tasten 1–4

ATTRS = {
    'str': {'name': 'Stärke', 'desc': 'Schaden von Klassen mit Stärke als Hauptattribut. Vergrößert den Ausdauervorrat.'},
    'ges': {'name': 'Geschick', 'desc': 'Schaden von Klassen mit Geschick als Hauptattribut. Mehr kritische Treffer, höheres Lauftempo.'},
    'int': {'name': 'Intelligenz', 'desc': 'Schaden von Klassen mit Intelligenz als Hauptattribut. Mehr Mana, kürzere Abklingzeiten.'},
    'vit': {'name': 'Vitalität', 'desc': 'Mehr Leben, etwas Rüstung und Lebensregeneration.'},
}
RES_NAMES = {'mana': 'Mana', 'ausdauer': 'Ausdauer'}


def xp_needed(level):
    """Erfahrungspunkte für den Aufstieg von `level` auf `level + 1`."""
    return int(60 * level ** 1.6)


def gear_price(tier):
    """Goldpreis für die nächste Schmiedestufe. Über Stufe 25 hinaus wird jede Stufe spürbar teurer."""
    return int(40 * (tier + 1) ** 1.5 * (1 + 0.10 * max(0, tier - 24)))


def potion_price(level):
    return 12 + 2 * level


def respec_price(level):
    return 20 * level


# Gegner mit scale=True (Verliese) wachsen mit ihrer Stufe: Leben etwa so schnell wie der Schaden
# eines Helden gleicher Stufe, Schaden etwa so schnell wie dessen Leben.
def enemy_hp_mult(level):
    return (1 + 0.10 * (level - 1)) * (1 + 0.055 * (level - 1))


def enemy_dmg_mult(level):
    return 1 + 0.10 * (level - 1) + 0.0008 * (level - 1) ** 2


def enemy_xp(base, level):
    return max(1, round(base * level ** 1.45))


def enemy_gold(rng, level):
    f = 1 + 0.15 * (level - 1)
    return (round(rng[0] * f), round(rng[1] * f))


def elixir_price(level):
    return 30 + 10 * level


# ------------------------------------------------------------ Elite-Gegner
# Feste Gegner (keine Bosse) erscheinen mit dieser Chance als Elite: mehr Leben, eine Eigenart,
# dreifache Erfahrung und dreifaches Gold, oft mit Beute.
ELITE_CHANCE = 0.07
ELITE_REWARD = 3.0
ELITE_AFFIXES = {
    'zaeh':    {'name': 'zäh',         'hp': 3.2},
    'flink':   {'name': 'flink',       'hp': 2.2, 'speed': 1.35, 'cd': 0.7},
    'wuetend': {'name': 'wütend',      'hp': 2.2, 'dmg': 1.5},
    'vampir':  {'name': 'blutdurstig', 'hp': 2.4, 'leech': 0.6},
}

# ----------------------------------------------------------------- Elixiere
# Zehn Minuten Wirkung, bleiben über das Abmelden hinaus erhalten. 'xp' = mehr Erfahrung.
ELIXIR_TIME = 600.0
ELIXIRS = {
    'kraft':    {'name': 'Kraftelixier',          'desc': '15 % mehr Schaden',         'mods': {'dmg': 0.15}},
    'stein':    {'name': 'Steinhautelixier',      'desc': '12 % weniger erlittener Schaden', 'mods': {'armor': 0.12}},
    'weisheit': {'name': 'Elixier der Weisheit',  'desc': '25 % mehr Erfahrung',       'mods': {'xp': 0.25}},
}

# ------------------------------------------------------------------- Beute
# Ringe und Amulette mit Zufallswerten. Werte wachsen mit der Gegenstandsstufe (= Stufe des Gegners).
ITEM_SLOTS = {'ring': 'Ring', 'amulett': 'Amulett'}
BAG_MAX = 10
# Wert: (Name in der Anzeige, Grundwert, Beiname des Gegenstands)
ITEM_STATS = {
    'power':         ('Angriffskraft',          0.040, 'der Stärke'),
    'hp_pct':        ('Leben',                  0.050, 'des Lebens'),
    'crit':          ('Kritische Treffer',      0.015, 'des Falken'),
    'crit_dmg':      ('Kritischer Schaden',     0.080, 'der Klinge'),
    'dr':            ('Weniger erlittener Schaden', 0.015, 'des Bollwerks'),
    'speed':         ('Lauftempo',              0.020, 'des Windes'),
    'haste':         ('Angriffstempo',          0.030, 'der Eile'),
    'heal_pct':      ('Heilwirkung',            0.060, 'der Gnade'),
    'res_regen_pct': ('Erholung des Vorrats',   0.080, 'des langen Atems'),
    'kill_heal':     ('Heilung je Sieg',        0.005, 'des Blutdursts'),
}
# Seltenheit: (Name, Farbe, Anzahl Werte, Faktor auf die Werte, Gewicht, Verkaufswert je Stufe)
RARITIES = [
    ('gewöhnlich', '#d8d2c4', 1, 1.0, 60, 4),
    ('magisch',    '#6fb6ff', 2, 1.0, 30, 8),
    ('selten',     '#ffd36a', 3, 1.1, 9, 16),
    ('legendär',   '#ff8a3a', 4, 1.3, 1, 40),
]
DROP_CHANCE = {'normal': 0.015, 'elite': 0.4, 'boss': 1.0}


def item_scale(ilvl):
    """Faktor auf die Grundwerte: Stufe 1 = 0,5, Stufe 40 = 1,5, Stufe 100 = 3."""
    return 0.475 + ilvl * 0.025
