# Burg Rabenfels

Neue Klassen, Karten, Quests oder Gegner? Lies zuerst `AGENTS.md` – dort stehen Arbeitsablauf,
alle Angaben und die Werkzeuge. Kurzfassung:

- Inhalte liegen als Daten unter `content/`; `game/engine.py` und `static/js/` bleiben unberührt.
- Gerüst anlegen: `python tools/neu.py klasse|karte|gegner|quest ID …`
- Prüfen: `python tools/pruefen.py`, dann `python tools/pruefen.py --spiel`, am Ende `python test_spiel.py`
- Sichtbare Texte sind deutsch.
