"""Legt ein spielbares Gerüst für neue Inhalte an – danach nur noch anpassen statt von null beginnen.

  python tools/neu.py klasse paladin --name Paladin --stil klinge
  python tools/neu.py karte  moor --name "Das Moor" --groesse 34x26 --licht tag
  python tools/neu.py karte  mine --name "Alte Mine" --licht dunkel --verlies
  python tools/neu.py gegner sumpfhexe --name Sumpfhexe --stufe 6 --fern
  python tools/neu.py quest  hexenjagd --npc moor_hueter --art kill --ziel sumpfhexe --anzahl 5

Jedes Gerüst ist sofort gültig: Die Klasse hat 20 aktive und 9 passive Fähigkeiten (jede Grundform
kommt vor), die Karte hat Start, Bewohner, Gegnergebiet, Rückweg und einen Eingang auf der Hauptkarte.
Texte, die nur du schreiben kannst, sind mit TODO markiert; `python tools/pruefen.py` zählt sie auf.

  --ordner ORDNER   Zielordner statt content/ (z. B. zum Ausprobieren; laden mit --extra bzw. RABENFELS_CONTENT)
"""
import argparse
import math
import os
import re
import sys

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
sys.path.insert(0, ROOT)
import game                                              # noqa: E402
from game import registry as R, world as W                # noqa: E402
from game.data import xp_needed                           # noqa: E402

PALETTE = ['#e6c35a', '#6fd0c8', '#e58fd0', '#f09a4a', '#7fa8f0', '#c9e06a', '#d98a8a', '#9fe0a0']
SHOT_KIND = {'feuer': 'fire', 'frost': 'ice', 'blitz': 'arkan', 'arkan': 'arkan', 'gift': 'poison',
             'stich': 'arrow', 'schnitt': 'arrow', 'wucht': 'welle'}


def de(x):
    """Zahl in deutscher Schreibweise: 2.5 -> '2,5', 8.0 -> '8'."""
    return f'{x:g}'.replace('.', ',')


def sek(x):
    return '1 Sekunde' if x == 1 else f'{de(x)} Sekunden'


def shade(color, f):
    """Farbe abdunkeln (f < 1) oder aufhellen (f > 1)."""
    r, g, b = (int(color[i:i + 2], 16) for i in (1, 3, 5))
    return '#%02x%02x%02x' % tuple(max(0, min(255, round(v * f))) for v in (r, g, b))


def fail(msg):
    print(msg)
    sys.exit(1)


def taken(id):
    """Wo ist diese Kennung schon vergeben?"""
    npcs = {nid for m in R.MAPS.values() for nid in m['npcs']}
    for label, table in (('Klasse', R.CLASSES), ('Fähigkeit', R.SKILLS), ('Gegner', R.ENEMIES), ('Quest', R.QUESTS),
                         ('Karte', R.MAPS), ('Bewohner', npcs)):
        if id in table:
            return label
    return None


def write(folder, rel, text, append=False):
    path = os.path.join(folder, rel)
    os.makedirs(os.path.dirname(path), exist_ok=True)
    if os.path.exists(path) and not append:
        fail(f'{path} gibt es schon. Wähle eine andere Kennung oder bearbeite die Datei direkt.')
    with open(path, 'a' if append else 'w', encoding='utf-8') as f:
        f.write(text)
    return path


# ====================================================================== Klasse
STYLE = {
    'klinge': {
        'stats': "hp=150, hp_lvl=18, dmg=15, armor=0.25, main='str', res='ausdauer'",
        'atk': "{{'name': 'Hieb', 'type': 'melee', 'cd': 0.55, 'range': 2.7, 'arc': 2.0, 'tag': '{tag}'}}",
        'look': "{{'cloth': '{dark}', 'legs': '#4a4038', 'arms': '#9aa1a8', 'hat': 'helmet', 'plume': '{color}',\n"
                "          'weapon': 'sword', 'shield': '#6f757d', 'pads': '#9aa1a8', 'scale': 1.12}}",
        'tags': [('schnitt', 'blutend'), ('wucht', 'wankend'), ('blitz', 'geschockt')],
        'branches': ['Angriff', 'Schutz', 'Ansturm'],
    },
    'magie': {
        'stats': "hp=85, hp_lvl=9, dmg=18, armor=0.0, main='int', res='mana'",
        'atk': "{{'name': 'Geschoss', 'type': 'shot', 'kind': '{kind}', 'cd': 0.75, 'range': 15.0, 'speed': 17.0,\n"
               "         'splash': 1.8, 'tag': '{tag}'}}",
        'look': "{{'cloth': '{dark}', 'robe': '{darker}', 'hat': 'wizard', 'hatColor': '{darker}', 'weapon': 'staff',\n"
                "          'orb': '{color}', 'scale': 1.1}}",
        'tags': [('feuer', 'brennend'), ('frost', 'gefroren'), ('arkan', 'markiert')],
        'branches': ['Zerstörung', 'Schutz', 'Beweglichkeit'],
    },
    'bogen': {
        'stats': "hp=105, hp_lvl=12, dmg=12, armor=0.08, main='ges', res='ausdauer'",
        'atk': "{{'name': 'Schuss', 'type': 'shot', 'kind': 'arrow', 'cd': 0.45, 'range': 17.0, 'speed': 26.0,\n"
               "         'splash': 0.0, 'tag': '{tag}'}}",
        'look': "{{'cloth': '{dark}', 'legs': '#5a4630', 'arms': '{darker}', 'hat': 'hood', 'hatColor': '{darker}',\n"
                "          'bow': True, 'cape': '{darker}', 'scale': 1.1}}",
        'tags': [('stich', 'markiert'), ('gift', 'vergiftet'), ('schnitt', 'blutend')],
        'branches': ['Treffsicherheit', 'Wildnis', 'Beweglichkeit'],
    },
}


def describe(form, tag, p, res_name):
    """Ehrliche Beschreibung einer Fähigkeit aus ihren Angaben – als Ausgangspunkt für den eigenen Text."""
    dur = sek(p['dur']) if 'dur' in p else ''
    if form == 'arc':
        t = 'Trifft alle Gegner direkt vor dir.'
        if p.get('hits', 1) > 1:
            t = f"{p['hits']} schnelle Treffer auf alle Gegner direkt vor dir."
    elif form == 'nova':
        t = 'Trifft alle Gegner rings um dich.' if p.get('mult') else 'Wirkt auf alle Gegner rings um dich.'
    elif form == 'shot':
        t = f"{p['count']} Geschosse in einem Fächer." if p.get('count', 1) > 1 else 'Ein Geschoss in Zielrichtung.'
        if p.get('pierce'):
            t += ' Es durchschlägt alle Gegner in seiner Bahn.'
    elif form == 'blast':
        t = ('Nach kurzem Ausholen trifft ein Einschlag alles um dich.' if p.get('at_self')
             else 'Nach kurzer Verzögerung schlägt es an der Stelle des Mauszeigers ein.')
    elif form == 'zone':
        if p.get('ally'):
            t = f'Ein Kreis um dich schützt und heilt {dur} lang alle Gefährten darin.'
        elif p.get('follow'):
            t = f'{dur} lang nehmen Gegner um dich herum laufend Schaden.'
        else:
            t = f'Ein Feld am Mauszeiger schadet {dur} lang allem darin.'
    elif form == 'dash':
        t = ('Du springst an die Stelle des Mauszeigers und schlägst dort ein.' if p.get('leap')
             else 'Du schnellst in Zielrichtung' + (' und triffst alles am Ziel.' if p.get('r') else '.'))
    elif form == 'chain':
        t = f"Ein Schlag, der von Gegner zu Gegner springt – bis zu {p['n']} Ziele."
    elif form == 'heal':
        t = f"Heilt dich und Gefährten in der Nähe um {de(p['pct'] * 100)} % ihres Lebens."
    else:                                                                    # buff
        who = 'Du und Gefährten in der Nähe' if p.get('r') else 'Du'
        verb = 'habt' if p.get('r') else 'hast'
        mods = {'dmg': 'mehr Schaden', 'armor': 'mehr Schutz', 'haste': 'schnellere Angriffe', 'speed': 'mehr Lauftempo',
                'crit': 'mehr kritische Treffer', 'lifesteal': 'Heilung durch Treffer', 'regen': 'Erholung',
                'res_pct': f'mehr {res_name}'}
        if p.get('absorb'):
            t = f"Ein Schild fängt {dur} lang Schaden in Höhe von {de(p['absorb'] * 100)} % deines Lebens ab."
        else:
            t = f"{who} {verb} {dur} lang {' und '.join(mods[k] for k in p['mods'])}."
    if p.get('apply'):
        t += f" Getroffene sind danach {R.STATUS[p['apply']]['name'].lower()}."
    if p.get('stun'):
        t += f" Betäubt {sek(p['stun'])}."
    if p.get('slow'):
        t += ' Verlangsamt.'
    if p.get('execute'):
        t += ' Trifft Gegner unter einem Drittel Leben um die Hälfte härter.'
    if p.get('fade'):
        t += ' Gegner lassen kurz von dir ab.'
    return t


def class_file(id, name, style, color):
    s = STYLE[style]
    for tag, st in s['tags']:
        if tag not in R.TAGS or st not in R.STATUS:
            fail(f"Der Stil '{style}' braucht die Schadensart '{tag}' und den Zustand '{st}' – eine davon fehlt in den Inhalten.")
    (t0, s0), (t1, s1), (t2, s2) = s['tags']
    res_name = 'Mana' if "'mana'" in s['stats'] else 'Ausdauer'
    melee = style == 'klinge'

    def strike(tag, **extra):                      # der typische Einzeltreffer der Klasse
        if melee:
            return 'arc', {'range': 3.0, 'arc': 2.2, **extra}
        speed, rng = (28.0, 18.0) if style == 'bogen' else (20.0, 16.0)
        return 'shot', {'speed': speed, 'range': rng, **extra, 'kind': SHOT_KIND.get(tag, 'arkan')}

    def placed(**extra):                           # Flächen: Nahkämpfer um sich selbst, Fernkämpfer am Mauszeiger
        return {**extra, 'at_self': True} if melee else {'range': 13.0, **extra}

    dot0 = ('dot_' + s0, 0.15, f"{R.STATUS[s0]['name']}: {{v}} % mehr Schaden über Zeit.") if R.STATUS[s0].get('dot') \
        else ('status_dur', 0.10, 'Zustände, die du verursachst, halten {v} % länger.')
    A, P = 'active', 'passive'
    # (Art, Zweig, Stufe, Kürzel, Name, Form/Wert, Schadensart, Kosten, Abklingzeit, Angaben)
    nodes = [
        # ---- Zweig 0: Schaden
        (A, 0, 1, 'angriff', 'Schneller Angriff', *strike(t0, mult=1.5, apply=s0), t0, 15, 5),
        (A, 0, 3, 'rundum', 'Rundumschlag', 'nova', {'r': 3.6, 'mult': 1.4}, t0, 20, 6),
        (P, 0, 6, 'p_kunde', 'Waffenkunde', 'dmg_' + t0, 0.04, f"{R.TAGS[t0]['name']}schaden +{{v}} %."),
        (A, 0, 8, 'schwer', 'Schwerer Angriff', *strike(t0, mult=2.4), t0, 25, 8),
        (A, 0, 14, 'einschlag', 'Einschlag', 'blast', placed(r=3.5, delay=0.6, mult=2.6), t0, 30, 12),
        (P, 0, 16, 'p_nachwirkung', 'Nachwirkung', *dot0),
        (A, 0, 22, 'dauer', 'Dauerangriff', 'zone',
         {'r': 3.4, 'dur': 2.4, 'tick': 0.4, 'mult': 0.55, 'follow': True} if melee
         else {'range': 14.0, 'r': 4.5, 'dur': 4.0, 'tick': 0.4, 'mult': 0.5}, t0, 30, 12),
        (P, 0, 26, 'p_blick', 'Scharfer Blick', 'crit', 0.02, 'Chance auf kritische Treffer +{v} %.'),
        (A, 0, 32, 'gnadenstoss', 'Gnadenstoß', *strike(t0, mult=3.0, execute=True), t0, 30, 10),
        (A, 0, 45, 'vernichtung', 'Vernichtung', 'blast', placed(r=6.0, delay=0.7, mult=4.5, apply=s0), t0, 50, 40),
        # ---- Zweig 1: Schutz und Unterstützung
        (A, 1, 2, 'stoss', 'Stoß', 'arc', {'range': 2.6, 'arc': 1.6, 'mult': 1.2, 'apply': s1, 'stun': 1.0}, t1, 15, 7),
        (P, 1, 4, 'p_zaeh', 'Zähigkeit', 'hp_pct', 0.04, 'Maximales Leben +{v} %.'),
        (A, 1, 5, 'ruf', 'Schlachtruf', 'buff', {'r': 9.0, 'dur': 8.0, 'mods': {'dmg': 0.3}}, 'hilfe', 25, 18),
        (A, 1, 10, 'hilfe', 'Erste Hilfe', 'heal', {'r': 8.0, 'pct': 0.3}, 'hilfe', 30, 16),
        (P, 1, 14, 'p_fell', 'Dickes Fell', 'dr', 0.03, 'Erlittener Schaden −{v} %.'),
        (A, 1, 16, 'erschuetterung', 'Erschütterung', 'nova', {'r': 4.8, 'mult': 1.5, 'apply': s1, 'slow': 3.0}, t1, 25, 9),
        (A, 1, 24, 'schild', 'Schutzschild', 'buff', {'dur': 8.0, 'absorb': 0.3}, 'hilfe', 25, 20),
        (P, 1, 28, 'p_atem', 'Langer Atem', 'res_regen_pct', 0.08, f'{res_name} erholt sich {{v}} % schneller.'),
        (A, 1, 34, 'kreis', 'Schutzkreis', 'zone',
         {'r': 6.0, 'dur': 10.0, 'tick': 1.0, 'mult': 0, 'at_self': True, 'ally': {'armor': 0.25, 'regen': 0.02}}, 'hilfe', 35, 30),
        (A, 1, 48, 'welle', 'Schockwelle', 'shot',
         {'speed': 14.0, 'range': 14.0, 'size': 1.2, 'mult': 2.6, 'pierce': True, 'apply': s1, 'kind': 'welle'}, t1, 35, 14),
        # ---- Zweig 2: Beweglichkeit
        (A, 2, 4, 'vorstoss', 'Vorstoß', 'dash', {'dist': 7.0, 'r': 2.6, 'mult': 1.5}, t2, 20, 9),
        (P, 2, 8, 'p_fuss', 'Leichtfüßig', 'speed', 0.02, 'Lauftempo +{v} %.'),
        (A, 2, 12, 'eile', 'Eile', 'buff', {'dur': 8.0, 'mods': {'haste': 0.4}}, 'hilfe', 20, 20),
        (A, 2, 18, 'kette', 'Kettenschlag', 'chain', {'range': 12.0, 'jump': 6.0, 'n': 4, 'mult': 1.5, 'apply': s2}, t2, 18, 5),
        (P, 2, 20, 'p_haende', 'Schnelle Hände', 'haste', 0.03, 'Angriffstempo +{v} %.'),
        (A, 2, 28, 'sprung', 'Sprungangriff', 'dash', {'dist': 9.0, 'leap': True, 'r': 3.6, 'mult': 2.2}, t2, 30, 12),
        (P, 2, 34, 'p_kombi', 'Zusammenspiel', 'combo', 0.10, 'Kombos richten {v} % mehr Zusatzschaden an.'),
        (A, 2, 40, 'blendung', 'Blendung', 'nova', {'r': 5.0, 'mult': 0, 'stun': 1.5, 'fade': True}, None, 20, 16),
        (A, 2, 60, 'entfesselung', 'Entfesselung', 'nova', {'r': 7.5, 'mult': 3.2, 'apply': s2}, t2, 55, 40),
    ]
    dark, darker = shade(color, 0.6), shade(color, 0.45)
    out = [
        f'"""{name}: Gerüst von tools/neu.py – spielbar, aber noch ohne eigenes Gesicht.',
        '',
        'Anpassen: Namen und Beschreibungen (TODO), Aussehen, Schadensarten, Werte. Kennungen der Fähigkeiten',
        'dürfen umbenannt werden, solange sie im ganzen Spiel eindeutig bleiben und `start` dazu passt.',
        'Ansehen: python tools/pruefen.py --klasse ' + id,
        '"""',
        'from game.registry import active, passive, player_class',
        '',
        f"C = '{id}'",
        'player_class(',
        f"    C, name={name!r}, color='{color}',",
        "    desc='TODO: Ein bis zwei Sätze, die auf dem Auswahlbild neben der Klasse stehen.',",
        f"    {s['stats']},",
        '    atk=' + s['atk'].format(tag=t0, kind=SHOT_KIND.get(t0, 'arkan')) + ',',
        '    look=' + s['look'].format(color=color, dark=dark, darker=darker) + ',',
        f"    branches=[({s['branches'][0]!r}, 'TODO: Wofür dieser Zweig steht'),",
        f"              ({s['branches'][1]!r}, 'TODO: Wofür dieser Zweig steht'),",
        f"              ({s['branches'][2]!r}, 'TODO: Wofür dieser Zweig steht')],",
        f"    start='{id}_angriff',",
        ')',
    ]
    branch = -1
    for kind, b, lvl, key, title, *rest in nodes:
        if b != branch:
            branch = b
            out += ['', f"# --- Zweig {b}: {s['branches'][b]}"]
        if kind == P:
            stat, per, desc = rest
            out.append(f"passive('{id}_{key}', C, {b}, {lvl}, {title!r}, '{stat}', {per}, {desc!r})")
        else:
            form, params, tag, cost, cd = rest
            args = ', '.join(f'{k}={v!r}' for k, v in params.items())
            desc = describe(form, tag, params, res_name)
            out.append(f"active('{id}_{key}', C, {b}, {lvl}, {title!r}, '{form}', {tag!r}, {cost}, {cd},\n"
                       f"       {desc!r},\n       {args})")
    return '\n'.join(out) + '\n'


def new_class(a):
    name = a.name or a.id.capitalize()
    color = a.farbe or PALETTE[sum(map(ord, a.id)) % len(PALETTE)]
    if not R.COLOR_RE.match(color) or len(color) != 7:
        fail(f"--farbe {color!r} ist keine Farbe der Form #rrggbb.")
    return write(a.ordner, os.path.join('klassen', a.id + '.py'), class_file(a.id, name, a.stil, color))


# ======================================================================= Karte
def find_entrance(mid):
    """Freie Kachel auf Karte `mid` für einen Übergang: erreichbar, rundum frei, abseits von Gegnern und Bewohnern."""
    b, m, T = W.MAPS[mid], R.MAPS[mid], W.TILE
    here = {(tx - b['ox'], tz) for (tx, tz) in W.PORTAL_AT if b['ox'] <= tx < b['ox'] + b['w']}
    avoid = [(m['start'], 3.0)]
    avoid += [((n['x'] - b['ox'], n['z']), 3.0) for n in W.NPCS.values() if n['map'] == mid]
    avoid += [((x / T - b['ox'], z / T), 2.0) for _, x, z, pm in W.PICKUPS if pm == mid]
    avoid += [((x + 0.5, z + 0.5), 4.0) for x, z in here]
    avoid += [((p['x'] / T - b['ox'], p['z'] / T), 3.0) for p in W.PORTAL_AT.values() if p['to'] == mid]
    hostile = [z['leash'] for z in b['zones'].values()]
    best = None
    for x, z in b['reach']:
        if any((x + dx, z + dz) not in b['reach'] or (x + dx, z + dz) in here for dx in (-1, 0, 1) for dz in (-1, 0, 1)):
            continue
        cx, cz = x + 0.5, z + 0.5
        if any(math.hypot(cx - ax, cz - az) < r for (ax, az), r in avoid):
            continue
        if any(W.in_rect((b['ox'] + cx) * T, cz * T, rect) for rect in hostile):
            continue
        cand = (math.hypot(cx - m['start'][0], cz - m['start'][1]), z, x)
        best = min(best, cand) if best else cand
    return (best[2], best[1]) if best else None


def make_plan(w, h, dark):
    """Ankunftsbereich oben, darunter – hinter einer Engstelle – das Gegnergebiet."""
    wall, ground, path, prop = ('M', 'k', 'k', 'P') if dark else ('T', ',', ':', 'R')
    cx = w // 2
    rows = []
    for z in range(h):
        row = ''
        for x in range(w):
            mid = x in (cx - 1, cx)
            if x in (0, w - 1) or z in (0, h - 1) or (z == 6 and not mid):
                row += wall
            elif z == 1 and mid:
                row += '1'
            elif mid and z < 9:
                row += path
            elif z >= 10 and z < h - 2 and 2 < x < w - 3 and x % 6 == 3 and z % 5 == 0:
                row += prop
            else:
                row += ground
        rows.append(row)
    return rows, cx


def new_map(a):
    name = a.name or a.id.capitalize()
    try:
        w, h = (int(v) for v in a.groesse.lower().split('x'))
    except ValueError:
        fail(f"--groesse {a.groesse!r}: erwartet wird BREITExHÖHE, z. B. 30x24.")
    if not (16 <= w <= W.MAX_SIZE and 16 <= h <= W.MAX_SIZE):
        fail(f'--groesse: das Gerüst braucht 16 bis {W.MAX_SIZE} Kacheln je Richtung.')
    dark = a.licht == 'dunkel'
    rows, cx = make_plan(w, h, dark)

    # Eingang auf einer bestehenden Karte
    src = W.MAIN
    at = None
    if a.eingang:
        match = re.match(r'^(?:(\w+):)?(\d+),(\d+)$', a.eingang)
        if not match or (match.group(1) or src) not in W.MAPS:
            fail(f"--eingang {a.eingang!r}: erwartet wird KARTE:X,Z oder X,Z (Kachel auf der Hauptkarte '{W.MAIN}').")
        src, at = match.group(1) or src, (int(match.group(2)), int(match.group(3)))
        if at not in W.MAPS[src]['reach'] or (at[0], at[1] + 1) not in W.MAPS[src]['reach']:
            fail(f"--eingang: die Kachel {at} auf Karte '{src}' und die Kachel darunter müssen begehbar und erreichbar sein. "
                 f"Plan ansehen: python tools/pruefen.py --karte {src}")
    else:
        at = find_entrance(src)
        if not at:
            fail(f"Auf Karte '{src}' ist keine freie Kachel für den Eingang zu finden. Gib sie an: --eingang X,Z")
    back = (at[0] + 0.5, at[1] + 1.5)                             # Rückkehr: eine Kachel unterhalb des Eingangs

    zone = 'halle' if a.verlies else 'wildnis'
    rect = (2, 8, w - 3, h - 3)
    npc = a.id + '_hueter'
    if taken(npc):
        fail(f"Die Bewohner-Kennung '{npc}' ist schon vergeben.")
    lamp = 'ghost' if dark else 'torch'
    deco = [(lamp, cx - 2.5, 1.5), (lamp, cx + 2.5, 1.5), (lamp, cx - 1.5, 7.5), (lamp, cx + 1.5, 7.5)]
    if dark:                                                       # ohne Lichter ist eine dunkle Karte schwarz
        deco += [(lamp, x + 0.5, z + 0.5) for z in range(12, h - 3, 6) for x in (2, w - 3)]
    out = [
        f'"""{name}: Gerüst von tools/neu.py – begehbar und angeschlossen, aber noch leer.',
        '',
        'Anpassen: Plan (ein Zeichen je Kachel, Zeichen siehe AGENTS.md), Ortsnamen, Bewohner, Gegner, Lichter.',
        f'Ansehen: python tools/pruefen.py --karte {a.id}     Alle Koordinaten sind Kacheln dieser Karte: (x, z).',
        '"""',
        'from game.registry import game_map, portal',
        '',
        'game_map(',
        f"    '{a.id}', name={name!r}, light='{a.licht}', floor='{'k' if dark else ','}', start=({cx}, 3.5),",
        '    plan="""',
        *('    ' + r for r in rows),
        '    """,',
        '    regions=[',
        f"        ('TODO Name des Ankunftsorts', (1, 1, {w - 2}, 5)),",
        f"        ({name!r}, (0, 0, {w - 1}, {h - 1})),",
        '    ],',
    ]
    if a.verlies:
        mix = [k for k, e in R.ENEMIES.items() if e.get('scale') and not e.get('boss')]
        boss = next((k for k, e in R.ENEMIES.items() if e.get('scale') and e.get('boss')), None)
        if not mix:
            fail('Für ein Verlies fehlt eine Gegnerart mit scale=True. Lege eine an: python tools/neu.py gegner ID --verlies')
        first = [1, 1, 3, 6, 9, 12, 15, 18]
        entries = ', '.join(f"('{k}', {first[min(i, 7)]}, {max(2, 5 - i)})" for i, k in enumerate(mix[:8]))
        out += [
            "    # margin 2 schließt die Engstelle ein: Wer sie betritt, weckt die nächste Ebene.",
            f"    zones={{'{zone}': {{'rect': {rect}, 'margin': 2}}}},",
            '    npcs={',
            f"        '{npc}': {{",
            f"            'name': 'TODO Name', 'role': 'TODO Rolle', 'at': ({cx + 3.5}, 3.5),",
            "            'look': {'cloth': '#2f2a3c', 'robe': '#262232', 'hat': 'hood', 'weapon': 'staff', 'orb': '#59ffc0', 'scale': 1.12},",
            "            'greet': 'TODO: Begrüßung – erklärt, dass hinter der Engstelle das Verlies beginnt.',",
            "            'services': ['dungeon'],                 # lässt Helden auf einer früheren Ebene wieder einsteigen",
            '        },',
            '    },',
            f"    portals={{'1': {{'to': '{src}', 'target': {back}}}}},        # Ziffer 1 im Plan: zurück",
            '    deco=[' + ', '.join(f"('{k}', {x}, {z})" for k, x, z in deco) + '],',
            '    # Endloses Verlies: Gegnerstufe = base_level + Ebene. mix: (Gegnerart, ab Ebene, Gewicht).',
            '    dungeon={',
            f"        'zone': '{zone}', 'base_level': {a.stufe or 7},",
            f"        'mix': [{entries}],",
            *([f"        'boss': '{boss}', 'boss_every': 5,"] if boss else []),
            '    },',
        ]
    else:
        fixed = [(e['lvl'], k) for k, e in R.ENEMIES.items() if not e.get('scale') and not e.get('boss') and e.get('respawn')]
        if a.gegner:
            if a.gegner not in R.ENEMIES or R.ENEMIES[a.gegner].get('scale'):
                fail(f"--gegner {a.gegner!r}: gesucht ist eine Gegnerart mit fester Stufe. Vorhanden: {', '.join(k for _, k in sorted(fixed))}")
            foe = a.gegner
        elif not fixed:
            fail('Es gibt keine Gegnerart mit fester Stufe. Lege eine an: python tools/neu.py gegner ID --stufe N')
        else:
            foe = min(fixed, key=lambda f: (abs(f[0] - (a.stufe or 99)), f[1]))[1]
        count = max(4, min(14, (rect[2] - rect[0]) * (rect[3] - rect[1]) // 45))
        out += [
            "    # Gegnergebiet. margin: so weit verfolgen die Gegner einen Helden über das Rechteck hinaus.",
            f"    zones={{'{zone}': {{'rect': {rect}, 'margin': 1}}}},",
            f"    spawns=[('{foe}', '{zone}', {count})],",
            '    npcs={',
            f"        '{npc}': {{",
            f"            'name': 'TODO Name', 'role': 'TODO Rolle', 'at': ({cx + 3.5}, 3.5),",
            "            'look': {'cloth': '#5a6a4a', 'legs': '#4a3a28', 'hat': 'hood', 'weapon': 'staff', 'scale': 1.1},",
            "            'greet': 'TODO: Begrüßung.',",
            '        },',
            '    },',
            f"    portals={{'1': {{'to': '{src}', 'target': {back}}}}},        # Ziffer 1 im Plan: zurück",
            '    deco=[' + ', '.join(f"('{k}', {x}, {z})" for k, x, z in deco) + '],',
        ]
    out += [
        ')',
        '',
        f"# Eingang: Diese Kachel der Karte '{src}' führt hierher (Ankunft am Startpunkt). Sie wird zur Treppe mit Lichtsäule.",
        f"portal('{src}', at={at}, to='{a.id}')",
    ]
    return write(a.ordner, os.path.join('karten', a.id + '.py'), '\n'.join(out) + '\n')


# ====================================================================== Gegner
def new_enemy(a):
    name = a.name or a.id.capitalize()
    lvl = a.stufe or 5
    if a.tier:
        look = "{'body': 'beast', 'fur': '#5a4a3c', 'dark': '#40342a', 'eyeGlow': '#ffd23a', 'scale': 1.1}"
    elif a.fern:
        look = ("{'skin': '#b9c4b0', 'cloth': '#3a2a52', 'robe': '#2f2244', 'hat': 'hood', 'hatColor': '#2f2244',\n"
                "            'weapon': 'staff', 'orb': '#b38cff', 'eyeGlow': '#b38cff', 'scale': 1.05}")
    else:
        look = "{'skin': '#b08a6a', 'cloth': '#5a3a2c', 'legs': '#3a2c22', 'weapon': 'club', 'scale': 1.0}"
    ranged = ', shot=10.0' if a.fern else ''
    reach = 11.0 if a.fern else 1.6
    if a.verlies:
        hp, dmg = (48, 10) if a.fern else (70, 9)
        head = (f"# Wächst mit der Ebene (Werte gelten für Stufe 1). Eintragen in dungeon['mix'] einer Karte.\n"
                f"enemy('{a.id}', {name!r}, scale=True, hp={hp}, dmg={dmg}, speed=4.2, radius=0.5, aggro=60.0, range={reach}, "
                f"cd={2.4 if a.fern else 1.4},\n      xp=2.0, gold=(2, 4){ranged},")
    else:
        hp = round((26 + 8 * lvl + 1.9 * lvl * lvl) * (0.7 if a.fern else 1))
        xp = round(6 + 3.5 * lvl + 1.15 * lvl * lvl)
        head = (f"# Feste Stufe. Eintragen in spawns einer Karte: ('{a.id}', '<Zone>', Anzahl).\n"
                f"enemy('{a.id}', {name!r}, lvl={lvl}, hp={hp}, dmg={1 + 2 * lvl}, speed=4.4, radius=0.5, aggro=8.0, range={reach}, "
                f"cd={2.4 if a.fern else 1.3},\n      xp={xp}, gold=({lvl}, {2 * lvl + 1}), respawn=15{ranged},")
    block = f"{head}\n      look={look})\n"
    rel = a.datei or 'gegner.py'
    path = os.path.join(a.ordner, rel)
    if os.path.exists(path):
        text = open(path, encoding='utf-8').read()
        needs_import = not re.search(r'^from game\.registry import .*\benemy\b', text, re.M)
        return write(a.ordner, rel, '\n' + ('from game.registry import enemy\n' if needs_import else '') + block, append=True)
    return write(a.ordner, rel, f'"""Gegnerarten (Gerüst von tools/neu.py)."""\nfrom game.registry import enemy\n\n{block}')


# ======================================================================= Quest
def new_quest(a):
    if not a.npc:
        fail('Eine Quest braucht einen Bewohner: --npc KENNUNG. Vorhanden: ' + ', '.join(W.NPCS))
    if a.npc not in W.NPCS:
        fail(f"Bewohner '{a.npc}' gibt es nicht. Vorhanden: {', '.join(W.NPCS)}")
    home = W.NPCS[a.npc]['map']
    kind, target, count = a.art, a.ziel, a.anzahl
    minlvl = a.stufe or 1
    goal, where = 'TODO: Kurzform des Ziels', R.MAPS[home]['name']
    xp = None
    if kind == 'kill':
        target = target or 'map:' + home
        count = count or 8
        if target in R.ENEMIES:
            e = R.ENEMIES[target]
            goal = f"{e['name']} besiegen"
            maps = [m['name'] for m in R.MAPS.values() if any(sp[0] == target for sp in m['spawns'])]
            where = maps[0] if maps else where
            if not e.get('scale'):
                xp, minlvl = max(50, round(count * e['xp'], -1)), a.stufe or max(1, e['lvl'] - 2)
        elif target.startswith('map:'):
            goal = f"Gegner besiegen: {R.MAPS.get(target[4:], {}).get('name', target[4:])}"
        else:
            goal = 'Gegner besiegen'
    elif kind == 'collect':
        if not target:
            fail('--art collect braucht --ziel QUESTGEGENSTAND. Vorhanden: ' + ', '.join(R.PICKUPS))
        count = count or 4
        if target in R.PICKUPS:
            goal = f"{R.PICKUPS[target]['name']} einsammeln"
    elif kind == 'combo':
        target, count, goal, where = 'any', count or 10, 'Kombos auslösen', 'überall'
    else:                                                          # depth
        dungeons = [mid for mid, m in R.MAPS.items() if m['dungeon']]
        if not dungeons:
            fail('--art depth braucht eine Karte mit Verlies – es gibt noch keine.')
        target = target or (home if home in dungeons else dungeons[0])
        count = count or 5
        if target in dungeons:                                     # Mindeststufe und Lohn nach der Stärke des Verlieses
            minlvl = a.stufe or max(1, R.MAPS[target]['dungeon']['base_level'] - 1)
            xp = round(xp_needed(minlvl) * (1 + count / 4), -2)
        goal, where = f"Ebene schaffen: {R.MAPS.get(target, {}).get('name', target)}", R.MAPS.get(target, {}).get('name', where)
    if a.wiederholbar:
        reward = 'xp_pct=0.25, gold_lvl=12'                        # wächst mit der Stufe des Helden
    else:
        xp = xp or max(60, round(xp_needed(minlvl) * 0.9, -1))
        reward = f'xp={int(xp)}, gold={max(10, int(round(xp / 5, -1)))}'
    giver = 'der Bewohner' if 'TODO' in W.NPCS[a.npc]['name'] else W.NPCS[a.npc]['name']
    cond = ''.join([f", req='{a.nach}'" if a.nach else '', f', minlvl={minlvl}' if minlvl > 1 else '',
                    ', repeat=True' if a.wiederholbar else ''])
    block = (f"quest('{a.id}', title='TODO Titel', npc='{a.npc}', type='{kind}', target='{target}', count={count},\n"
             f"      goal={goal!r}, where={where!r},\n"
             f"      {reward}{cond},\n"
             f"      text='TODO: Der Auftrag, wie ihn {giver} ausspricht.',\n"
             f"      done='TODO: Der Dank bei der Abgabe.')\n")
    rel = a.datei or os.path.join('quests', a.id + '.py')
    path = os.path.join(a.ordner, rel)
    if os.path.exists(path):
        text = open(path, encoding='utf-8').read()
        needs_import = not re.search(r'^from game\.registry import .*\bquest\b', text, re.M)
        return write(a.ordner, rel, '\n' + ('from game.registry import quest\n' if needs_import else '') + block, append=True)
    return write(a.ordner, rel, f'"""Quests (Gerüst von tools/neu.py)."""\nfrom game.registry import quest\n\n{block}')


# ======================================================================== Start
def main():
    ap = argparse.ArgumentParser(description='Gerüst für neue Inhalte anlegen.',
                                 epilog='Danach: Datei anpassen, python tools/pruefen.py, python tools/pruefen.py --spiel')
    ap.add_argument('art', choices=['klasse', 'karte', 'gegner', 'quest'])
    ap.add_argument('id', help='Kennung: Kleinbuchstaben, Ziffern, _')
    ap.add_argument('--name', help='Anzeigename')
    ap.add_argument('--ordner', default=R.CONTENT_DIR, help='Zielordner (Vorgabe: content/)')
    ap.add_argument('--datei', help='gegner, quest: an diese Datei im Zielordner anhängen, z. B. quests/moor.py')
    ap.add_argument('--stufe', type=int, help='gegner: Stufe · quest: Mindeststufe · karte: passende Gegner bzw. base_level')
    g = ap.add_argument_group('klasse')
    g.add_argument('--stil', choices=sorted(STYLE), default='klinge', help='Nahkampf, Zauber oder Bogen (Vorgabe: klinge)')
    g.add_argument('--farbe', help='Klassenfarbe #rrggbb')
    g = ap.add_argument_group('karte')
    g.add_argument('--groesse', default='30x24', help='BREITExHÖHE in Kacheln (Vorgabe: 30x24)')
    g.add_argument('--licht', choices=['tag', 'dunkel'], default='tag')
    g.add_argument('--verlies', action='store_true', help='karte: endloses Verlies · gegner: wächst mit der Ebene')
    g.add_argument('--eingang', metavar='[KARTE:]X,Z', help='Kachel des Eingangs (sonst wird eine freie gesucht)')
    g.add_argument('--gegner', help='Gegnerart für das Gegnergebiet')
    g = ap.add_argument_group('gegner')
    g.add_argument('--tier', action='store_true', help='vierbeiniges Tier statt Gestalt')
    g.add_argument('--fern', action='store_true', help='Fernkämpfer mit Geschossen')
    g = ap.add_argument_group('quest')
    g.add_argument('--npc', help='Bewohner, der die Quest vergibt')
    g.add_argument('--art', dest='art2', choices=['kill', 'collect', 'combo', 'depth'], default='kill')
    g.add_argument('--ziel', help='Gegnerart, map:<Karte>, any, Questgegenstand oder Karte mit Verlies')
    g.add_argument('--anzahl', type=int)
    g.add_argument('--nach', help='Quest, die vorher abgeschlossen sein muss')
    g.add_argument('--wiederholbar', action='store_true')
    a = ap.parse_args()
    a.kind, a.art = a.art, a.art2
    a.ordner = os.path.abspath(a.ordner)
    extra = [] if a.ordner == os.path.abspath(R.CONTENT_DIR) else [a.ordner]
    if extra:
        os.makedirs(a.ordner, exist_ok=True)

    try:
        game.load(extra)
    except R.ContentError as err:
        fail(f'{err}\n\nDie Inhalte sind fehlerhaft. Erst beheben (python tools/pruefen.py), dann ein neues Gerüst anlegen.')
    if not R.ID_RE.match(a.id):
        fail(f'Kennung {a.id!r}: Kleinbuchstaben, Ziffern und _ – beginnend mit einem Buchstaben.')
    if taken(a.id):
        fail(f"Die Kennung '{a.id}' ist schon vergeben ({taken(a.id)}).")

    path = {'klasse': new_class, 'karte': new_map, 'gegner': new_enemy, 'quest': new_quest}[a.kind](a)
    shown = os.path.relpath(path, ROOT) if path.startswith(ROOT) else path
    flag = f' --extra {a.ordner}' if extra else ''
    try:
        game.load(extra)
    except R.ContentError as err:
        fail(f'Angelegt: {shown}\nDas Gerüst passt aber nicht zu den vorhandenen Inhalten:\n{err}')
    todo = sum(int(n.split(' Platzhalter')[0].rsplit(' ', 1)[1]) for n in R.NOTES if 'TODO' in n and n.startswith(shown + ':'))
    print(f'Angelegt und geprüft: {shown}')
    if todo:
        print(f'  {todo} Platzhalter (TODO) warten auf deinen Text.')
    view = {'klasse': f'--klasse {a.id}', 'karte': f'--karte {a.id}', 'quest': '--quests', 'gegner': ''}[a.kind]
    print(f'  Ansehen:   python tools/pruefen.py {view}{flag}'.rstrip())
    print(f'  Probelauf: python tools/pruefen.py --spiel{flag}')
    if a.kind == 'gegner':
        print("  Der Gegner erscheint erst, wenn eine Karte ihn in spawns oder dungeon['mix'] nennt.")
    return 0


if __name__ == '__main__':
    for stream in (sys.stdout, sys.stderr):                   # Umlaute und Pfeile auch auf Windows und in Pipes
        stream.reconfigure(encoding='utf-8', errors='replace')
    try:
        code = main()
        sys.stdout.flush()
    except BrokenPipeError:                                   # Ausgabe wurde abgeschnitten (z. B. durch | head)
        os.dup2(os.open(os.devnull, os.O_WRONLY), sys.stdout.fileno())
        code = 0
    sys.exit(code)
