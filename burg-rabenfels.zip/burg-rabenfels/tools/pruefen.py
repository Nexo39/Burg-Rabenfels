"""Prüft die Inhalte unter content/ und zeigt, was daraus entsteht.

  python tools/pruefen.py                 alle Inhalte laden und prüfen, Übersicht ausgeben
  python tools/pruefen.py --karte burg    Plan einer Karte mit Zahlenleiste, Bewohnern, Zonen und Übergängen
  python tools/pruefen.py --klasse magier Skilltree einer Klasse als Tabelle
  python tools/pruefen.py --quests        alle Quests in ihrer Reihenfolge
  python tools/pruefen.py --spiel         Probelauf ohne Browser: jede Klasse, jede Fähigkeit, jeder Übergang,
                                          jede Quest, jedes Verlies
  --extra ORDNER                          zusätzlichen Inhaltsordner mitladen (mehrfach möglich)

Rückgabewert 0, wenn alles in Ordnung ist, sonst 1 – geeignet für Skripte.
"""
import argparse
import math
import os
import sys
import tempfile
import traceback

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
sys.path.insert(0, ROOT)
import game                                              # noqa: E402
from game import registry as R, world as W                # noqa: E402


def load(extra):
    try:
        game.load(extra)
    except R.ContentError as err:
        print(err)
        if R.NOTES:
            print('\nHinweise:\n  - ' + '\n  - '.join(R.NOTES))
        return False
    return True


def overview():
    print(f'Inhalte in Ordnung: {len(R.CLASSES)} Klassen, {len(R.SKILLS)} Fähigkeiten, {len(R.ENEMIES)} Gegnerarten, '
          f'{len(R.QUESTS)} Quests, {len(R.MAPS)} Karten, {len(R.COMBOS)} Kombos.')
    if R.NOTES:
        print('\nHinweise (kein Fehler, aber vielleicht nicht so gemeint):\n  - ' + '\n  - '.join(R.NOTES))
    print('\nKarten')
    for mid, b in W.MAPS.items():
        m = R.MAPS[mid]
        foes = sum(n for kind, zone, n, _ in W.SPAWNS if zone['map'] == mid)
        to = sorted({p['to'] for (tx, tz), p in W.PORTAL_AT.items() if W.map_at(tx * W.TILE, tz * W.TILE) == mid})
        extra = ', Verlies' if b['dungeon'] else ''
        print(f"  {mid:14s} {b['name']:22s} {b['w']:2d} x {b['h']:2d}  {b['light']:6s}  {len(b['zones'])} Zonen, {foes} Gegner, "
              f"{len(m['npcs'])} Bewohner, {len(m['pickups'])} Fundstücke{extra}; Übergänge nach: {', '.join(to) or '–'}"
              + ('  [Hauptkarte]' if mid == W.MAIN else ''))
    print('\nKlassen')
    for cid, c in R.CLASSES.items():
        mine = [s for s in R.SKILLS.values() if s['cls'] == cid]
        per = ', '.join(f"{b['name']} {sum(1 for s in mine if s['branch'] == i)}" for i, b in enumerate(c['branches']))
        print(f"  {cid:14s} {c['name']:14s} {sum(1 for s in mine if s['type'] == 'active')} aktiv, "
              f"{sum(1 for s in mine if s['type'] == 'passive')} passiv  ({per})  Hauptattribut {c['main']}, {c['res']}")
    print('\nMehr: --karte ID, --klasse ID, --quests, --spiel')


def show_map(mid):
    if mid not in W.MAPS:
        print(f"Karte '{mid}' gibt es nicht. Vorhanden: {', '.join(W.MAPS)}")
        return False
    b, m = W.MAPS[mid], R.MAPS[mid]
    marks, legend = {}, []
    if 'reach' in b:                                           # begehbar, aber vom Start und den Ankünften abgeschnitten
        cut = [(x, z) for z in range(b['h']) for x in range(b['w'])
               if b['floor'][z][x] not in W.SOLID_FLOOR and b['obj'][z][x] not in W.SOLID_OBJ and (x, z) not in b['reach']]
        marks.update({t: '?' for t in cut})
        if cut:
            legend.append(f'  ?  {len(cut)} begehbare Kacheln, die niemand erreichen kann (abgeschnitten)')
    sx, sz = m['start']
    marks[(int(sx), int(sz))] = '@'
    legend.append(f"  @  Start {m['start']}")
    for i, (nid, n) in enumerate(m['npcs'].items()):
        ch = 'abcdefghijklmnopqrstuvwxyz'[i % 26]
        if not n.get('at') or len(n['at']) != 2:
            continue
        marks[(int(n['at'][0]), int(n['at'][1]))] = ch
        legend.append(f"  {ch}  Bewohner {nid} ({n.get('name')}) bei {tuple(n['at'])}" + (f", Dienste: {', '.join(n['services'])}" if n.get('services') else ''))
    picks = [pk for pk in m['pickups'] if len(pk) == 3]
    for kind, x, z in picks:
        marks[(int(x), int(z))] = '*'
    if picks:
        legend.append('  *  Questgegenstände: ' + ', '.join(f'{k} {(x, z)}' for k, x, z in picks))
    for (tx, tz), p in W.PORTAL_AT.items():
        if W.map_at(tx * W.TILE, tz * W.TILE) == mid:
            marks[(tx - b['ox'], tz)] = '>'
            lx, lz = p['x'] / W.TILE - W.MAPS[p['to']]['ox'], p['z'] / W.TILE
            legend.append(f"  >  Übergang auf Kachel {(tx - b['ox'], tz)} nach '{p['to']}' {(round(lx, 1), round(lz, 1))}")
    print(f"Karte '{mid}' – {b['name']}, {b['w']} x {b['h']} Kacheln, Licht: {b['light']}\n")
    print(W.ascii_map(mid, marks))
    print('\n' + '\n'.join(legend))
    for name, z in b['zones'].items():
        rect = m['zones'][name]['rect'] if isinstance(m['zones'][name], dict) else m['zones'][name]
        foes = ', '.join(f'{n} x {kind}' for kind, zone, n, _ in W.SPAWNS if zone is z) or ('Verlies' if z['dungeon'] else 'keine Gegner')
        print(f"  Zone {name}: Rechteck {tuple(rect)}, {len(z['tiles'])} begehbare Kacheln, {foes}")
    for name, rect in m['regions']:
        print(f'  Ort „{name}“: {tuple(rect)}')
    print('\nKoordinaten sind (x, z): x = Spalte (Zahlenleiste oben), z = Zeile (Zahl links).')
    return True


def show_class(cid):
    if cid not in R.CLASSES:
        print(f"Klasse '{cid}' gibt es nicht. Vorhanden: {', '.join(R.CLASSES)}")
        return False
    c = R.CLASSES[cid]
    a = c['atk']
    print(f"Klasse '{cid}' – {c['name']}: Leben {c['hp']} (+{c['hp_lvl']} je Stufe), Schaden {c['dmg']}, Rüstung {c['armor']}, "
          f"Hauptattribut {c['main']}, {c['res']}, Stil {c['style']}")
    print(f"Grundangriff {a['name']}: {a['type']}, {a['tag']}, alle {a['cd']} s, Reichweite {a['range']}\n")
    for i, br in enumerate(c['branches']):
        print(f"Zweig {i}: {br['name']} – {br['desc']}")
        nodes = sorted((s for s in R.SKILLS.values() if s['cls'] == cid and s['branch'] == i), key=lambda s: s['lvl'])
        for s in nodes:
            if s['type'] == 'passive':
                detail = f"passiv  {s['stat']} +{s['per']} je Stufe"
            else:
                bits = [f"{s['form']:5s}", f"{s['tag'] or '–':8s}", f"Kosten {s['cost']:2d}", f"cd {s['cd']:>4}"]
                if s.get('mult'):
                    n = s.get('hits') or s.get('count') or 1
                    bits.append(f"Schaden {n} x {s['mult']}" if n > 1 else f"Schaden {s['mult']}")
                if s.get('apply'):
                    bits.append(f"→ {s['apply']}")
                detail = '  '.join(bits)
            start = '  [Start]' if s['id'] == c['start'] else ''
            print(f"  St.{s['lvl']:3d}  braucht {s['need']} Punkte  {s['id']:18s} {s['name']:22s} {detail}{start}")
        print()
    return True


def show_quests():
    print('Quests in der Reihenfolge ihrer Anmeldung\n')
    for qid, q in R.QUESTS.items():
        npc = W.NPCS[q['npc']]
        reward = f"{q['xp']} EP" if q.get('xp') else f"{q['xp_pct']:.0%} einer Stufe"
        reward += f", {q['gold']} Gold" if q.get('gold') else f", {q['gold_lvl']} Gold je Stufe" if q.get('gold_lvl') else ''
        cond = ', '.join(x for x in (f"nach '{q['req']}'" if q['req'] else '', f"ab Stufe {q['minlvl']}" if q['minlvl'] > 1 else '',
                                     'wiederholbar' if q.get('repeat') else '') if x)
        print(f"  {qid:10s} {q['title']:28s} {npc['name']} ({npc['map']})  {q['type']} {q['target']} x {q['count']}  → {reward}"
              + (f'  [{cond}]' if cond else ''))
    return True


def smoke():
    """Probelauf: startet die Spiellogik und benutzt alle Inhalte einmal. Meldet, was nicht funktioniert."""
    import game.engine as E
    clock = [1000.0]
    E.time.time = lambda: clock[0]
    g = E.Game(lambda *a, **k: None, os.path.join(tempfile.mkdtemp(), 'saves', 'probe.json'), dev=True)
    problems = []

    def tick(seconds):
        for _ in range(int(seconds / E.TICK)):
            clock[0] += E.TICK
            g.tick(clock[0], E.TICK)

    def attempt(what, fn):
        try:
            fn()
        except Exception:                                        # jede Störung zählt, der Lauf geht weiter
            tb = traceback.format_exc().strip().split('\n')
            where = next((l.strip() for l in reversed(tb) if l.strip().startswith('File')), '')
            problems.append(f'{what}: {tb[-1]}  ({where})')

    def hero(sid, cid):
        r = g.join(sid, 'Probe ' + cid[:8], cid)
        assert r.get('ok'), r
        p = g.players[sid]
        p.level = 100
        p.skills = {k: 1 for k, s in R.SKILLS.items() if s['cls'] == cid}
        p.recalc()
        p.hp, p.res = float(p.max_hp), float(p.stats['res'])
        return p

    # ---- 1) Klassen: Grundangriff und jede aktive Fähigkeit, mitten unter Gegnern
    spot = next(((z, at) for kind, z, n, at in W.SPAWNS), None)
    for cid in R.CLASSES:
        sid = 'k_' + cid
        made = []
        attempt(f"Klasse '{cid}'", lambda: made.append(hero(sid, cid)))
        if not made:
            continue
        p = made[0]

        def visit():                                               # einmal auf jeder Karte stehen
            for b in W.MAPS.values():
                p.x, p.z = b['start']
                tick(0.3)
        attempt(f"Klasse '{cid}' auf den Karten", visit)
        if spot:
            p.x, p.z = spot[1] or W.random_point(spot[0])
        here = W.map_at(p.x, p.z)
        for key, sk in R.SKILLS.items():
            if sk['cls'] != cid or sk['type'] != 'active':
                continue

            def cast(key=key):
                p.hp, p.res, p.dead = float(p.max_hp), float(p.stats['res']), False
                p.cds.clear()
                p.bar[0] = key
                near = [e for e in g.enemies.values() if not e.dead and e.zone['map'] == here]
                t = min(near, key=lambda e: math.hypot(e.x - p.x, e.z - p.z)) if near else None
                aim = {'x': t.x if t else p.x + 3, 'z': t.z if t else p.z}
                r = g.on_skill(sid, {'n': 1, **aim})
                if not (r and r.get('ok')):
                    problems.append(f"Klasse '{cid}', Fähigkeit '{key}': ließ sich nicht wirken ({r}).")
                g.on_attack(sid, aim)
                tick(1.3)
            attempt(f"Klasse '{cid}', Fähigkeit '{key}'", cast)
            for e in g.enemies.values():
                if e.dead and not e.temp:
                    e.reset()
        attempt(f"Klasse '{cid}' verlässt das Spiel", lambda: g.leave(sid))

    cid = next(iter(R.CLASSES))
    p = hero('probe', cid)

    # ---- 2) Übergänge: führen dorthin, wo sie sollen
    for (tx, tz), dest in list(W.PORTAL_AT.items()):
        def run(tx=tx, tz=tz, dest=dest):
            p.x, p.z, p.stairs_at, p.dead = (tx + 0.5) * W.TILE, (tz + 0.5) * W.TILE, 0.0, False
            tick(0.2)
            if W.map_at(p.x, p.z) != dest['to']:
                problems.append(f"Übergang auf Kachel {(tx, tz)}: Held kam nicht auf Karte '{dest['to']}' an.")
        attempt(f'Übergang {(tx, tz)}', run)

    # ---- 3) Quests: annehmen, erfüllen, abgeben
    for qid, q in R.QUESTS.items():
        def run(qid=qid, q=q):
            n = W.NPCS[q['npc']]
            p.x, p.z, p.dead, p.hp = n['x'] * W.TILE, (n['z'] + 0.5) * W.TILE, False, float(p.max_hp)
            if W.blocked(p.x, p.z, 0.3):
                p.x, p.z = n['x'] * W.TILE, n['z'] * W.TILE
            p.quests = {k: {'s': 'done', 'n': v['count']} for k, v in R.QUESTS.items() if k != qid}
            p.deepest = {}
            g.on_quest('probe', {'id': qid, 'do': 'accept'})
            if p.quests.get(qid, {}).get('s') != 'active':
                return problems.append(f"Quest '{qid}': ließ sich bei {n['name']} nicht annehmen.")
            for _ in range(q['count'] if q['type'] != 'depth' else 1):
                if q['type'] == 'kill':
                    t = q['target']
                    g._quest_progress(p, 'kill', None if t == 'any' or t.startswith('map:') else t,
                                      map_id=t[4:] if t.startswith('map:') else None)
                elif q['type'] == 'depth':
                    g._quest_progress(p, 'depth', q['target'], q['count'])
                else:
                    g._quest_progress(p, q['type'], q['target'])
            if p.quests[qid]['s'] != 'ready':
                return problems.append(f"Quest '{qid}': wird nicht als erfüllt erkannt (Stand {p.quests[qid]}).")
            g.on_quest('probe', {'id': qid, 'do': 'turnin'})
            if p.quests[qid]['s'] != 'done':
                problems.append(f"Quest '{qid}': ließ sich nicht abgeben.")
        attempt(f"Quest '{qid}'", run)

    # ---- 4) Verliese: bis über den ersten Boss
    for mid, dg in g.dungeons.items():
        def run(mid=mid, dg=dg):
            cfg = W.MAPS[mid]['dungeon']
            zone = W.MAPS[mid]['zones'][cfg['zone']]
            p.x, p.z = W.random_point(zone)
            p.dead, p.hp, p.deepest = False, float(p.max_hp), {}
            tick(0.2)
            floors = cfg['boss_every'] + 1 if cfg['boss'] else 3
            for depth in range(1, floors + 1):
                if dg['depth'] != depth or dg['phase'] != 'fight':
                    return problems.append(f"Verlies '{mid}': Ebene {depth} begann nicht (Stand {dg['depth']}, {dg['phase']}).")
                for _ in range(40):                                # Wellen: alle besiegen, bis die Ebene geschafft ist
                    for e in g._dungeon_enemies(zone):
                        g._damage_enemy(e, p, e.hp + 1)
                    p.hp, p.dead = float(p.max_hp), False
                    tick(0.1)
                    if dg['phase'] != 'fight':
                        break
                tick(4.3)
            if p.deepest.get(mid, 0) < floors:
                problems.append(f"Verlies '{mid}': nach {floors} Ebenen steht die tiefste bei {p.deepest.get(mid, 0)}.")
        attempt(f"Verlies '{mid}'", run)

    tick(1.0)
    if problems:
        print(f'Probelauf: {len(problems)} Problem(e)\n  - ' + '\n  - '.join(problems))
        return False
    print(f'Probelauf in Ordnung: {len(R.CLASSES)} Klassen mit {sum(1 for s in R.SKILLS.values() if s["type"] == "active")} '
          f'aktiven Fähigkeiten, {len(W.PORTAL_AT)} Übergangskacheln, {len(R.QUESTS)} Quests, {len(g.dungeons)} Verlies(e).')
    return True


def main():
    ap = argparse.ArgumentParser(description='Inhalte von Burg Rabenfels prüfen und ansehen.')
    ap.add_argument('--karte', metavar='ID')
    ap.add_argument('--klasse', metavar='ID')
    ap.add_argument('--quests', action='store_true')
    ap.add_argument('--spiel', action='store_true', help='Probelauf der Spiellogik mit allen Inhalten')
    ap.add_argument('--extra', action='append', default=[], metavar='ORDNER')
    args = ap.parse_args()
    if not load(args.extra):
        if args.karte and args.karte in W.MAPS:               # der Plan hilft beim Beheben, auch wenn noch Fehler offen sind
            print()
            show_map(args.karte)
        return 1
    ok = True
    if args.karte:
        ok = show_map(args.karte)
    elif args.klasse:
        ok = show_class(args.klasse)
    elif args.quests:
        ok = show_quests()
    elif args.spiel:
        ok = smoke()
    else:
        overview()
    return 0 if ok else 1


if __name__ == '__main__':
    for stream in (sys.stdout, sys.stderr):                   # Umlaute und Pfeile auch auf Windows und in Pipes
        stream.reconfigure(encoding='utf-8', errors='replace')
    try:
        code = main()
        sys.stdout.flush()
    except BrokenPipeError:                                   # Ausgabe wurde abgeschnitten (z. B. durch | head)
        os.dup2(os.open(os.devnull, os.O_WRONLY), sys.stdout.fileno())
        code = 0
    sys.exit(code)
